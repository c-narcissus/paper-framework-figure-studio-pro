# Release Checklist v3.2.15

- [ ] `VERSION` is `3.2.15`.
- [ ] `SKILL.md` describes S0-S5 only and states that S5 is terminal.
- [ ] S1 must include former S2 preparation duties.
- [ ] S3 must include former S2 review/aggregate duties.
- [ ] S4 must include former S5 preparation duties.
- [ ] S2/S5 expose only `IMAGE_GENERATE` substages.
- [ ] No assistant workflow, command, template, or handoff exists after S5.
- [ ] Image route guard still forbids SVG/code/PPT/PDF/screenshot/local raster substitutes for target-paper images.
- [ ] No user-facing contract-check setting appears in starter prompts, state templates, or active policy references.
- [ ] Architecture audit passes.

- [ ] Candidate/artifact ID coherence passes for prompt-index, manifest, registry, artifacts, status files, image-generation events, and checkpoint inventories.
- [ ] User-facing suggested prompts say `请使用 paper-framework-figure-studio-pro skill` and do not refer to versioned archive filenames.
