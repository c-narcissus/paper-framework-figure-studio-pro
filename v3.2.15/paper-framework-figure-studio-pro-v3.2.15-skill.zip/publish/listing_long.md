# paper-framework-figure-studio-pro v3.2.15

A human-in-the-loop workflow for research-paper framework, architecture, pipeline, data-flow, and mechanism figures.

Workflow: Bootstrap -> S0 -> S1 -> S2 -> S3 -> S4 -> S5 -> END.

Key behavior:

- S0 builds the paper foundation and risk register.
- S1 designs the figure strategy and must prepare all S2 prompt packages/prompt-index.
- S2 only generates low-fidelity sketch candidates through the approved image route.
- S3 reviews/aggregates S2 visual signals and selects the direction.
- S4 prepares formal candidate briefs and all S5 prompt packages/prompt-index.
- S5 only generates formal raster candidates and ends the assistant workflow.
- Human selection, manuscript captioning, and downstream editing after S5 are outside this skill.
