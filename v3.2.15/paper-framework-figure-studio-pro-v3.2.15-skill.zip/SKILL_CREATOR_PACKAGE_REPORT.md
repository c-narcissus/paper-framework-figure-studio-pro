# Skill Creator Package Report v3.2.15

## Package status

This package updates paper-framework-figure-studio-pro to v3.2.15.

## Main structural behavior

The active workflow remains terminal at S5-CANDIDATE-IMAGE. S2 and S5 are image-generation-only public stages:

- S1 includes the former S2 prompt-preparation work.
- S2 only generates sketch images from the S1 prompt-index.
- S3 includes the former S2 image review and exploration aggregate work, then selects direction.
- S4 includes the former S5 prompt-preparation work.
- S5 only generates formal candidate images and ends the assistant workflow.

## v3.2.15 candidate/artifact ID hardening

- Adds `references/candidate-artifact-id-coherence-policy-v3215.md`.
- Makes prompt-index `candidate_id` the source of truth for image stages.
- Keeps IDs coherent across prompt paths, target image paths, manifests, substage plans, status files, candidate registries, artifacts, image-generation events, and checkpoint inventories.
- Defaults S2 sketch IDs to `C01-C08` and S5 formal IDs to `F01-F06`; later stages and scripts must not rewrite S5 IDs as `Cxx` or numeric artifact IDs after prompt-index exists.
- Updates validation and image-batch registration to detect candidate/path mismatches.

## User-facing prompt wording

Suggested prompts now say `请使用 paper-framework-figure-studio-pro skill` and do not refer to versioned archive filenames.
