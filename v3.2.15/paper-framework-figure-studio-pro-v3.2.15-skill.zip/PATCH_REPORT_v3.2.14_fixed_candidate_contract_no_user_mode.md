# PATCH REPORT v3.2.14 — Fixed Candidate Contract Without User-Exposed Mode

## User request

Because there is only one supported candidate contract behavior, the skill must not present a contract-check setting in suggested prompts or project templates.

## Changes

- Removed user-facing contract-check configuration from startup guidance.
- Replaced the old contract-check-mode policy with `references/fixed-candidate-contract-policy-v3214.md`.
- Renamed project state default policy from a mode selector to `fixed_candidate_contract_policy`.
- Updated active scripts, metadata, templates, release files, and architecture audit to v3.2.14.
- Added audit guards against obsolete contract-setting terms in active user-facing files.

## Invariant kept

S2 and S5 remain image-generation-only. S5 remains terminal: `我的任务已经完成，剩下由人类来决策。`
