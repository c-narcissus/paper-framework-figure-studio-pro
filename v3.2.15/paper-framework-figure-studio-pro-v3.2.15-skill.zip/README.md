# Paper Framework Figure Studio Pro

Version: **3.2.15**

A human-in-the-loop skill for paper-grounded research framework figures: architecture diagrams, method overviews, mechanism schematics, system/data-flow figures, and pipeline figures.

## v3.2.15 workflow

```text
Bootstrap / plan-only gate
  ↓
S0-PAPER-FOUNDATION
  ↓
S1-FIGURE-STRATEGY
  └─ includes former S2 prompt preparation
  ↓
S2-SKETCH-EXPLORE
  └─ image generation only
  ↓
S3-DIRECTION-SELECT
  └─ includes former S2 audit and aggregate duties
  ↓
S4-CANDIDATE-BRIEF
  └─ includes former S5 prompt preparation
  ↓
S5-CANDIDATE-IMAGE
  └─ image generation only, terminal
```

After S5, the assistant workflow is complete. The remaining selection, manual editing, final captioning, and paper-layout decisions are handled by humans.

If asked what comes after S5, answer:

```text
我的任务已经完成，剩下由人类来决策。
```

## What changed in v3.2.15

- S2 and S5 are now **image-generation-only public stages**.
- S1 **must** perform the old S2 preparation responsibilities before closing.
- S3 **must** perform the old S2 review and aggregate responsibilities before or during direction selection.
- S4 **must** perform the old S5 preparation responsibilities before closing.
- S2/S5 rerun, review, and standalone aggregate substages are removed.
- There is no assistant workflow after S5; human selection and manuscript use are outside this skill.
- future-image-stage dynamic parity has been removed from the active workflow contract.
- User-facing contract-check configuration remains removed; the fixed candidate contract behavior is built into S1/S3/S4 and never appears as a prompt option.
- Prompt-index `candidate_id` is now the hard source of truth for S2/S5 image ids, paths, state registries, artifacts, and checkpoints.
- S2 defaults to `C01`-`C08`; S5 defaults to `F01`-`F06`, but any validated prompt-index id set is allowed without paper-specific hardcoding.
- Suggested user prompts say “请使用 paper-framework-figure-studio-pro skill” rather than naming a versioned skill zip.

## Image route

Target paper images must be generated only through the environment-approved image route:

- Codex: `image_gen`
- ChatGPT web: Create Image / ChatGPT Images 2.0
- Other runtimes: named approved image-generation API only

The workflow forbids SVG, Mermaid, HTML/canvas, Python/PIL/Pillow, Matplotlib, Graphviz, TikZ, PPT/PDF rendering, screenshots, SVG-to-PNG, and local programmatic raster substitutes for target paper images.

## Main safeguards

- Paper-grounded source evidence and risk register from S0.
- Reader-first visual strategy and S2 prompt preparation inside S1.
- Low-fidelity exploration sketches in S2.
- Embedded S2 issue-ledger review and direction selection in S3.
- Formal candidate prompt preparation inside S4.
- Formal candidate image generation in S5.
- Human decision boundary after S5.
- Candidate/artifact/checkpoint id coherence validation across outputs and state files.

## Package notes

Reusable skill files must stay paper-neutral. Project-specific paper facts, module names, variables, datasets, candidate outputs, and audit conclusions belong only in run outputs, not in the skill package.
