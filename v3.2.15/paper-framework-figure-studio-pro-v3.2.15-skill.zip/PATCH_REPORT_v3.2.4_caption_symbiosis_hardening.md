# Patch Report: v3.2.4 Caption-Symbiosis / Handoff Hardening

Scope: generic skill package only. No paper-specific module, dataset, project path, or target-paper-specific rule was added.

## Changes

1. **Figure-caption symbiosis hardening**
   - Added S2/S5 issue-ledger caption fields: caption alignment issues, caption burden, safe caption-only items, must-be-visible-not-caption-only items, legend/caption needs, and caption risk notes.
   - S3/deleted assistant workflow after S5 now consume user preference plus issue ledgers/caption-burden notes as decision context.

2. **S2/S5 issue-ledger audit**
   - S2/S5 embedded image review/deleted text recheck defaults to issue inventories rather than PASS/FAIL-style candidate conclusions.
   - Hard contradictions are represented as `BLOCKER_ISSUE` entries.

3. **Prompt handoff file references**
   - S2/S5/rerun image prompts must be saved to prompt files and referenced by prompt-index files.
   - User-visible next prompts should reference prompt indexes or final-image-prompt files rather than inline long prompt bodies.

4. **S2 default style**
   - S2 default image style is now explicitly hand-drawn / whiteboard-like / wireframe / low-fidelity exploration unless the user asks otherwise.

5. **S4 formal candidate defaults**
   - Complete-paper / framework / method-overview tasks default to six generic formal candidate briefs from a paper-agnostic visual-treatment matrix.

6. **Helper scripts**
   - Hardened generic prompt_handoff.py, audit_policy.py, formal_matrix.py, checkpoint_policy.py.
   - Updated DEFAULT_CANDIDATE_COUNT_BY_STEP for S5 to 6.

## Regression Checklist

- [x] No target-paper-specific module names added to reusable policy text.
- [x] No current project paths added to reusable skill rules.
- [x] S2 default hand-drawn style recorded in SKILL and reference policies.
- [x] S2/S5 audits record issue ledgers and caption-burden fields.
- [x] Prompt handoffs use file references / prompt indexes.
- [x] S4 default formal matrix count is six.
