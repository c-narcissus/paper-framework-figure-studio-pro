# Patch Report v3.2.9 — Cumulative Substage Checkpoint Guard

## Purpose

Fix a generic workflow failure mode where a dynamic-stage substage checkpoint can accidentally become a current-substage-only zip instead of a cumulative restore bundle.

This patch is paper-agnostic and task-agnostic. It does not encode any project id, paper title, dataset, model, candidate id, stage-local filename, or generated image count.

## New policy

Added:

- `references/cumulative-substage-checkpoint-integrity-policy-v329.md`

The new policy states that every checkpoint-producing step/substage must:

1. inventory current included roots dynamically from workflow state;
2. inspect prior `complete_restore_ready` checkpoint bundles from state;
3. preserve previous checkpoint payload members that still fall under current included roots;
4. write the checkpoint;
5. reopen the zip or zip-part union;
6. validate required assets/images and previous payload subset;
7. rebuild/repack or record `incomplete_restore_blocked` before surfacing the checkpoint;
8. include `checkpoint-integrity-audit.json` in every checkpoint.

## Script/runtime changes

Updated:

- `scripts/figure_studio_core/substages.py`
  - adds generic previous-checkpoint payload discovery;
  - adds cumulative `checkpoint_stage_list` and `cumulative=true` manifest fields;
  - adds prior payload recovery from previous complete checkpoint zips;
  - adds post-write previous-payload subset validation;
  - writes `checkpoint-integrity-audit.json`;
  - repacks checkpoint archives with integrity metadata;
  - keeps planned future images pending rather than missing.

Added:

- `scripts/figure_studio_checkpoint_integrity.py`
  - standalone generic audit script for checkpoint zip/part unions;
  - verifies `checkpoint-integrity-audit.json` is present;
  - verifies previous complete checkpoint payload members are preserved;
  - discovers all expectations from state, workflow order, included roots, and checkpoint bundles.

Updated:

- `references/cumulative-restore-checkpoint-policy-v318-hotfix.md`
- `references/s2-s5-dynamic-substage-orchestration-policy-v316.md`
- `SKILL.md`
- `README.md`
- `CHANGELOG.md`
- `metadata.json`
- `agents/openai.yaml`

## Non-hardcoding audit

The patch uses dynamic sources only:

- `WORKFLOW_STEPS` for stage order and output roots;
- `checkpoint_bundles` for prior checkpoints;
- current run-directory included roots;
- state artifact/image-generation/candidate registries;
- zip member lists.

It does not hard-code S5, legacy dynamic-stage pattern, a specific paper, a specific project, candidate IDs, image counts, module names, or output filenames beyond generic checkpoint metadata names.

## Validation performed

Commands run:

```bash
python -m py_compile scripts/figure_studio_checkpoint_integrity.py scripts/figure_studio_core/substages.py scripts/figure_studio_core/constants.py
python scripts/figure_studio_architecture_audit.py --target . --fail-on-issue
python scripts/figure_studio_release_check_paths.py scan --target .
```

A temporary generic two-stage run was also created to verify that an S1 chunk checkpoint preserves an S0 stage-final payload and includes `checkpoint-integrity-audit.json`.

## Result

Version bumped to `3.2.9`. Release package is ready as:

```text
paper-framework-figure-studio-pro-v3.2.9-skill.zip
```
