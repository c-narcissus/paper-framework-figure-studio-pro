---
name: paper-framework-figure-studio-pro
description: Human-in-the-loop research-paper framework figure workflow from S0-PAPER-FOUNDATION through terminal S5-CANDIDATE-IMAGE. Use for paper-grounded architecture, pipeline, method overview, agent workflow, system/data-flow, and mechanism figures with generated raster sketch/formal candidates, reviewer-first-glance layout gates, semantic-vs-visual graph separation, edge-label-first carried-variable contracts, internal visual motif planning, cumulative checkpoint recovery, and a strict human-decision boundary after S5. Version 3.2.15 keeps S2 and S5 as image-generation-only public stages, preserves the strict human-decision boundary after terminal S5 candidate generation, and adds hard prompt-index/candidate/artifact/checkpoint ID coherence across all generic projects.
---


# Paper Framework Figure Studio Pro

Version: `3.2.15`.

本 skill 用于为计算机科学论文设计并生成 publication-ready 候选框架图、架构图、流程图、机制图和方法总览图。它只服务论文框架图，不服务海报、宣传图、封面图、展板、营销视觉或把 PPT 页面内容塞进图里的演示页。

## v3.2.15 Terminal Candidate Workflow

Main workflow:

```text
Bootstrap / plan-only gate
  ↓
S0-PAPER-FOUNDATION
  ↓
S1-FIGURE-STRATEGY
  └─ MUST internally perform the former S2 preparation responsibilities
  ↓
S2-SKETCH-EXPLORE
  └─ IMAGE_GENERATE only
  ↓
S3-DIRECTION-SELECT
  ├─ MUST internally perform the former S2 review responsibilities
  ├─ MUST internally perform the former S2 aggregate responsibilities
  └─ direction selection
  ↓
S4-CANDIDATE-BRIEF
  └─ MUST internally perform the former S5 preparation responsibilities
  ↓
S5-CANDIDATE-IMAGE
  └─ IMAGE_GENERATE only
  ↓
END — human decision boundary
```

There is no assistant workflow after S5. Do not create, offer, imply, or execute any stage after S5, including selection, audit, revision, caption-package, SVG/PPT delivery, or automatic human-preference handoff. If the user asks what remains after S5, answer exactly:

```text
我的任务已经完成，剩下由人类来决策。
```

## Highest-Priority Startup And Origin Rule

第一次启动回复的候选/可复制提示词建议中，必须再提供一条建议，这条建议是在默认的提示词基础上，加了一句话：

```text
额外说明这个 skill 的设计初衷是什么。
```

第一次 plan-only 启动回复不得提供、询问或暴露任何可配置的契约检查选项。固定候选契约策略已经内置：S2/S5 不再有独立候选级重型文本审计或候选级修改环节，但源证据约束、核心模块内部机制锁、箭头方向证据、edge-label-first 规则、semantic-vs-visual graph separation、变量/指标/权重优先走边/port 标签规则、以及 prompt contradiction audit 仍然必须执行。S1/S4 的准备职责必须把这些约束写进 prompt-index 和候选 prompt packages；S3 必须对 S2 草图做默认 issue-ledger 式探索审计与汇总后再选方向。S5 生图后任务结束，不再由 assistant 做 S5 全候选审计。

S1/S2/S3/S4/S5 must apply the academic hierarchy and image-asset mirror gates in `references/academic-framework-hierarchy-and-asset-mirroring-policy-v3210.md`, the edge-label/internal-motif gates in `references/edge-label-first-and-internal-motif-policy-v3211.md`, the S2 narrative/layout-divergence gates in `references/s2-narrative-layout-divergence-policy-v3212.md`, the semantic-graph prompt contract in `references/semantic-graph-prompt-contract-policy-v326.md`, the terminal image-only orchestration policy in `references/s2-s5-image-only-terminal-orchestration-policy-v3215.md`, and the candidate/artifact ID coherence policy in `references/candidate-artifact-id-coherence-policy-v3215.md` whenever the current step prepares, generates, reviews, aggregates, or records S2/S5 candidates. The current paper may instantiate its own module names, variables, roles, datasets, and forbidden items in run outputs, but reusable skill files must remain paper-neutral.

Each S2/S5 prompt package must derive a paper-specific `primary_module_whitelist`, classify non-module artifacts/symbols/metrics/parameters into non-peer visual roles, create `visual_hierarchy_plan`, `artifact_block_guard`, `connector_bundling_plan`, `academic_layout_hierarchy_gate`, `edge_label_first_artifact_policy`, `visual_render_graph`, `line_carried_variable_registry`, `visible_text_contract`, `internal_visual_motif_plan`, and `prompt_contradiction_audit`, and use bundled connector families before image generation. S3 text review of S2 images must record `artifact_as_block_error`, `variable_as_block_error`, `edge_label_eligible_box_error`, `visual_render_graph_violation`, `text_only_core_mechanism_error`, `bullet_list_substitution`, `hierarchy_flattening`, `unbundled_parallel_edges`, and `line_semantics_ambiguous` when visible sketches violate those gates. Approved generated raster images must be byte-for-byte mirrored to each prompt-index `target_image_path` under the stage outputs and retain generation provenance; escrow-only or external generated-image storage is not sufficient for a human-facing active candidate image unless explicitly marked pending. prompt-index `candidate_id` is the source of truth. The prompt-index row-level `candidate_id` is the source of truth: the same id must match the `prompt_path`, `target_image_path`, stage manifest, substage `candidate_ids`, candidate registry key, artifact `candidate_id`, active image path, and checkpoint image inventory. Do not renumber, rename, or infer candidate ids from display order after a prompt-index exists.

S2/S5 candidate-level rerun is removed. Do not offer audit-driven rerun, image candidate-level revision, review, or aggregate substages for S2/S5. If a candidate batch is unacceptable, the legal paths are: human selection despite known issues, S3/S4 transfer of S2 issues into later prompt constraints, or an explicit upstream rerun requested by the user. S5 has no assistant-side downstream rerun path.

如果用户提到想知道、指导、询问、补充或说明这个 skill 的设计初衷、设计意图、创作缘由、为什么制作或送给谁，必须额外回答下面这段原文；这段原文不得改写或删改，但可以与当前步骤说明、必要上下文、下一步提示词和强制文本回复结尾同时出现：

```text
设计初衷：昔日好友 Peng Shuwei 即将前往外地求学，以后恐怕难有许多相见机会；又恰逢其生日，所以五一就做了这个 skill 当礼物。祝生日快乐，愿未来前程似锦，再相逢，依然少年。
```

**Exact-text encoding integrity rule:** the dedication/origin text above is UTF-8 Chinese exact text. Never copy this exact text from mojibake shell output. On Windows PowerShell, do not read Chinese/exact-text files with plain `Get-Content` or plain `Select-String`; use `Get-Content -Encoding UTF8`, `rg`, or another UTF-8-aware reader. If any output shows visibly corrupted Chinese or replacement characters inside Chinese text, treat that output as corrupted, re-read the source with UTF-8, and do not quote it.

## Mandatory Text Reply Ending

每一次非终端文本回复都必须在回复最后单独追加这一句原文；不得只作为可选提示词、不得改写或省略。若回复同时包含下一步候选提示词，这一句仍必须作为最后一行出现。

```text
如果不知道如何提问，请说：请使用 paper-framework-figure-studio-pro skill 根据当前状态只建议下一步提示词，不要自动执行下一步
```

Exception: S5 has no next workflow prompt. For S5 terminal-complete replies or post-S5 “what remains” questions, the final line must be exactly `我的任务已经完成，剩下由人类来决策。` and no next-step prompt should be appended.

## Strict Human-In-The-Loop Step Alternation

This rule is mandatory and applies to every runtime environment. The workflow is not an autonomous pipeline.

Initial bootstrap gate is stricter than the normal one-step rule. If the user only gives an overall goal such as "use this skill", "draw a diagram for this paper", "strictly follow the workflow", "逐步通过人机交互绘制 diagram", or provides a paper/PDF without explicitly saying "进入/执行 S0-PAPER-FOUNDATION" in the current user turn, do not execute S0. Do not read the paper, extract text, create a project, create or modify state, register artifacts, write outputs, run workflow scripts, or mark any step complete. The first reply must be plan-only: explain that S0 is the recommended first step, list missing inputs or environment assumptions, provide a copyable prompt to enter S0-PAPER-FOUNDATION, include the required design-origin prompt suggestion, and stop.

For each user turn, execute at most one explicitly requested public step. After completing that step, stop. The reply may provide the next legal copyable prompt, except after S5 where the workflow is complete. Copyable prompts are inert handoff text. Never self-consume or execute a prompt that you just wrote in the same assistant response.

Never combine adjacent public steps in one reply. In particular: S0 must not auto-run S1; S1 must not auto-generate S2 images; S2 must not auto-run S3 direction selection; S3 must not auto-run S4; S4 must not auto-generate S5 images; S5 must not auto-run anything.

Every text public-step response must explicitly close the current public step by its exact ID when that public step actually closes. At the end of S0-S4, write that the current public step is complete/ended, state that the next public step has not been executed, and provide only the next copyable prompt. S2 and S5 are image-only public stages; they do not contain text planning, text review, candidate-level revision, review, or aggregate substages.

## ChatGPT Web Text-Only Guard

For every text-only public step, the displayed copyable prompt must include:

```text
本轮纯文字：只执行文字、state、manifest、brief、audit、guidance 或 checkpoint 写入；不要生成任何图片。
```

This applies to `S0-PAPER-FOUNDATION`, `S1-FIGURE-STRATEGY`, `S3-DIRECTION-SELECT`, and `S4-CANDIDATE-BRIEF`. It also applies to embedded S2 preparation inside S1, embedded S2 audit/aggregate inside S3, and embedded S5 preparation inside S4. A later user turn may run S2 or S5 only when that later prompt is explicitly image-only.

## Public Stages

- **S0-PAPER-FOUNDATION**: text-only foundation stage. Build paper/source foundation, runtime state, framework-figure readiness state, optional author supplement request, and risk register. S0 must not design or generate images.
- **S1-FIGURE-STRATEGY**: text-only strategy stage. It must consume S0 foundation/risk register, define reader question, figure role, paper-core semantics lock, candidate strategy, style/layout matrices, core-detail display requirements, edge/port seed contracts, visible text whitelist, repetition compression plan, and the former S2 prompt preparation. S1 must output S2 prompt packages and prompt-index, then stop before S2 image generation.
- **S2-SKETCH-EXPLORE**: image-only stage. It only generates low-fidelity/whiteboard-like sketch candidates from the S1-prepared prompt-index. It must not write audit, ranking, explanation, rerun guidance, checkpoint narrative, or next-step prose.
- **S3-DIRECTION-SELECT**: text-only selection stage. It must first perform the former S2 text review and aggregate responsibilities by reading generated S2 sketches and their registry, writing issue-ledger/visual-signal summaries, recording which visual ideas are useful or risky, and creating the cumulative S3 checkpoint. Then it selects the paper-grounded refinement direction. S3 does not generate images and does not rerun S2 images.
- **S4-CANDIDATE-BRIEF**: text-only formal-brief stage. It must consume S0-S3 evidence, transfer S2 issues into S5 negative constraints, create formal candidate matrix, layout/routing/arrow contracts, text whitelist, line-carried variable registry, internal visual motif plan, caption-support plan, prompt contradiction audit, and the former S5 prompt preparation. S4 must output S5 prompt packages and prompt-index, then stop before S5 image generation.
- **S5-CANDIDATE-IMAGE**: image-only terminal stage. It only generates formal publication-schematic raster candidates from the S4-prepared prompt-index. It must not write audit, ranking, explanation, rerun guidance, assistant-continuation guidance, caption package, checkpoint narrative, or next-step prose. After S5 image generation, assistant workflow is complete.

## S0-PAPER-FOUNDATION

S0 internal responsibilities:

1. `S0-00-input-inventory`: register paper files/text, supplemental materials, user constraints, runtime, canvas defaults, and preference references.
2. `S0-01-paper-deep-read`: read source text and write `paper-foundation-report.md`.
3. `S0-02-framework-figure-risk-screen`: detect missing information, ambiguities, contradictions, unsupported lineage, opaque core modules, and scope mismatch.
4. `S0-03-author-supplement-request-or-risk-lock`: request author supplement when needed, or record risk lock if user chooses to continue.
5. `S0-04-user-response-integration`: integrate user supplements.
6. `S0-05-foundation-lock`: write `framework-figure-risk-register.md` and readiness state.
7. `S0-06-s0-to-s1-handoff`: provide the S1 copyable prompt only.

Readiness states: `S0_FOUNDATION_READY`, `S0_FOUNDATION_READY_WITH_RISK`, `S0_NEEDS_AUTHOR_SUPPLEMENT`, `S0_NOT_SUITABLE_FOR_COMPLETE_FRAMEWORK`.

## S1-FIGURE-STRATEGY — includes former S2 preparation

S1 must not merely say that S2 preparation may happen later. Before S1 closes, it must complete the old S2 preparation responsibilities as embedded duties:

- S2 candidate registry and default 8 sketch candidate cards.
- S2 orthogonal style-feature matrix and narrative/layout-divergence matrix.
- Complete-framework eligibility audit: required S2 candidates must be full-framework candidates unless the user explicitly requested scoped probes.
- Core-detail display matrix: source-grounded core contribution modules need visible internal mechanisms, not empty title boxes or bullet lists.
- Entity/artifact/symbol classification and semantic graph vs visual render graph split.
- Edge/port/arrow seed contract with direction evidence and forbidden-edge list.
- Edge-label-first and line-carried variable registry.
- Visible text whitelist and prompt contradiction audit.
- Prompt packages and `outputs/S2-sketch-explore/prompt-index.json`; default S2 ids are `C01`-`C08`, and every row must keep `candidate_id`, `prompt_path`, and `target_image_path` coherent.
- Cumulative S1 checkpoint containing all S2 prompt-preparation outputs as pending future image targets.

S1 closes by giving only the S2 image-only prompt. It must not generate S2 images.

## S2-SKETCH-EXPLORE — IMAGE_GENERATE only

S2 is a pure image-generation public stage. It reads the S1-prepared prompt-index and generates the requested sketch candidates through the environment-locked image route. S2 must keep the exact prompt-index candidate ids, read each row's `prompt_path`, and register/mirror generated raster images to the same row's `target_image_path`. S2 must not perform text planning, audit, aggregate, revision, review, ranking, or finalization.

## S3-DIRECTION-SELECT — includes former S2 review and aggregate

S3 must automatically absorb the old S2 audit/aggregate duties before direction selection:

- Read all registered S2 candidate images and prompt-index rows.
- Create issue-ledger style notes for visible problems, semantic violations, missing core internal motifs, arrow/connector confusion, variable-as-block errors, unsupported topology, excessive density, and caption-burden risks.
- Summarize visual exploration signals without treating S2 audit as a score-only ranking.
- Create the S2 exploration aggregate within the S3 report/checkpoint.
- Select the refinement direction using S0/S1 evidence, S2 visual signals, and user preference.
- Record which S2 ideas S4 should absorb, avoid, or transform.

S3 closes by giving only the S4 prompt. It must not generate images and must not rerun S2 candidates.

## S4-CANDIDATE-BRIEF — includes former S5 preparation

S4 must not merely say that S5 preparation may happen later. Before S4 closes, it must complete the old S5 preparation responsibilities as embedded duties:

- Formal candidate matrix, default 6 candidates for complete-framework tasks. Default formal ids are `F01`-`F06` unless a validated S5 prompt-index defines a different safe id set.
- S2 issue transfer into S5 negative constraints and must-fix prompt rules.
- Element layout contract, routing/arrow/port contract, text whitelist, line-carried variable registry, internal visual motif plan, and caption-support plan.
- Formal prompt contradiction audit and prompt-file-read audit.
- Prompt packages and `outputs/S5-candidate-image/prompt-index.json`; default S5 ids are `F01`-`F06`, and every row must keep `candidate_id`, `prompt_path`, and `target_image_path` coherent.
- Cumulative S4 checkpoint containing all S5 prompt-preparation outputs as pending future image targets.

S4 closes by giving only the S5 image-only prompt. It must not generate S5 images.

## S5-CANDIDATE-IMAGE — IMAGE_GENERATE only and terminal

S5 is a pure image-generation public stage. It reads the S4-prepared prompt-index and generates the requested formal candidates through the environment-locked image route. It must keep the exact prompt-index candidate ids, read each row's `prompt_path`, and register/mirror generated raster images to the same row's `target_image_path`. S5 must not write audit, ranking, explanation, caption package, rerun guidance, assistant-continuation guidance, aggregate checkpoint, or next-step prompt.

After S5, the workflow ends. If the user asks what comes next, answer exactly:

```text
我的任务已经完成，剩下由人类来决策。
```

## Image Generation Route Lock

Target paper images must be generated only through the approved image route for the runtime:

- Codex: `image_gen`.
- ChatGPT web: Create Image / ChatGPT Images 2.0.
- Other runtimes: a named approved image-generation API only when first-party routes are unavailable and the reason is recorded.

Do not use SVG, Mermaid, HTML/canvas, Python/PIL/Pillow, Matplotlib/Plotly, Graphviz, TikZ/LaTeX, PPT/PDF rendering, screenshots, SVG-to-PNG, or any local programmatic raster substitute for target paper images.

## Checkpoints And State

Every text public stage that writes a checkpoint must create a cumulative project-start-to-current restore bundle. S1 checkpoint includes S2 prompt-index as pending future image targets. S3 checkpoint includes S2 generated-image registry plus embedded S2 audit/aggregate summaries and direction selection. S4 checkpoint includes S5 prompt-index as pending future image targets. S2 and S5 are image-only stages; they register image generation events and active image paths but do not create text aggregate checkpoints.

State files and registries must store relative paths only. Never add target-project paper facts, module names, datasets, claims, generated candidate summaries, output paths, or audit conclusions to the reusable skill package.

Useful state commands. When a prompt-index exists, pass it to `plan-substages` or rely on the default prompt-index path so candidate ids come from the prompt-index rather than from stage defaults:

```bash
python scripts/figure_studio_state.py plan-substages --project-id <project_id> --step S2-SKETCH-EXPLORE --runtime chatgpt_web --prompt-index outputs/S2-sketch-explore/prompt-index.json
python scripts/figure_studio_state.py scan-substages --project-id <project_id> --step S2-SKETCH-EXPLORE
python scripts/figure_studio_state.py recommend-next-action --project-id <project_id> --step S5-CANDIDATE-IMAGE
python scripts/figure_studio_state.py register-image-batch --project-id <project_id> --step S2-SKETCH-EXPLORE --batch-id <batch_id> --prompt-index outputs/S2-sketch-explore/prompt-index.json --use-target-image-paths --output-dir outputs/S2-sketch-explore/registered-generated-images --source <generated_png> --generation-event-id <event_id> --replace
python scripts/figure_studio_state.py create-checkpoint --project-id <project_id> --stage S4-CANDIDATE-BRIEF --checkpoint-type stage-final --sequence 1
python scripts/figure_studio_checkpoint_guard.py --run-dir figure-studio-runs/<project_id> --stage S4-CANDIDATE-BRIEF --zip checkpoints/S4-CANDIDATE-BRIEF/stage-final-0001.zip --fail-on-error
python scripts/figure_studio_state.py doctor --project-id <project_id>
```

## On-Demand Reference Loading

Keep this `SKILL.md` as the short controller. Load detailed references only when the current request needs them:

- `references/workflow-and-state-contract.md`
- `references/architecture-governance-contract.md`
- `references/module-orchestration-contract.md`
- `references/human-step-execution-contract.md`
- `references/image-generation-route-hardening-policy-v325.md`
- `references/paper-deep-reading-contract.md`
- `references/s0-foundation-readiness-and-candidate-status-policy-v316.md`
- `references/startup-preference-and-environment-contract.md`
- `references/startup-style-lens-decision-policy-v315.md`
- `references/prompt-generation-policy.md`
- `references/file-reference-prompt-handoff-policy-v324.md`
- `references/semantic-graph-prompt-contract-policy-v326.md`
- `references/framework-abstraction-flowline-and-rerun-prompt-policy-v328.md`
- `references/academic-framework-hierarchy-and-asset-mirroring-policy-v3210.md`
- `references/edge-label-first-and-internal-motif-policy-v3211.md`
- `references/paper-core-semantics-and-prompt-contract-policy-v323.md`
- `references/source-grounded-prompt-audit-and-style-policy-v320.md`
- `references/visual-information-economy-and-repetition-control-policy-v322.md`
- `references/first-round-diversity-matrix-policy.md`
- `references/s2-s5-layout-routing-prompt-audit-policy-v317.md`
- `references/first-glance-layout-sanity-policy-v318.md`
- `references/s2-sketch-mode-core-detail-area-policy.md`
- `references/choice-prompt-policy.md`
- `references/response-prompt-options-policy.md`
- `references/s2-s5-image-only-terminal-orchestration-policy-v3215.md`
- `references/candidate-artifact-id-coherence-policy-v3215.md`
- `references/substage-user-guidance-policy-v316.md`
- `references/continue-next-action-policy-v316.md`
- `references/chatgpt-web-checkpoint-bundle-policy.md`
- `references/figure-caption-codesign-policy-v311.md`
- `references/figure-caption-symbiosis-policy-v314a.md`
- `references/candidate-issue-ledger-and-caption-burden-policy-v324.md`
- `references/core-submodule-detail-policy-v313.md`
- `references/semantic-lineage-dual-use-policy-v315.md`
- `references/connector-provenance-and-area-budget-policy-v315-hotfix.md`
- `references/s2-model-contract-and-audit-policy-v315-hotfix.md`
- `references/security-and-portability-policy.md`
- `references/step-rewind-cleanup-contract.md`
