# Changelog

## v3.2.15 — Candidate / Artifact ID Coherence

- Adds a generic candidate-id coherence policy across S2/S5 prompt-index rows, prompt paths, target image paths, stage manifests, substage candidate ids, candidate registries, artifact records, image-generation events, outputs, and checkpoint image inventories.
- Makes prompt-index `candidate_id` the source of truth after S1/S4 preparation; scripts must not renumber formal S5 images as Cxx or raw numeric ids when the prompt-index uses Fxx or another safe id family.
- Updates S5 formal candidate defaults to F01-F06 while preserving S2 C01-C08 defaults and accepting any validated prompt-index ids.
- Updates prompt-index helpers to normalize both legacy object-shaped candidate maps and canonical ordered candidate lists.
- Updates starter/copyable prompts so they say “请使用 paper-framework-figure-studio-pro skill” rather than referring to a versioned zip package.
- Adds `references/candidate-artifact-id-coherence-policy-v3215.md` and `references/s2-s5-image-only-terminal-orchestration-policy-v3215.md`.

## v3.2.14 — Fixed Candidate Contract Without User-Exposed Mode

- Removes the user-facing contract-check setting from startup guidance, copyable prompts, project state templates, and policy references.
- Keeps the fixed candidate contract behavior internal: S1/S4 prepare strict prompt contracts; S3 reviews and aggregates S2; S2/S5 remain image-generation-only; S5 remains terminal.
- Replaces the old contract-check-mode reference with `references/fixed-candidate-contract-policy-v3214.md`.
- Updates scripts, metadata, templates, and release text so users are not invited to modify a single-option setting.

## v3.2.13 — Terminal Image-Only S2/S5 Workflow

- Changes the main workflow to: S0 -> S1 -> S2 -> S3 -> S4 -> S5 -> END.
- Makes S2 and S5 image-generation-only public stages.
- Moves former S2 prompt preparation into S1 as a mandatory responsibility.
- Moves former S2 image audit and exploration aggregate into S3 as mandatory responsibilities before direction selection.
- Moves former S5 prompt preparation into S4 as a mandatory responsibility.
- Removes S2/S5 candidate-level rerun and review.
- Removes S2/S5 standalone aggregate substages.
- Removes all assistant workflow after S5. After S5, remaining selection, revision, captioning, and paper integration are human decisions.
- Removes future-image-stage parity based on the old dynamic text-image substage template.
- Introduced the fixed candidate contract behavior that v3.2.14 later made non-user-configurable.
- Adds `references/s2-s5-image-only-terminal-orchestration-policy-v3213.md`.
- Updates state schema, metadata, examples, templates, architecture assets, and scripts for terminal S5 behavior.

## v3.2.12 — S2 Narrative Strategy And Layout Divergence Hardening

- Added generic S2 narrative-strategy and layout-divergence gates so first-round sketches test different method-story explanations rather than near-duplicate layouts.

## v3.2.11 — Edge-Label-First And Internal Motif Hardening

- Added edge-label-first rendering, semantic-vs-visual graph separation, line-carried variable registries, and internal visual motif requirements for core compound modules.

## v3.2.10 — Academic Hierarchy And Image Mirror Hardening

- Added academic framework hierarchy, connector bundling/edge economy, and stage-local image mirror requirements without paper-specific hardcoding.

## v3.2.9 — Cumulative Checkpoint Integrity

- Added cumulative checkpoint integrity validation for restore bundles.

## v3.2.8 And Earlier

- Added framework abstraction, entity-density control, flowline semantics, semantic graph prompt contracts, image-route hardening, caption symbiosis, and S0 readiness policies.
