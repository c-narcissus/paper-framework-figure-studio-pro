# Patch Report v3.2.9 — Generic Substage Cumulative Checkpoint Guard

## Scope

This patch updates the reusable skill, not any single project run. It is paper-agnostic and contains no project id, paper title, candidate id, module label, or expected image filename assumptions.

## Problem generalized

Dynamic workflows can create substage or chunk checkpoints during embedded prompt preparation, IMAGE_GENERATE, embedded image review, rerun, or aggregate pages. A checkpoint may be named as a chunk but still be expected to restore the entire run. If a substage page packages only the current substage folder, a later resume loses earlier stages even though the checkpoint link appears valid.

## Solution

- Added `references/substage-cumulative-checkpoint-integrity-policy-v329.md`.
- Added `scripts/figure_studio_checkpoint_guard.py`.
- Updated core checkpoint policy references and state schema.
- Required every substage checkpoint page to write/retain a checkpoint integrity report.
- Added a bounded validate → rebuild → validate mechanism for single-zip checkpoints.
- Required per-root coverage checking using roots discovered from project state/workflow output directories.
- Preserved pending-future semantics: planned but not-yet-generated assets do not block restore.

## Guard command template

```bash
python scripts/figure_studio_checkpoint_guard.py \
  --run-dir <project_run_dir> \
  --current-stage <current_public_stage_id> \
  --substage-id <optional_internal_substage_id> \
  --zip <checkpoint_zip_path> \
  --report-path <checkpoint_dir>/checkpoint-integrity-report.json \
  --rerun \
  --max-attempts 2
```

The command is intentionally parameterized. It must be supplied values from state/manifests/runtime, not hard-coded values from a particular project.

## Validation performed

- Basic script syntax/import check.
- Generic fake-run test: a current-substage-only zip was detected as incomplete, rebuilt, and revalidated as cumulative.
- Release path scan.
- Architecture audit.

## Non-hardcoding audit

The new policy and script do not contain task-specific terms, paper names, candidate ids, or expected image names.
