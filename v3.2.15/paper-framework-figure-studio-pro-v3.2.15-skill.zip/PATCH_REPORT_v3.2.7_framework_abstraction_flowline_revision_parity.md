# Patch Report v3.2.7 — Framework Abstraction, Flowline Semantics, And Rerun-Prompt Parity

## Scope

This patch is generic skill-policy hardening. It does not bind the reusable skill to any target paper, method, dataset, candidate image, project ID, or uploaded example. It extracts general failure modes from user feedback and converts them into portable prompt/audit rules.

## Generalized failure modes addressed

1. **Intermediate variables promoted to visual modules.** Prompt packages now classify symbols and variables before node creation. Pass-through quantities default to edge/port labels or attached tags.
2. **Framework diagrams over-decomposed into micro-boxes.** Prompt packages now require an element granularity plan so framework-level figures merge low-level details into compound modules when possible.
3. **Unsupported module inputs.** Prompt packages now require module input contracts; arrows into a module must have source-grounded eligibility.
4. **Duplicate or redundant source-target arrows.** Prompt packages now require an edge cardinality audit and merge/split connector plan.
5. **Ambiguous arrows.** Every connector now carries explicit flow semantics such as data/artifact, model-state/reference, control/gating, evaluation/metric, communication/exchange, dependency, callout, or next-round reuse.
6. **S5 or rerun prompt drift.** S2/S5 and explicit rerun prompts share the same semantic baseline; rerun prompts must carry forward the original graph/edge/symbol/granularity contracts.

## Files changed

- Added `references/framework-abstraction-flowline-and-rerun-prompt-policy-v327.md`.
- Updated `SKILL.md` to mention v3.2.7 and enforce S2/S5 semantic baseline parity.
- Updated `references/semantic-graph-prompt-contract-policy-v326.md` to v3.2.7 wording with symbol/edge-label and flow semantics fields.
- Updated `references/s2-s5-layout-routing-prompt-audit-policy-v317.md` to v3.2.7 prompt-package order and audit checks.
- Updated `references/s2-s5-dynamic-substage-orchestration-policy-v316.md` with semantic contract parity and rerun-prompt parity.
- Updated `references/candidate-issue-ledger-and-caption-burden-policy-v324.md` issue categories.
- Updated `references/visual-information-economy-and-repetition-control-policy-v322.md` with symbol/micro-operation compression.
- Updated `README.md`, `CHANGELOG.md`, `VERSION`, `metadata.json`, and `agents/openai.yaml`.

## Backward compatibility

- The public workflow remains unchanged. No new public stage is introduced.
- S2 remains low-fidelity by default; S5 remains formal/polished by default.
- The fixed candidate contract policy still omits heavy S2/S5 per-candidate connector/area enumeration, but it no longer permits S2/S5 prompt packages or rerun prompts to skip symbol classification, flow semantics, module-input contracts, duplicate-edge checks, or granularity planning.
