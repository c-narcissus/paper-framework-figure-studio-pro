# Preference Reference Transfer Policy

Uploaded or registered style preference references are analyzed for S1-FIGURE-STRATEGY figure-type and reader-effect suggestions.

After S5, human decisions are outside this assistant workflow.

If the user later selects or restates a style preference as an explicit requirement, record it as a user decision and carry it forward. Do not infer it silently from uploaded examples.

Preference references can inspire visual grammar, not source-paper facts.
