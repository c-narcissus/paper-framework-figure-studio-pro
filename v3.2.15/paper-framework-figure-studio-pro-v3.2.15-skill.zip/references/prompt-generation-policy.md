# Prompt Generation Policy v3.2.13

Long image prompts must be saved to files and referenced through `prompt-index.json`; user-visible handoff text must not inline full multi-candidate prompts.

S1 prepares S2 sketch prompts. S4 prepares S5 formal-candidate prompts. S2 and S5 only read those prompts and generate images using the environment-locked image route.

Prompt packages must remain paper-grounded: semantic graph and visual render graph are separated, visible text is whitelisted, edge direction is evidence-backed, variables/metrics/weights default to line/port labels, and core modules include pictorial internal motifs.

No prompt generation stage exists after S5.
