# Framework Abstraction, Flowline Semantics, And Rerun-Prompt Parity Policy v3.2.7

Use this policy whenever S2/S5 prepares or audits a framework, architecture, pipeline, method-overview, workflow, mechanism, data-flow, model-flow, or rerun image prompt. It is generic and paper-agnostic. It must not encode facts from a particular paper, dataset, method family, user project, uploaded image, or prior run. Project outputs may instantiate these rules with the current paper's own evidence and terms only.

## Purpose

Framework figures must show the method's semantic structure at an appropriate abstraction level. They should not turn every intermediate variable, temporary output, scalar, threshold, metric, or edge annotation into a separate visual module. They must also make each arrow's meaning explicit in the prompt contract so audits can compare the image against the paper/source evidence.

This policy closes four common prompt failures:

1. treating pass-through symbols or intermediate variables as boxed modules;
2. over-decomposing a framework into many equally weighted micro-boxes;
3. drawing unsupported or duplicate arrows because a variable appears near a module;
4. weakening S5 or upstream rerun prompts relative to S2 by omitting graph, line-type, or source-evidence checks.

## Entity / Artifact / Symbol Classification Gate

Before writing `node_registry`, classify every planned visible item with `visual_semantic_class`:

| Class | Meaning | Default visual treatment |
| --- | --- | --- |
| `actor_or_context` | paper-defined participant, condition, environment, or repeated population marker | compact chip/container/context marker |
| `module_or_operation` | transformation, training step, aggregation step, inference step, model, or mechanism with a semantic role | visible module/card/gate |
| `material_artifact` | data/model object that is produced, stored, branched, reused, evaluated, or mixed as a distinct object | visible artifact token only when needed for branching or lineage |
| `inline_symbol` | scalar, variable, temporary output, pseudo-output, score, loss, threshold, edge annotation, or pass-through quantity | line label / port label / small inline tag, not a standalone box by default |
| `control_parameter` | threshold, schedule, hyperparameter, control signal, or gate condition | merge into the controlled gate/module or show as a small attached tag; not equal-weight module by default |
| `caption_only` | useful but not necessary for first-glance pixel meaning | move to caption/legend/body text |

`inline_symbol` and `control_parameter` items must not become standalone nodes unless the current paper and reader path require visible branching, comparison, or reuse. When kept as visible text, they should normally be rendered as **edge labels, port labels, or small tags attached to a module**.

Required prompt-package field:

```yaml
symbol_entity_classification:
  - paper_term_or_symbol: <current-paper term>
    visual_semantic_class: actor_or_context | module_or_operation | material_artifact | inline_symbol | control_parameter | caption_only
    planned_rendering: node | edge_label | port_label | attached_tag | grouped_token | caption_only | removed
    node_exception_reason: <required only if inline_symbol/control_parameter becomes a node>
    evidence_anchor: <paper/S0/S1/S4/source anchor>
```

## Variables And Intermediate Outputs As Edge Labels

A variable-like output should be drawn on the connector that carries it, rather than as its own box, when all of the following hold:

- it is produced by one module and immediately consumed by one or more known downstream modules;
- it has no internal mechanism to show;
- it is not a persistent store, model, actor, or paper-primary object whose visual identity matters;
- making it a box would add clutter or imply an extra processing step.

Use a compact connector label such as `<symbol>` near the arrow, or a merge connector with multiple inline labels. This applies generically to pseudo-label variables, latent variables, logits, scores, losses, weights, probabilities, masks, schedules, small validation subsets, scalar metrics, and similar mathematical quantities. If such an item branches to two consumers, use one labeled split connector, not two duplicated variable boxes unless the artifact is explicitly a material object.

Required prompt-package field:

```yaml
edge_annotation_registry:
  - annotation_id: A_...
    text: <visible mathematical symbol or short phrase>
    attaches_to_edge_ids: [E_...]
    annotation_role: carried_data | carried_model_state | control_value | evaluation_value | branch_label | caption_only
    render_mode: inline_edge_label | port_tag | merge_label | no_visible_label
    evidence_anchor: <paper/S0/S1/S4/source anchor>
```

The visible-text whitelist must distinguish `visible_node_labels` from `visible_edge_or_port_labels`. A symbol may be whitelisted for an edge label without authorizing a separate visible box.

## Framework-Level Granularity Gate

Before saving any S2/S5 image prompt, create an `element_granularity_plan`. The plan decides which source-grounded details deserve full module boxes and which should be merged, attached, line-labeled, or moved to caption.

Required field:

```yaml
element_granularity_plan:
  figure_role: framework_overview | architecture | pipeline | mechanism_explainer | scoped_detail | comparison
  granularity_target: coarse | medium | detailed
  elements:
    - paper_term: <current-paper term>
      source_role: core_module | substep | parameter | intermediate_symbol | artifact | metric | context | constraint
      planned_rendering: full_node | compound_module_internal_token | attached_tag | edge_label | grouped_icon | caption_only | removed
      merge_group: <optional compound module id>
      why_this_level: <reader-path and evidence reason>
      clutter_risk: low | medium | high
```

A framework overview should prefer **compound modules with a few internal tokens** over separate equal-weight boxes for every substep. Split a substep into a standalone node only when it has a distinct source-supported input/output, branch, evaluation role, or reader-critical mechanism. Otherwise keep it in the parent module as an icon, stacked micro-token, attached tag, or caption phrase.

Micro-operation pairs that function as a gate/parameter pair should generally be rendered as one compound gate with an attached control tag. Do not separate a threshold from its filter, a schedule from its sampler, a confidence score from its selector, or a local hyperparameter from its controlled module unless the current paper's source evidence makes that separation necessary for the figure's main question.

## Flowline Semantic Typing

Every line, arrow, connector, bracket, callout, merge, split, loop, and feedback relation in S2/S5 prompt packages must have a `flow_semantics` field. The image prompt must state the flow semantics in words even when the final pixels will not visibly print those words.

Allowed baseline types:

```text
data_or_artifact_flow
model_state_or_reference_flow
control_or_gating_flow
evaluation_or_metric_flow
communication_or_exchange_flow
conceptual_dependency
containment_or_grouping
callout_or_zoom
next_round_or_reuse
no_arrow_association
```

For each edge, record:

```yaml
flow_semantics_registry:
  - edge_id: E_...
    flow_semantics: data_or_artifact_flow | model_state_or_reference_flow | control_or_gating_flow | evaluation_or_metric_flow | communication_or_exchange_flow | conceptual_dependency | containment_or_grouping | callout_or_zoom | next_round_or_reuse | no_arrow_association
    visible_line_style: solid | dashed | dotted | bracket | no_arrow_grouping
    visible_arrowhead: target | both | none
    should_visible_label_flow_type: false
    prompt_wording: <plain-language line/arrow meaning for image generator>
    evidence_anchor: <paper/S0/S1/S4/source anchor>
```

Stage prompts must avoid vague connector instructions. Write prompts with statements like `solid arrow meaning local data/artifact flow`, `dashed arrow meaning exchanged model state/reference`, or `dotted arrow meaning control/next-round reuse`. The words need not be printed in the figure unless deliberately whitelisted.

## Direction And Input-Eligibility Gate

A module input is legal only when the paper, algorithm, equation, source-grounded S0/S1/S4 contract, or author clarification supports both the relation and direction. Do not route a data item into a module merely because it is visually nearby, belongs to the same local client, or appears elsewhere in the method.

For every module, record `module_input_contract`:

```yaml
module_input_contract:
  - module_node_id: N_...
    module_display_label: <visible label>
    allowed_input_families:
      - data_or_artifact_flow
      - model_state_or_reference_flow
      - control_or_gating_flow
      - evaluation_or_metric_flow
    allowed_inputs:
      - source_node_or_annotation: <node id or annotation id>
        role: <why it enters this module>
        evidence_anchor: <paper/S0/S1/S4/source anchor>
    forbidden_inputs:
      - source_node_or_annotation: <unsupported input>
        reason: <why drawing it would be misleading>
```

If an item is relevant context but not an input, show it as a nearby context chip, bracket, or caption-only note rather than an arrow into the module.

## Edge Cardinality And Duplicate-Line Gate

A prompt must not create duplicate arrows between the same source and target with the same direction, line style, and semantics. Duplicate or converging lines are allowed only when they carry different source-supported roles, distinct artifacts, distinct model states, or intentionally separate lanes.

Required audit field:

```yaml
edge_cardinality_audit:
  duplicate_source_target_pairs: []
  duplicate_allowed_with_distinct_roles: []
  merge_or_split_connectors_used: [<edge ids or connector family ids>]
  redundant_edge_fix: remove | merge | convert_to_inline_label | route_to_caption | not_needed
```

When two variable labels feed the same module as alternative or joint inputs, prefer a single merge connector with inline labels, or one multi-input gate. Do not draw two identical arrows from the same variable/source into the same module unless the source evidence says they are separate roles.

## Post-S5 Boundary Removed In v3.2.13

After S5, human decisions are outside this assistant workflow.

- source-grounded element support;
- entity/artifact/symbol classification;
- element granularity plan;
- visible node-label vs edge-label whitelist separation;
- exact edge registry with `flow_semantics`;
- module input contract;
- edge cardinality audit;
- forbidden-edge/topology checks;
- prompt-file-read audit when prompts are file-handoff assets.

After S5, human decisions are outside this assistant workflow.

## Rerun Prompt Parity

After S5, human decisions are outside this assistant workflow.

Required rerun fields:

```yaml
rerun_prompt_parity_audit:
  source_prompt_path: <path>
  source_prompt_hash: <hash>
  issue_ledger_path: <path>
  semantic_graph_spec_carried_forward: true|false
  visible_text_whitelist_carried_forward: true|false
  edge_annotation_registry_carried_forward: true|false
  flow_semantics_registry_carried_forward: true|false
  element_granularity_plan_carried_forward: true|false
  module_input_contract_carried_forward: true|false
  rerun_delta_only_changes_listed_issues: true|false
  no_new_uncontracted_elements_or_edges: true|false
  stage_style_preserved_or_explicitly_authorized: true|false
```

Rerun image prompts must say which errors to remove, but they must also restate the core allowed structure, edge semantics, symbol-as-edge-label rules, and forbidden shortcuts. Do not pass a upstream rerun prompt that only says "fix the arrows", "make it cleaner", "remove clutter", or "correct the wrong module" without rebuilding the full prompt contract.

## Audit Additions

S2/S5 text reviews must add issue categories for:

- `symbol_as_box_error`: intermediate variables or control values became full modules without justification;
- `over_decomposition`: framework-level figure split too many micro-operations into equal-weight boxes;
- `unsupported_module_input`: an arrow enters a module without evidence-supported input eligibility;
- `duplicate_edge`: redundant edge(s) share the same source, target, semantics, and role;
- `flow_semantics_mismatch`: drawn line style or direction contradicts its intended data/model/control/evaluation semantics;
- `rerun_contract_drift`: explicit upstream rerun prompt or reruned image lost the original semantic contract.

These categories are generic; the audit description should instantiate them with the current paper's terms in project outputs only.

## Non-Hardcoding And Portability

This policy must remain project-neutral. It must not name a target paper, dataset, method, author, project ID, user file path, generated candidate ID, or uploaded example as reusable doctrine. It defines checks and fields. Current-run reports may cite current-paper variables or examples, but reusable skill files must not bake them in.
