# S1/S2 Strategy And Sketch Module v3.2.15

S1 is the strategy stage and now also owns all former S2 prompt-preparation responsibilities.

S1 must prepare:

- reader question and figure role;
- paper-core semantics lock;
- S2 candidate cards;
- S2 narrative/layout divergence matrix;
- source-grounded text whitelist;
- edge/port/arrow contracts;
- line-carried variable registry;
- semantic graph versus visual render graph split;
- internal visual motif plan for core compound modules;
- prompt contradiction audit;
- `outputs/S2-sketch-explore/prompt-index.json`;
- candidate/artifact ID coherence: every S2 prompt-index row must preserve the same `candidate_id` across `prompt_path`, `target_image_path`, registry keys, artifacts, status files, and checkpoint inventories.

S2 is image generation only. It reads the S1-prepared prompt-index, maps generated images by exact prompt-index row order, mirrors each image to the same row `target_image_path`, and creates low-fidelity sketch candidates through the approved image route. It does not audit, rerun, rank, aggregate, or hand off.
