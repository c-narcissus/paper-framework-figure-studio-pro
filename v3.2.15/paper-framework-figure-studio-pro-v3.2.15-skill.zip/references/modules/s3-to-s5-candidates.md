# S3 To S5 Candidate Module v3.2.15

S3 must first review and aggregate S2 sketches, then select direction.

S3 responsibilities:

- inspect registered S2 images;
- record issue-ledger and visual-signal summaries;
- transfer useful/risky S2 findings to S4;
- choose the refinement direction.

S4 is the formal candidate brief stage and now also owns all former S5 prompt-preparation responsibilities.

S4 must prepare:

- formal candidate matrix;
- S2 issue transfer and negative constraints;
- formal layout/routing/arrow contracts;
- visible text whitelist;
- line-carried variable registry;
- internal visual motif plan;
- prompt contradiction audit;
- `outputs/S5-candidate-image/prompt-index.json`;
- candidate/artifact ID coherence: every S5 prompt-index row must preserve the same `candidate_id` across `prompt_path`, `target_image_path`, registry keys, artifacts, status files, and checkpoint inventories. Default formal IDs are F01-F06, not C01-C06.

S5 is image generation only and terminal. It reads the S4-prepared prompt-index, maps generated images by exact prompt-index row order, mirrors each image to the same row `target_image_path`, generates formal candidates through the approved image route, and then assistant workflow ends.
