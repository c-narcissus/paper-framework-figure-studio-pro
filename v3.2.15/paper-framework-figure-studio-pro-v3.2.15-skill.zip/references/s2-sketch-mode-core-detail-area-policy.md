# S2 Sketch Mode Core Detail Area Policy v3.2.3

S2 sketches are low-fidelity exploration images, not formal selected figures. They must still preserve paper-grounded core mechanisms, visible internal anchors for non-droppable contributions, and evidence-backed arrow directions.

After S5, human decisions are outside this assistant workflow.

## Default S2 Visual Fidelity

Unless the user explicitly requests another compatible style, S2 image prompts should request an exploratory sketch or wireframe: rough/hand-drawn or whiteboard-like lines, coarse boxes, sparse labels, simple glyphs, obvious whitespace, and a visible layout-study feel. S2 prompts should not ask for final-polished vector schematics, dense precision blueprint grids, publication-ready diagrams, photorealistic scenes, or detailed dashboard pages unless the candidate is explicitly a controlled stress test and still passes sparsity, first-glance, repetition, and edge-contract gates.

## S2 Semantic Contract Still Applies

Low fidelity reduces rendering polish; it does not reduce scientific fidelity. S2 embedded prompt preparation must still compile:

- `paper_core_semantics_lock`;
- `role_flow_separation_table` when repeated/variant families exist;
- `core_detail_display_matrix` for non-droppable modules;
- `edge_whitelist_and_port_contract`;
- `density_and_whitespace_budget`;
- `element_instance_budget` and `repeated_flow_compression_plan` when repetition exists.

A sketch that is visually loose but contains unsupported modules, wrong labels, uncontracted arrows, repeated equivalent full pipelines, or misleading detail panels must be flagged or blocked in S2 audit.

## Default Hand-Drawn S2 Style Reinforcement v3.2.4

S2 default means a hand-drawn / whiteboard-like exploratory sketch unless the user explicitly requests another compatible style. The image prompt should include words such as `low-fidelity`, `hand-drawn`, `whiteboard sketch`, `wireframe`, `rough but readable lines`, `coarse boxes`, `sparse labels`, and `layout study`. Do not default to refined formal vector, publication-ready, poster, dashboard, or polished infographic phrasing in S2.
