# Skill Patch Report — paper-framework-figure-studio-pro v3.2.3

## Purpose

Patch the reusable skill so prompt generation and audits derive layout, repetition, arrow contracts, and stage style from the current paper's semantic backbone, rather than from paper-specific examples, style templates, or flawed generated candidates.

## Key changes

1. Added `references/paper-derived-semantic-backbone-and-nonhardcoded-compression-policy-v323.md`.
2. Added required `paper_semantic_spine_contract` to S2/S5 prompt packages.
3. Added actor/condition variation matrix and shared-vs-distinct flow decision procedure.
4. Required project-derived edge source contracts and port binding; no reusable paper-specific connector lists.
5. Added S2 rough exploratory sketch-mode style contract, with hand-drawn/whiteboard preservation when requested.
6. Added S4/S5/deleted assistant workflow after S5 semantic fault scrub so selected generated images are only visual references and cannot carry unsupported arrows, modules, or redundant full lanes forward.
7. Updated SKILL, prompt-generation, source-grounded audit, layout/routing, repetition-control, edge-cardinality, complete-framework, deleted assistant workflow after S5, and review-rubric policies.

## Non-hardcoding guard

The patch does not add any target-paper roles, modules, variables, datasets, or connector sequences. Concrete names and edges must be extracted per project from that paper's S0/S1/S4 evidence.
