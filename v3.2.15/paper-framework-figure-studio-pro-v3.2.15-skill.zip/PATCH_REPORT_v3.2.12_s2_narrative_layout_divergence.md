# Patch Report v3.2.12 — S2 Narrative Strategy And Layout Divergence

## Motivation

A first-round S2 batch can become unhelpful when all candidates use the same module order, the same full edge list, the same whiteboard rendering style, and only weakly different labels such as "hourglass", "swimlane", or "cycle". The resulting images may be near-duplicates, and rough sketch style can be mistaken for permission to produce disordered layouts.

This patch generalizes the fix. It is not tied to any target paper, method family, dataset, module name, or variable name.

## Generic Changes

- Added `references/s2-narrative-layout-divergence-policy-v3212.md`.
- Reframed S2 first-round style variation as narrative/explanation-strategy variation.
- Added required `narrative_strategy_vector` fields for S1 candidate cards and S2 prompt packages.
- Added batch-level `s2_layout_divergence_matrix` and pairwise layout divergence gate.
- Added `layout_projection` so a shared semantic graph can be rendered differently across candidates by changing primary/secondary/context/caption edge priorities.
- Added hard `layout_grammar_block` requirements: canvas partition, anchors, region weights, route corridors, scan order, non-overlap, edge bundling, and anti-similarity directives.
- Added S2 audit checks for individual layout sanity and batch narrative diversity.
- Updated S1-S2 module, prompt generation policy, layout routing prompt audit policy, first-glance layout sanity policy, and prompt template.

## Non-Hardcoding Boundary

Reusable skill files describe only procedure, fields, gates, and generic role families. They do not include target-paper module names, variables, datasets, or project-specific corrections. Project outputs may instantiate the fields using current paper evidence and risk registers.

## Expected Behavior Change

S2 embedded prompt preparation should no longer produce eight prompts that all ask for the same full pipeline in roughly the same layout. It should produce prompts that test different faithful storytelling strategies: macro backbone, actor-centered zoom, artifact lineage, model-state lifecycle, multi-space balance, signature mechanism reveal, problem-solution storyboard, evidence/comparison story, or dense contract stress test, as appropriate to the paper.

S2 IMAGE_GENERATE should receive much stronger layout instructions, reducing visually similar and disordered sketch outputs.
