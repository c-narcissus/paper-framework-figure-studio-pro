# Patch Report v3.2.9 — Generic Cumulative Checkpoint Integrity Guard

## Scope

This patch updates `paper-framework-figure-studio-pro` from v3.2.8 to v3.2.9.
The change is generic and reusable. It does **not** encode any target paper, project id, module name, variable name, candidate id, image count, or task-specific file list.

## Problem addressed

Dynamic text/image substages can accidentally emit a checkpoint-like zip that contains only the current substage output folder while earlier completed stage outputs already exist. Such a zip is not restore-complete and must not be described as a cumulative checkpoint.

## General solution

v3.2.9 adds a cumulative checkpoint integrity guard for every checkpoint-producing public stage, dynamic substage, future/custom image stage, rerun/review unit, aggregate unit, and deleted assistant workflow after S5 internal unit.

The guard verifies that:

- checkpoint scope is cumulative from project start through the requested stage/substage;
- `checkpoint-manifest.json` is present;
- `included_roots` covers state/input roots and every completed/current output root through the requested stage;
- every already-existing file under those roots is present in the zip or zip-part union;
- generated/registered raster assets that should exist are present;
- planned future outputs are pending assets/images rather than missing restore blockers;
- a saved `checkpoint-cumulative-integrity.json` report records cumulative root coverage, required existing asset counts, substage page assets, missing-page status, bounded rebuild attempts, and final restore status.

If the guard fails, the workflow must rebuild the checkpoint from cumulative roots and rerun the guard up to a bounded attempt limit. If the guard still fails, the checkpoint must be marked `incomplete_restore_blocked`, not `complete_restore_ready`.

## Substage-page checkpoint checks

Checkpoint-producing substage pages now have an explicit integrity section. Existing substage pages are discovered generically from:

- `project-state.json` substage records;
- `substage_guidance_registry` rows;
- prompt index / rerun prompt index / final prompt index files when present;
- stage manifest files;
- current-stage output files whose path fragments match the current substage id.

The detection is deliberately generic. It derives page assets from state, guidance records, stage roots, and substage-id fragments. It does not rely on paper names, project names, candidate ids, fixed candidate counts, or fixed run-specific filenames.

## Files changed

- `SKILL.md`
  - version updated to 3.2.9;
  - checkpoint rule now requires substage-page checkpoint integrity sections and the v3.2.9 guard policy.
- `README.md`
  - version updated to 3.2.9 and summarizes cumulative checkpoint guard behavior.
- `VERSION`
  - set to `3.2.9`.
- `metadata.json`
  - version and checkpoint policy updated.
- `CHANGELOG.md`
  - added v3.2.9 entry.
- `agents/openai.yaml`
  - version and critical checkpoint rule updated.
- `references/cumulative-checkpoint-integrity-guard-policy-v329.md`
  - new paper-agnostic checkpoint integrity policy.
- `references/cumulative-restore-checkpoint-policy-v318-hotfix.md`
  - refreshed with mandatory integrity guard requirements.
- `references/chatgpt-web-checkpoint-bundle-policy.md`
  - refreshed with substage-page checkpoint guard requirements.
- `scripts/figure_studio_checkpoint_guard.py`
  - standalone paper-agnostic validator/rebuilder.
- `scripts/figure_studio_state.py`
  - `create-checkpoint` now supports `--substage-id` and bounded `--checkpoint-validation-attempts`.
- `scripts/figure_studio_core/substages.py`
  - checkpoint creation discovers required substage pages, validates cumulative root coverage, writes `checkpoint-cumulative-integrity.json`, repacks that report into the final zip/parts, and blocks complete-status wording when integrity fails.

## Non-hardcoding audit

The checkpoint guard derives expected coverage from workflow state, workflow order, existing project-run-relative roots, registries, and zip members. It does not refer to any paper-specific terms, project-specific output names, fixed candidate IDs, image totals, or concrete task files.

## Validation

- Python syntax compilation passed for modified scripts.
- Synthetic S5 chunk checkpoint smoke test passed: the generated zip contained state plus existing outputs from S0, S1, S2, S3, S4, and S5.
- The generated `checkpoint-cumulative-integrity.json` recorded the current substage id, required substage page path(s), complete root coverage, and `complete_restore_ready`.
- Standalone guard script passed on the smoke-test checkpoint.
- Architecture audit passed.
- Release path scan passed.
