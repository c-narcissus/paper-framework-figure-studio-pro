# Patch Report v3.2.10 — Academic Hierarchy And Asset Mirror Hardening

## Scope

This patch generalizes recent framework-figure feedback into reusable, paper-agnostic skill rules. It does not encode any target-paper facts, variable names, datasets, module names, candidate ids, or project-specific fixes.

## Added

- `references/academic-framework-hierarchy-and-asset-mirroring-policy-v3210.md`
  - `visual_hierarchy_plan`
  - paper-derived `primary_module_whitelist`
  - `artifact_block_guard`
  - `connector_bundling_plan`
  - `academic_layout_hierarchy_gate`
  - stage-local image mirror and generated-image escrow policy
- New audit categories:
  - `artifact_as_block_error`
  - `variable_as_block_error`
  - `hierarchy_flattening`
  - `micro_node_overproduction`
  - `unbundled_parallel_edges`
  - `unlabeled_parallel_edges`
  - `edge_label_missing`
  - `line_semantics_ambiguous`
- `register-image-batch` prompt-index mirroring support:
  - `--prompt-index`
  - `--use-target-image-paths`
  - `--target-path-field`

## Changed

- `SKILL.md`
  - Version updated to `3.2.10`.
  - S1/S2/S3/S4/S5 now must apply the new hierarchy/mirroring policy in addition to v3.2.8 flowline semantics and v3.2.9 checkpoint integrity.
  - deleted assistant workflow after S5 reference list includes the new policy.
- `README.md`
  - Adds v3.2.10 release notes.
- `CHANGELOG.md`
  - Adds v3.2.10 entry.
- `scripts/figure_studio_core/image_outputs.py`
  - Adds optional prompt-index target-path mirroring for generated images.
- `scripts/figure_studio_state.py`
  - Exposes the new mirror registration flags.

## Design Notes

- Stage-local image mirroring is a byte-for-byte copy of a raster already produced by an approved image-generation route. It is not a local/programmatic raster substitute and does not redraw, crop, retouch, or render the image.
- The generated-image provenance/escrow concept is preserved. The stage-local candidate path is the human-facing canonical active image path, while provenance remains available for restore and audit.
- The rules are intentionally generic: each project derives its own module whitelist, variable demotion, connector bundling, and exceptions from the current paper/source evidence.
