"""Generic S4 formal candidate matrix helpers for v3.2.15."""

from __future__ import annotations

from typing import Iterable

DEFAULT_VISUAL_TREATMENTS = [
    "Balanced overview",
    "Technical decomposition",
    "Typed-edge / relation map",
    "Artifact / state lineage",
    "Boundary / interaction swimlane",
    "Low-density final skeleton",
]


def formal_candidate_id(index: int, prefix: str = "F") -> str:
    return f"{prefix}{index:02d}"


def generate_formal_candidate_matrix(
    default_count: int = 6,
    visual_treatments: Iterable[str] | None = None,
    *,
    id_prefix: str = "F",
    selected_direction_count: int | None = None,
) -> list[dict[str, str | int | None]]:
    """Generate paper-agnostic S4 formal candidates.

    The default is six candidates for complete-paper/framework/method-overview
    tasks. It is generic: no paper-specific module names, datasets, claims, or
    project paths are encoded here.
    """
    treatments = list(visual_treatments or DEFAULT_VISUAL_TREATMENTS)
    if default_count < 1:
        raise ValueError("default_count must be >= 1")
    candidates = []
    for i in range(default_count):
        candidates.append(
            {
                "candidate_id": formal_candidate_id(i + 1, id_prefix),
                "matrix_index": i + 1,
                "selected_direction_slot": (i % selected_direction_count) + 1 if selected_direction_count else None,
                "visual_treatment": treatments[i % len(treatments)],
                "paper_binding": "none_generic_treatment_only",
            }
        )
    return candidates
