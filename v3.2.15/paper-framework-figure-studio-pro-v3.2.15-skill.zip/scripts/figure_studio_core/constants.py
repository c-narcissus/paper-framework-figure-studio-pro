"""Stable public constants and schema values for paper-framework-figure-studio-pro v3.2.15."""

from __future__ import annotations

from pathlib import Path
import re

SKILL_NAME = "paper-framework-figure-studio-pro"
SKILL_VERSION = "3.2.15"
SCHEMA_VERSION = 1
DEFAULT_ROOT = "figure-studio-runs"
STATE_RELATIVE_PATH = Path("state") / "project-state.json"

PREFERENCE_REFERENCE_ROOT = "inputs/preference-reference-images"
PREFERENCE_ANALYSIS_PATH = "outputs/S0-paper-foundation/preference-reference-analysis.md"

SAFE_PROJECT_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,79}$")
SECRET_KEY_RE = re.compile(r"(api[_-]?key|token|secret|password|credential)", re.I)

REFERENCE_IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".webp"}
TARGET_RASTER_IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".webp"}
TARGET_RASTER_IMAGE_STEPS = {
    "S2-SKETCH-EXPLORE",
    "S5-CANDIDATE-IMAGE",
}
TARGET_RASTER_REFERENCE_ROLES = {
    "s2.primary_sketch",
    "s5.primary_candidate",
}
FORBIDDEN_TARGET_IMAGE_KINDS = {"svg", "html", "mermaid", "canvas", "pptx", "pdf"}
FORBIDDEN_TARGET_IMAGE_EXTS = {".svg", ".html", ".htm", ".mmd", ".pptx", ".pdf"}
RUNTIME_ENVIRONMENTS = {"unknown", "chatgpt_web", "codex", "claude_code", "other"}
IMAGE_GENERATION_ROUTES = {
    "unknown",
    "chatgpt_create_image",
    "codex_image_gen",
    "codex_imagegen",  # legacy alias accepted only for migration; new state writes codex_image_gen.
    "approved_image_api",
    "user_supplied_api_required",
}
IMAGE_GENERATION_EVENT_GENERATORS = {"image_gen", "imagegen", "create-image", "approved-image-api"}

CANDIDATE_STATUS_VALUES = {
    "PASS",
    "FLAG_MINOR",
    "FLAG_MAJOR",
    "BLOCKED",
    "PENDING",
    "MISSING",
    "NEEDS_REVIEW",
    "ISSUE_LEDGER_READY",
    "HAS_ISSUES",
    "HAS_BLOCKER_ISSUE",
    "NEEDS_HUMAN_SELECTION",
}
SUBSTAGE_STATUS_VALUES = {"pending", "in_progress", "complete", "blocked", "stale"}
SUBSTAGE_MODES = {"IMAGE_GENERATE"}
SUBSTAGE_STEPS = {"S2-SKETCH-EXPLORE", "S5-CANDIDATE-IMAGE"}
GUIDANCE_STEPS = {"S2-SKETCH-EXPLORE", "S5-CANDIDATE-IMAGE"}

DEFAULT_CANDIDATE_COUNT_BY_STEP = {"S2-SKETCH-EXPLORE": 8, "S5-CANDIDATE-IMAGE": 6}
MAX_CANDIDATE_COUNT_BY_STEP = {"S2-SKETCH-EXPLORE": 12, "S5-CANDIDATE-IMAGE": 12}
CHATGPT_WEB_IMAGE_CHUNK_LIMIT = 8
CHATGPT_WEB_RECOMMENDED_IMAGE_CHUNK_SIZE = 8
CODEX_IMAGE_CHUNK_LIMIT = 8

WORKFLOW_STEPS = [
    (
        "S0-PAPER-FOUNDATION",
        "TEXT_ONLY",
        "Build the paper/source foundation, runtime state, canvas defaults, framework-figure readiness state, optional author-supplement request, and risk register.",
        "outputs/S0-paper-foundation",
    ),
    (
        "S1-FIGURE-STRATEGY",
        "TEXT_ONLY_WITH_EMBEDDED_S2_PREPARE",
        "Prepare reader question, figure role, narrative structure, visual directions, sketch candidate cards, and all S2 prompt packages/prompt-index before S2 image generation.",
        "outputs/S1-figure-strategy",
    ),
    (
        "S2-SKETCH-EXPLORE",
        "IMAGE_GENERATE_ONLY",
        "Generate low-fidelity exploration sketches from S1-prepared prompt packages. Do not write text review, aggregate, or next-step prose.",
        "outputs/S2-sketch-explore",
    ),
    (
        "S3-DIRECTION-SELECT",
        "TEXT_ONLY_WITH_EMBEDDED_S2_REVIEW_AGGREGATE",
        "Review S2 sketches with issue-ledger and exploration aggregate duties, then select the paper-grounded refinement direction.",
        "outputs/S3-direction-select",
    ),
    (
        "S4-CANDIDATE-BRIEF",
        "TEXT_ONLY_WITH_EMBEDDED_S5_PREPARE",
        "Prepare the formal candidate matrix and all S5 prompt packages/prompt-index before formal candidate image generation.",
        "outputs/S4-candidate-brief",
    ),
    (
        "S5-CANDIDATE-IMAGE",
        "IMAGE_GENERATE_ONLY_TERMINAL",
        "Generate formal paper-framework raster candidates from S4-prepared prompt packages. This is the terminal assistant workflow stage; remaining decisions are human decisions.",
        "outputs/S5-candidate-image",
    ),
]

STEP_OUTPUT_DIRS = {step: output_dir for step, _, _, output_dir in WORKFLOW_STEPS}
STEP_SEQUENCE = tuple(step for step, _, _, _ in WORKFLOW_STEPS)
DEFAULT_NEXT_STEP_BY_STEP = {
    step: STEP_SEQUENCE[index + 1] if index + 1 < len(STEP_SEQUENCE) else None
    for index, step in enumerate(STEP_SEQUENCE)
}
TEXT_REPLY_STEP_BANNER_TEMPLATE = (
    "当前流程位置\n"
    "全流程：S0-PAPER-FOUNDATION -> S1-FIGURE-STRATEGY -> S2-SKETCH-EXPLORE -> "
    "S3-DIRECTION-SELECT -> S4-CANDIDATE-BRIEF -> S5-CANDIDATE-IMAGE -> END\n"
    "当前 step：{current_step}\n"
    "默认下一步：{default_next_step}"
)
STEP_CLEANUP_EXTRA_DIRS = {}
STEP_CLEANUP_EXTRA_FILES = {}

ARTIFACT_ROLES = {
    "s0.paper_foundation_report": {
        "step": "S0-PAPER-FOUNDATION",
        "kind": "markdown",
        "relative_path": "outputs/S0-paper-foundation/paper-foundation-report.md",
    },
    "s0.framework_figure_risk_register": {
        "step": "S0-PAPER-FOUNDATION",
        "kind": "markdown",
        "relative_path": "outputs/S0-paper-foundation/framework-figure-risk-register.md",
    },
    "s0.author_supplement_request": {
        "step": "S0-PAPER-FOUNDATION",
        "kind": "markdown",
        "relative_path": "outputs/S0-paper-foundation/author-supplement-request.md",
    },
    "s0.supplement_integration_log": {
        "step": "S0-PAPER-FOUNDATION",
        "kind": "markdown",
        "relative_path": "outputs/S0-paper-foundation/supplement-integration-log.md",
    },
    "s1.figure_strategy": {
        "step": "S1-FIGURE-STRATEGY",
        "kind": "markdown",
        "relative_path": "outputs/S1-figure-strategy/figure-strategy-brief.md",
    },
    "s1.s2_prompt_index": {
        "step": "S1-FIGURE-STRATEGY",
        "kind": "json",
        "relative_path": "outputs/S2-sketch-explore/prompt-index.json",
    },
    "s2.primary_sketch": {
        "step": "S2-SKETCH-EXPLORE",
        "kind": "image",
        "relative_path": "outputs/S2-sketch-explore/candidates/C01/image-v01.png",
    },
    "s3.direction_selection": {
        "step": "S3-DIRECTION-SELECT",
        "kind": "markdown",
        "relative_path": "outputs/S3-direction-select/s3-direction-decision.md",
    },
    "s3.s2_exploration_aggregate": {
        "step": "S3-DIRECTION-SELECT",
        "kind": "markdown",
        "relative_path": "outputs/S3-direction-select/s2-exploration-aggregate.md",
    },
    "s4.candidate_brief": {
        "step": "S4-CANDIDATE-BRIEF",
        "kind": "markdown",
        "relative_path": "outputs/S4-candidate-brief/formal-candidate-brief.md",
    },
    "s4.s5_prompt_index": {
        "step": "S4-CANDIDATE-BRIEF",
        "kind": "json",
        "relative_path": "outputs/S5-candidate-image/prompt-index.json",
    },
    "s5.primary_candidate": {
        "step": "S5-CANDIDATE-IMAGE",
        "kind": "image",
        "relative_path": "outputs/S5-candidate-image/candidates/F01/image-v01.png",
    },
}

PRIMARY_ARTIFACT_ROLE_BY_STEP = {
    "S0-PAPER-FOUNDATION": "s0.paper_foundation_report",
    "S1-FIGURE-STRATEGY": "s1.figure_strategy",
    "S2-SKETCH-EXPLORE": "s2.primary_sketch",
    "S3-DIRECTION-SELECT": "s3.direction_selection",
    "S4-CANDIDATE-BRIEF": "s4.candidate_brief",
    "S5-CANDIDATE-IMAGE": "s5.primary_candidate",
}

CANONICAL_OUTPUTS = {step: ARTIFACT_ROLES[role]["relative_path"] for step, role in PRIMARY_ARTIFACT_ROLE_BY_STEP.items()}


def _pending_row(role_id: str) -> dict[str, str]:
    role = ARTIFACT_ROLES[role_id]
    return {"step": role["step"], "relative_path": role["relative_path"], "artifact_role": role_id}


PENDING_CANONICAL_OUTPUTS = []
for _step, _, _, _ in WORKFLOW_STEPS:
    _role_id = PRIMARY_ARTIFACT_ROLE_BY_STEP[_step]
    PENDING_CANONICAL_OUTPUTS.append(_pending_row(_role_id))
for _role_id in (
    "s1.s2_prompt_index",
    "s3.s2_exploration_aggregate",
    "s4.s5_prompt_index",
):
    PENDING_CANONICAL_OUTPUTS.append(_pending_row(_role_id))

TEXT_ONLY_STEPS = {step for step, mode, _, _ in WORKFLOW_STEPS if mode.startswith("TEXT_ONLY")}
IMAGE_ONLY_STEPS = {step for step, mode, _, _ in WORKFLOW_STEPS if mode.startswith("IMAGE")}

ATLAS_BOARD_ROOT = "assets/subtype-atlas/boards"
ATLAS_THUMBNAIL_ROOT = "assets/subtype-atlas/thumbnails"
ATLAS_MANIFEST_PATH = "assets/subtype-atlas/manifest.json"
ATLAS_BOARD_IDS = (
    "subtype-overview",
    "visual-grammar-layout",
    "reader-role-detail",
    "visual-communication-styles",
)
ATLAS_DISPLAY_POLICY = (
    "Whenever a reply mentions subtype/category atlas boards, layout grammar, visual communication styles, "
    "reader-role detail, or subtype overview, embed the corresponding saved PNG board with Markdown. "
    "Do not build generated web pages in any environment, including Codex."
)
