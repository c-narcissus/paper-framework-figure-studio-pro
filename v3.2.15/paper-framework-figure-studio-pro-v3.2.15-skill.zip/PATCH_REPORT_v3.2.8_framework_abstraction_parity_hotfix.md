# Patch Report v3.2.8 — Generic Framework Abstraction, Entity Density, Flowline Semantics, And Rerun Parity

## Scope

This patch modifies the reusable skill policy, not any individual paper run. It is paper-agnostic and must not encode facts, variable names, module names, datasets, topology, or candidate IDs from any single project. Future projects instantiate the rules only from their own S0/S1/S4 source-grounded evidence.

## Generalized problems addressed

1. **Intermediate variables as visual modules.** Temporary outputs, metrics, pseudo-outputs, thresholds, weights, masks, probabilities, and similar pass-through symbols now default to edge labels, port labels, or attached tags rather than standalone boxes.
2. **Over-dense framework diagrams.** S2/S5 prompt packages now require an `entity_density_budget` and `element_granularity_plan`; framework diagrams must merge low-level details into compound modules unless separation is source-grounded and reader-critical.
3. **Over-splitting micro-operations.** Gate/parameter pairs such as threshold+filter, schedule+sampler, confidence+selector, and metric+weighting must be rendered as compound gates or attached tags unless explicitly justified.
4. **Unsupported inputs from visual proximity.** Module input contracts now explicitly forbid arrows into a module unless relation and direction evidence supports them; local availability or container membership is not input evidence.
5. **Duplicate or redundant arrows.** Fork/merge connector plans and edge-cardinality audits prevent multiple arrows that carry the same variable or role to the same target.
6. **Ambiguous arrows.** Every connector in prompt packages and rerun prompts must specify flow semantics: data/artifact, model/reference, control/gating, evaluation/metric, communication/exchange, dependency, callout, grouping, or next-round reuse.
7. **S5/legacy dynamic-stage pattern/rerun drift from S2.** S2, S5, legacy dynamic-stage pattern, deleted assistant workflow after S5, and any future image stage now share the same semantic prompt baseline. Authorized rerun prompts must rebuild and preserve the original graph, line-label, flow semantics, granularity, density, module-input, and duplicate-edge contracts while changing only issue-ledger-scoped defects.

## Files changed

- Added `references/framework-abstraction-flowline-and-rerun-prompt-policy-v328.md`.
- Updated `SKILL.md` startup contract and prompt handoff rules.
- Updated semantic graph, S2/S5 layout/audit, dynamic substage, issue-ledger, and visual economy policies.
- Updated `README.md`, `CHANGELOG.md`, `VERSION`, `metadata.json`, and `agents/openai.yaml`.

## Backward compatibility

- The public workflow is unchanged: S0 → S1 → S2 → S3 → S4 → S5 → deleted assistant workflow after S5.
- No public legacy dynamic-stage pattern step is added. The legacy dynamic-stage pattern wording covers future project-defined image stages or downstream/custom stages that may be introduced by a wrapper workflow.
- S2 remains low-fidelity by default; S5 remains formal by default. Style may differ by stage, but semantic contract strength does not.
- The fixed candidate contract policy may still omit heavy per-candidate connector/area enumeration in S2/S5, but it cannot skip baseline symbol classification, density planning, edge-label separation, flow semantics, module input eligibility, duplicate-edge prevention, or rerun parity.
