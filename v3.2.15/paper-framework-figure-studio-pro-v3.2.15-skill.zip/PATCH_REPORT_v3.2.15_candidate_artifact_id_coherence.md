# Patch Report v3.2.15 — Candidate / Artifact ID Coherence

## Goal

Fix generic image ID mismatch risks across S2/S5 and related state/output artifacts without hard-coding any paper-specific project, dataset, method, or candidate name.

## Changes

- Added `references/candidate-artifact-id-coherence-policy-v3215.md`.
- Added `scripts/figure_studio_core/identity.py` as the shared candidate-id normalization and prompt-index validation layer.
- Made prompt-index `candidates[].candidate_id` the source of truth after S1/S4 preparation.
- Updated S2/S5 prompt-index, manifest, substage plan, status-file, candidate-registry, artifact, image-generation-event, and checkpoint logic to preserve the same candidate ID.
- Changed default S5 formal IDs to `F01-F06` while keeping S2 sketch defaults as `C01-C08`.
- Updated image-batch registration so S2/S5 target images must be mirrored to prompt-index `target_image_path` values instead of silently using numeric artifact IDs or unrelated output directories.
- Updated state validation to detect candidate/path mismatches in prompt-index rows, manifests, registries, artifacts, and image-generation event `candidate_outputs`.
- Updated user-facing starter/copyable prompts to say `请使用 paper-framework-figure-studio-pro skill` without naming a versioned archive file.

## Genericity guard

The patch is project-neutral. It validates only safe candidate ID shape and path coherence. It does not encode SemiDFL, its client topology, variables, datasets, method components, or any other paper-specific facts.

## Verification

- Python compileall passed.
- Architecture audit passed with 0 findings.
- State init and validate passed.
- S2 prompt-index planning produced `C01-C08` and `S2-01-image-generate-c01-c08`.
- S5 prompt-index planning produced `F01-F06` and `S5-01-image-generate-f01-f06`.
- S5 image registration mapped generated images to `outputs/S5-candidate-image/candidates/F01/image-v01.png` and `F02/image-v01.png`, updated status files, candidate registry, artifacts, and image-generation event `candidate_outputs` with matching IDs.
- Intentional F01 -> C01 target path mismatch was rejected by prompt-index validation.
- Release path scan passed with 0 findings after cache cleanup.
