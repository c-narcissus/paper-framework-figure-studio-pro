# Patch Report v3.2.9 — Generic Cumulative Substage Checkpoint Integrity

## Scope

This patch updates the reusable `paper-framework-figure-studio-pro` skill, not any specific paper run. It is project-agnostic and paper-agnostic: no paper title, project id, candidate id, method variable, dataset, or fixed image count is encoded.

## Problem addressed

A dynamic substage checkpoint can be accidentally produced as a current-substage-only or current-stage-only zip even though previous stage-final checkpoints were cumulative. That makes cross-session recovery unsafe because earlier state, manifests, prompts, audits, images, and outputs may be absent from the checkpoint.

## Generic solution

Added a cumulative checkpoint integrity layer that applies to every checkpoint-producing public stage, dynamic internal substage, rerun/review unit, aggregate unit, and terminal aggregate.

Key requirements:

- Every checkpoint is cumulative from workflow start through the current public stage/internal substage.
- Chunk checkpoints and stage-final checkpoints use the same restore scope.
- Each checkpoint-producing page must include a `checkpoint_integrity` section.
- Checkpoint inventories are discovered from run state, workflow plan, manifests, candidate registries, image generation records, artifact records, rerun/finalization records, and existing files under included roots.
- Planned future images/assets remain pending and do not block restore.
- After writing a zip or split parts, the archive member union is reopened and validated.
- Missing required existing assets trigger a bounded rebuild-and-revalidate loop before a checkpoint can be marked `complete_restore_ready`.
- If still incomplete, the checkpoint is marked `incomplete_restore_blocked` and exact missing manifests are written.

## Files added

- `references/cumulative-checkpoint-substage-integrity-policy-v329.md`
- `scripts/figure_studio_checkpoint_guard.py`
- `PATCH_REPORT_v3.2.9_cumulative_substage_checkpoint_integrity.md`

## Files updated

- `VERSION`
- `metadata.json`
- `README.md`
- `CHANGELOG.md`
- `SKILL.md`
- `SKILL_CREATOR_PACKAGE_REPORT.md`
- `references/cumulative-restore-checkpoint-policy-v318-hotfix.md`
- `references/chatgpt-web-checkpoint-bundle-policy.md`
- `references/s2-s5-dynamic-substage-orchestration-policy-v316.md`
- `scripts/figure_studio_core/constants.py`
- `scripts/figure_studio_core/checkpoint_policy.py`
- `scripts/figure_studio_core/substages.py`
- `scripts/figure_studio_state.py`
- `templates/project-state-template.json`
- publish metadata files with version text

## Script behavior

`figure_studio_checkpoint_guard.py` can validate or rebuild a checkpoint without hard-coding task specifics:

```bash
python scripts/figure_studio_checkpoint_guard.py \
  --run-dir <project-run-dir> \
  --stage <current-stage-id> \
  --zip <checkpoint.zip> \
  --report <checkpoint-integrity-report.json>
```

For bounded rebuild:

```bash
python scripts/figure_studio_checkpoint_guard.py \
  --run-dir <project-run-dir> \
  --stage <current-stage-id> \
  --zip <possibly-incomplete-checkpoint.zip> \
  --rebuild-output-zip <rebuilt-cumulative-checkpoint.zip> \
  --max-attempts 3 \
  --report <checkpoint-integrity-report.json>
```

## Validation

- Architecture audit: PASS, 0 findings.
- Release absolute-path/cache scan: PASS, 0 findings.
- Checkpoint guard smoke test: PASS; rebuilt a cumulative checkpoint from a generic dummy workflow without project- or paper-specific assumptions.

## Non-hardcoding confirmation

A package scan found no target-paper/project-specific terms from the current example run. The new rules derive coverage and required assets from state/manifests/registries/on-disk roots only.
