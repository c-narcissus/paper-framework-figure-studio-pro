# PATCH REPORT v3.2.13 — Terminal Image-Only Workflow

## User-requested change

- Collapse S2 and S5 into image-generation-only public stages.
- Move former S2 preparation duties into S1 as mandatory embedded work.
- Move former S2 review/aggregate duties into S3 as mandatory embedded work.
- Move former S5 preparation duties into S4 as mandatory embedded work.
- Remove S2/S5 candidate-level revision/review/aggregate substages.
- Remove every assistant workflow component after S5.
- Make the required after-S5 answer: `我的任务已经完成，剩下由人类来决策。`

## Main workflow after patch

```text
Bootstrap -> S0 -> S1(+S2 prep) -> S2(IMAGE_GENERATE only) -> S3(+S2 review/aggregate) -> S4(+S5 prep) -> S5(IMAGE_GENERATE only) -> END
```

## Updated package areas

- `SKILL.md`, `README.md`, `CHANGELOG.md`, `VERSION`, `metadata.json`.
- Core scripts: constants, state schema, validation, substage planning, runtime route guard, prompt handoff, CLI command surface, architecture audit.
- Templates and publish starter messages.
- Reference policies for orchestration, prompt handoff, candidate-light checking, S2/S5 layout routing, review ledger, and workflow/state behavior.
- Examples for S2 and S5 image-only turns.

## Validation performed

- Python compile check for all package scripts.
- `scripts/figure_studio_architecture_audit.py` passed with zero findings.
- State init + validate smoke test passed.
- S2 substage planning produced only `S2-01-image-generate-c01-c08`.
- S5 substage planning produced only `S5-01-image-generate-c01-c06`, with `default_next_step=null`.
- Terminal next-action smoke test returned `workflow_complete_human_decision` with the required Chinese terminal message.
