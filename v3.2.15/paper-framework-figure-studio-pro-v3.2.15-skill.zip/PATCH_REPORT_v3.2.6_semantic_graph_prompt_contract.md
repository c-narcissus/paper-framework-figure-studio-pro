# Patch Report v3.2.6 — Semantic Graph Prompt Contract

## Purpose

This hotfix addresses connector-heavy scientific framework figures where image models add unsupported arrows, duplicate artifacts, reuse labels ambiguously, or render vague consensus/control rails. It changes S2/S5 prompt generation so the image prompt is compiled from a structured semantic graph before any layout/style prose.

## Main changes

1. Added `references/semantic-graph-prompt-contract-policy-v326.md`.
2. Updated `SKILL.md` so S2/S5 prompt preparation requires:
   - `semantic_graph_spec`
   - `visible_text_whitelist`
   - `internal_text_blacklist`
   - `graph_integrity_audit`
   - `exact_edge_registry`
   - `prompt_file_read_audit`
3. Updated paper-core semantics policy so `node_id`, `edge_id`, and `port_id` are explicitly non-visible, while `display_label` and `visible_edge_label` are the only renderable text fields.
4. Updated edge-cardinality policy so every connector maps back to exactly one unique internal edge ID, and internal IDs appearing in the generated figure are audit failures.
5. Updated layout/routing audit policy with a semantic graph prompt gate.
6. Updated file-reference handoff policy so an image-generation unit must read the actual `prompt_path`, verify the prompt file exists, and confirm the graph spec / exact edge registry are present before generating.

## Key principle

Internal IDs are topology controls, not figure content. The generated diagram must draw only visible labels and symbols explicitly whitelisted by the prompt.
