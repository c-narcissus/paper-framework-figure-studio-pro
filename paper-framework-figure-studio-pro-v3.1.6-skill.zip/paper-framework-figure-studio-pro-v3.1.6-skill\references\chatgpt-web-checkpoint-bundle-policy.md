# ChatGPT Web Checkpoint Bundle Policy

When file artifact creation is available, ChatGPT web replies may provide a full checkpoint package so a workflow can resume in a new conversation.

In v3.1.6 this is required at the end of every main stage when running in `runtime=chatgpt_web`. For S2/S5, also create a checkpoint after `TEXT_AUDIT` or `TEXT_REAUDIT` when the stage is split across multiple units or the user may open a new session before aggregation. For S7, create a checkpoint after each text audit or re-audit when artifacts are available, because the mandatory S7 internal workflow alternates text units and one-image actions.

If the current ChatGPT web session cannot create downloadable files or zip artifacts, do not claim that a checkpoint zip exists and do not mark the checkpoint complete. Instead:

1. Write a text `checkpoint-manifest` summary in the response with project id, skill version, current public step ID, checkpoint type, included logical roots, missing zip reason, and restore instructions.
2. Mark the checkpoint need as `blocked_file_artifact_unavailable` in state if state can be written.
3. Tell the user that cross-session resume is not reliable until a real zip bundle is created by switching to a runtime with file creation or by providing/restoring a project bundle.
4. Continue within the same session only when the next action does not depend on cross-session recovery.

The checkpoint should include:

- `state/project-state.json`;
- relevant `inputs/`;
- all active `outputs/` up to the current stage needed for S0-S7 continuation, inspection, final selection, or final joint audit;
- S2/S5 `stage-manifest.json`, candidate folders, `audit-latest.*`, `status.json`, `substage_runs`, and `candidate_run_registry` when present;
- S2/S5/S7 `substage-guides/`, `substage_guidance_registry`, and `next_prompt_registry` when present;
- S7 internal run records, repair history, pending/submitted figure records, reconstruction spec, element icon inventory, icon sheets, and icon-sheet audit when present;
- `checkpoint-manifest.json` with project id, skill version, stage, checkpoint type, sequence, timestamp, included roots, and restore policy;
- a skill snapshot or version note.

If S2/S5 generated images are unavailable to the zip writer, the checkpoint must include a missing-image manifest and must not be described as a complete restore bundle. The response must tell the user to manually place the images into the exact zip paths before opening a new session. Use the paths recorded in state/manifest, for example:

```text
outputs/S2-sketch-explore/candidates/C01/<registered-active-image-file>
...
outputs/S2-sketch-explore/candidates/C08/<registered-active-image-file>

outputs/S5-candidate-images/candidates/C01/<registered-active-image-file>
...
outputs/S5-candidate-images/candidates/C06/<registered-active-image-file>
```

When S2/S5 repair was pre-authorized, the repaired image overwrites and uses the same registered active image path. Do not create a second active image filename for the user to manage.

Use overwrite/latest semantics when possible. If the platform creates duplicates, resolve the latest checkpoint by manifest timestamp and sequence number.

Do not include caches, host-specific absolute paths, or unrelated local files.

If one checkpoint is too large for ChatGPT web, split it into `checkpoint-part01.zip`, `checkpoint-part02.zip`, etc., and list all parts in `checkpoint-manifest.json`.
