"""User guidance handoff files for internal text/image loops."""

from __future__ import annotations

import argparse
import re
from pathlib import Path
from typing import Any

from .constants import GUIDANCE_STEPS, STEP_OUTPUT_DIRS
from .errors import StateError
from .paths import normalize_relative_path, safe_join, utc_now


SAFE_GUIDANCE_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,120}$")


def guidance_output_dir(step: str) -> str:
    if step not in GUIDANCE_STEPS:
        raise StateError(f"guidance is supported only for {sorted(GUIDANCE_STEPS)}")
    return f"{STEP_OUTPUT_DIRS[step]}/substage-guides"


def normalize_guidance_id(value: str) -> str:
    if not value or not SAFE_GUIDANCE_ID_RE.fullmatch(value):
        raise StateError("substage guidance id must contain only letters, digits, dot, underscore, and hyphen")
    return value


def optional_rel_path(run_dir: Path, label: str, value: str | None) -> str | None:
    if not value:
        return None
    rel = normalize_relative_path(value)
    safe_join(run_dir, rel)
    return rel


def guidance_markdown(args: argparse.Namespace, created_at: str) -> str:
    lines = [
        f"# Next User Prompt: {args.step} / {args.substage_id}",
        "",
        f"- step: `{args.step}`",
        f"- substage_id: `{args.substage_id}`",
        f"- created_at: `{created_at}`",
    ]
    if args.summary:
        lines.extend(["", "## Summary", "", args.summary.strip()])
    lines.extend(["", "## Copyable Prompt", "", "```text", args.next_prompt.strip(), "```"])
    if args.checkpoint_path:
        lines.extend(["", "## Checkpoint", "", f"- checkpoint: `{args.checkpoint_path}`"])
    if args.source_user_request:
        lines.extend(["", "## Source User Request", "", args.source_user_request.strip()])
    lines.append("")
    return "\n".join(lines)


def cmd_write_guidance(args: argparse.Namespace, run_dir: Path, state: dict[str, Any]) -> dict[str, Any]:
    if not args.next_prompt or not args.next_prompt.strip():
        raise StateError("--next-prompt is required and cannot be empty")
    substage_id = normalize_guidance_id(args.substage_id)
    guide_dir_rel = guidance_output_dir(args.step)
    guide_rel = f"{guide_dir_rel}/{substage_id}-next-user-prompt.md"
    guide_path = safe_join(run_dir, guide_rel)
    guide_path.parent.mkdir(parents=True, exist_ok=True)
    checkpoint_rel = optional_rel_path(run_dir, "checkpoint_path", args.checkpoint_path)
    created_at = utc_now()
    guide_path.write_text(guidance_markdown(args, created_at), encoding="utf-8")
    row = {
        "step": args.step,
        "substage_id": substage_id,
        "relative_path": guide_rel,
        "summary": args.summary or "",
        "next_prompt": args.next_prompt.strip(),
        "checkpoint_path": checkpoint_rel,
        "created_at": created_at,
        "updated_at": created_at,
        "source_user_request": args.source_user_request or "",
    }
    state.setdefault("substage_guidance_registry", {}).setdefault(args.step, {})[substage_id] = row
    state.setdefault("next_prompt_registry", {})[args.step] = {
        "substage_id": substage_id,
        "relative_path": guide_rel,
        "next_prompt": args.next_prompt.strip(),
        "updated_at": created_at,
    }
    state["updated_at"] = created_at
    return row
