# Review Rubric

Evaluate S2/S5/S6/S7 outputs against:

- paper fidelity and source-grounded terminology;
- required module coverage;
- correct data/control/causal arrow semantics;
- precise color semantics when color encodes meaning;
- paper-relevant icon semantics;
- visible core innovation mechanism when evidence exists;
- visible anchors for heavily described, formula-backed, or explicitly improved innovations;
- non-droppable core substep coverage;
- symbol/formula necessity;
- readable density at target size;
- figure-caption symbiosis and style-aware caption fit;
- first-glance appeal and 10-second comprehension;
- avoidance of poster/PPT-slide content dumping.

S6 must select one S5 raster candidate and provide title, style-aware caption, legend, body-reference text, and manuscript note. S7 must audit the selected image and text package together with a bounded PASS/TEXT-REPAIR/IMAGE-REPAIR/DIRECTION-REPAIR verdict.
