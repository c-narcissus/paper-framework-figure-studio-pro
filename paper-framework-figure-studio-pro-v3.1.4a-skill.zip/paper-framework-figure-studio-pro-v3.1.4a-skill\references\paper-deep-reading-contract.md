# Paper Deep Reading Contract

The paper foundation report is the factual anchor for S1 through S6.

When the input includes a PDF, LaTeX source, full paper text, detailed method description, report, supplement, or equivalent material, S0 must produce a rich, accurate, source-grounded `paper-foundation-report.md`.

The report should include:

- problem, assumptions, and related-work gap;
- ordered method or algorithm steps;
- model architecture, components, modules, training flow, inference flow, and inputs/outputs;
- losses, objectives, equations, constraints, and terminology mapping;
- arrow semantics: source, target, meaning, and evidence anchor;
- figure-relevant inclusions, exclusions, uncertainty, and reviewer risk;
- core innovation modules and non-droppable core substeps.

Later steps must use this report rather than relying on memory or a generic summary.

S6-FINAL-SELECT must recheck the selected candidate against the paper foundation before finalizing title, caption, legend, body-reference text, and manuscript note.
