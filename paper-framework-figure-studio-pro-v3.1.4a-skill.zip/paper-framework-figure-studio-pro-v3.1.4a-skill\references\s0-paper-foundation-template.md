# S0 Paper Foundation Template

S0 initializes state and builds the factual base.

Required sections when paper/source material is available:

1. Input material inventory.
2. Problem, assumptions, and contribution summary.
3. Method/algorithm/model pipeline.
4. Module inventory: input, output, role, dependency.
5. Training and inference flow.
6. Objective/loss/equation interpretation.
7. Terminology map: paper term -> figure label -> allowed shorthand.
8. Arrow semantics table.
9. Core innovation modules and internal mechanism evidence.
10. Heavily described, formula-backed, or explicitly improved mechanisms that need visual anchors.
11. Non-droppable core substeps.
12. Figure-relevant omissions and uncertainty.
13. Caption-supported facts, numbers, datasets, metrics, caveats, and formula explanations.
14. S1 strategy hints.

The report anchors S1-S7. If it is missing or too shallow, repair S0 before generating images.

Default canvas is 16:9 unless the user requests another ratio.

Default S2 count is 6 sketches. Default S5 count is 6 formal candidates. S5 candidates remain generated raster images. Their icons, arrows, colors, and caption plans should optimize paper meaning; SVG/PPT editability is secondary.
