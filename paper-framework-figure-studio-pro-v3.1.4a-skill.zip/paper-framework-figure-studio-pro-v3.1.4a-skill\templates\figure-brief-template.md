# S6-FINAL-SELECT Final Selection Report Template

Use this template when S6-FINAL-SELECT selects the final architecture reference from S5-CANDIDATE-IMAGE candidates.

## Metadata

- artifact_id: s6-final-selection-report
- canonical_relative_path: outputs/S6-final-selection/final-selection-report.md
- selected_reference_final: outputs/S5-candidate-images/candidate-01.png
- default_next_step: S7-FINAL-JOINT-AUDIT

## Selected Final Reference

- Selected image:
- Candidate ID:
- Why this candidate is the final reference:
- Figure-vs-caption split:
- Style-aware caption plan:
- Core innovation module detail mode:
- Core submodule internal mechanism preserved:
- Non-droppable core substeps preserved:
- Claimed improvement visual anchor:
- Symbol/formula necessity proof:
- Arrow/color/icon semantic contract:
- Semantic density budget:
- Editability notes:
- Known limitations:

## Paper Recheck

| Check | Paper/source evidence | Candidate result | Action |
|---|---|---|---|
| Core method/algorithm/model structure |  |  | keep/fix/drop |
| Core innovation submodule internal mechanism |  |  | keep/fix/drop |
| Non-droppable core substep coverage |  |  | keep/fix/drop |
| Required modules |  |  | keep/fix/drop |
| Terminology |  |  | keep/fix/drop |
| Arrow/data/control relations |  |  | keep/fix/drop |
| Color semantics |  |  | keep/fix/drop |
| Icon relevance to paper meaning |  |  | keep/fix/drop |
| Symbol/formula necessity |  |  | keep/fix/drop |
| Key contribution claims |  |  | keep/fix/drop |
| Figure-caption symbiosis |  |  | keep/fix/drop |
| Style-aware caption fit |  |  | keep/fix/drop |
| Density/readability for a paper figure |  |  | keep/fix/drop |

## Candidate Ranking

| Rank | Candidate | Paper fit | Core detail | First-glance appeal | 10-second comprehension | Semantic density | Icon/arrow/color precision | Caption fit | Decision |
|---|---|---|---|---|---|---|---|---|---|
| 1 | candidate-01.png |  |  |  |  |  |  |  | select |

## Final Figure Text

- Figure title:
- Caption (style-aware):
- Legend / symbol notes:
- Body-reference sentence:
- Manuscript revision note:

## Completion

S6-FINAL-SELECT complete. This stage has ended. S7-FINAL-JOINT-AUDIT has not been executed.
