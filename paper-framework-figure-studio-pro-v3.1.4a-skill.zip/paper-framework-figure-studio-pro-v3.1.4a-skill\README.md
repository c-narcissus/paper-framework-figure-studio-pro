# Paper Framework Figure Studio Pro v3.1.4a

`paper-framework-figure-studio-pro` is a human-in-the-loop skill for making research-paper framework, architecture, pipeline, mechanism, and method-overview figures.

v3.1.4a restores a bounded final audit stage and makes figure-caption symbiosis explicit:

```text
S0-PAPER-FOUNDATION -> S1-FIGURE-STRATEGY -> S2-SKETCH-EXPLORE -> S3-DIRECTION-SELECT -> S4-CANDIDATE-BRIEF -> S5-CANDIDATE-IMAGE -> S6-FINAL-SELECT -> S7-FINAL-JOINT-AUDIT
```

## Main Changes

- S7-FINAL-JOINT-AUDIT is the terminal step. S6 selects the final image and drafts title/caption/legend/body text; S7 audits the image and text together.
- S7 is a bounded best-practice review, not an endless checking loop. It runs fixed passes and returns `PASS`, `TEXT-REPAIR`, `IMAGE-REPAIR`, or `DIRECTION-REPAIR`.
- Figure and caption are treated as one unit. Captions must be style-aware and explain the selected figure's reader path, visual grammar, arrows, colors, icons, symbols, and intentional omissions.
- The caption can carry target-paper facts, values, datasets, metrics, formula meanings, caveats, and claim support when those would overload the image.
- The image should not include unnecessary symbols or formulas. A symbol/formula is used only when the core idea cannot be expressed without it.
- Core innovations described heavily in prose, formulas, or improvement claims must have clear visual anchors in the figure.
- S5 candidates remain generated raster images. SVG/PPT editability is secondary and must not override paper meaning, icon expressiveness, or caption fit.
- The first S2 low-fidelity hand-drawn batch must include paper-close story-driven/storyboard candidates by default, and those stories must use common concepts that readers can connect to the method.
- Re-entering S7 requires cleaning prior S7 outputs/records and recording the cleanup in state before rerunning S7.

## Step List

| Step | Type | Purpose |
|---|---|---|
| S0-PAPER-FOUNDATION | TEXT_ONLY | Build project state and the paper/source foundation. |
| S1-FIGURE-STRATEGY | TEXT_ONLY | Diagnose the reader question, figure role, core innovations, and candidate directions. |
| S2-SKETCH-EXPLORE | IMAGE_ONLY_PLUS_PROMPT | Generate 6-8 broad low-fidelity raster sketches, including story-driven/storyboard sketches by default. |
| S3-DIRECTION-SELECT | TEXT_ONLY | Select the strongest direction for local refinement. |
| S4-CANDIDATE-BRIEF | TEXT_ONLY | Prepare formal candidate briefs, prompts, caption split, core anchors, and visual semantics. |
| S5-CANDIDATE-IMAGE | IMAGE_ONLY_PLUS_PROMPT | Generate formal paper-framework raster candidates in clean schematic style. |
| S6-FINAL-SELECT | TEXT_ONLY | Select the final image and draft figure text. |
| S7-FINAL-JOINT-AUDIT | TEXT_ONLY | Audit the final image and caption/legend/body text together, then approve or route repair. |

## Operating Rules

- Execute only one explicitly requested step per user turn.
- Every step response must explicitly state that the current stage has ended. S0-S6 must also state that the next stage has not been executed.
- Text stages that offer multiple choices must provide both the default-choice prompt and a placeholder prompt for the user to fill in their preferred option.
- S2 and S5 target images must be raster outputs generated through the configured image route.
- At S3 completion, the next S4 prompt must offer hand-drawn continuity and clean formal figure-caption co-design branches; the clean formal branch is the default.
- S5 candidates should use paper-relevant icons, precise arrows, meaningful colors, and caption-compatible visual grammar.
- S6 is complete only when it includes the final selected image path/display and the draft figure text package. After that, the default next step is `S7-FINAL-JOINT-AUDIT`.
- S7 is complete only when the bounded joint audit passes. After that, the default next step is `完成`.

## Usage Prompt

```text
请按照 paper-framework-figure-studio-pro skill 的要求，根据当前状态和已登记产物，进入 S0-PAPER-FOUNDATION。建立项目状态，确认运行环境、输入材料、画幅和默认候选数量；如果输入包含 PDF/LaTeX/完整论文文本/详细方法说明，请只基于允许的论文材料生成并打印 paper-foundation-report.md。不要生成目标论文图片。完成 S0 后停止，并只提供进入 S1-FIGURE-STRATEGY 的可复制提示词。
```
