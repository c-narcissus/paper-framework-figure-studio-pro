# Visual Style And Board Protocol

S2 may be exploratory and visually varied. S5 should be formal, paper-grounded, and clean.

Second-round/formal candidate style:

- still generate raster images;
- use regular publication schematic composition;
- use stable modular geometry, clear connectors, restrained meaningful color, short labels, and paper-relevant icons;
- pair the visual style with a style-aware caption plan.

Avoid default hand-drawn, whiteboard, sketch-note, comic, sticky-note, painterly, photorealistic, texture-heavy, poster-like, or dense PPT-slide aesthetics for S5.

SVG/PPT editability is a secondary output-design consideration, not an output-modality change and not the primary figure objective. S5 candidates and the S6 selected final reference must be generated raster images.

Default density budget: 3-6 main modules, one dominant data/control flow, 0-3 secondary flows, usually no formulas and at most 1-2 essential formulas only when the core idea cannot be expressed without them, short module labels only, and landmark icons chosen for paper meaning. If a detail is scientifically important but visually expensive, move it to S6 caption/legend/body text instead of forcing it into the image, unless it is a non-droppable core innovation anchor that must remain visible.
