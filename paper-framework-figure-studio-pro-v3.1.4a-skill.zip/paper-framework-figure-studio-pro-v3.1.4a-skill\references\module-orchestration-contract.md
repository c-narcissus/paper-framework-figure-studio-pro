# Module Orchestration Contract

Use only the reference modules needed for the current step.

- S0-PAPER-FOUNDATION: `references/s0-paper-foundation-template.md`.
- S1-FIGURE-STRATEGY and S2-SKETCH-EXPLORE: `references/modules/s1-s2-strategy-and-sketch.md`.
- S3-DIRECTION-SELECT through S5-CANDIDATE-IMAGE: `references/modules/s3-to-s5-candidates.md`.
- S6-FINAL-SELECT: `references/modules/s6-final-selection.md`.

Active route:

```text
S0-PAPER-FOUNDATION -> S1-FIGURE-STRATEGY -> S2-SKETCH-EXPLORE -> S3-DIRECTION-SELECT -> S4-CANDIDATE-BRIEF -> S5-CANDIDATE-IMAGE -> S6-FINAL-SELECT
```

Global exploration steps may be divergent and reader-hook oriented. Local refinement steps must be paper-grounded. S6 finalizes the selected image and figure text.
