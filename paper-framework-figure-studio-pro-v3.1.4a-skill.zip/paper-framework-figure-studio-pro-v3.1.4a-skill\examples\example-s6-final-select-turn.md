# Example: S6-FINAL-SELECT

Run only S6. Select the final S5 candidate, show the selected path/image, provide the selection report, and write the figure title, style-aware caption, legend, body-reference text, and manuscript note. State that S6 has ended and S7 has not been executed. Stop with the S7-FINAL-JOINT-AUDIT prompt.
