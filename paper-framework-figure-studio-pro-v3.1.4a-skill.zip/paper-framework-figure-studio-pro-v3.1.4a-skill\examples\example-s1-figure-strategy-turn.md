# Example: S1-FIGURE-STRATEGY

Run only S1. Diagnose reader question, figure role, candidate directions, and S2 sketch cards. Stop with the S2-SKETCH-EXPLORE prompt.
