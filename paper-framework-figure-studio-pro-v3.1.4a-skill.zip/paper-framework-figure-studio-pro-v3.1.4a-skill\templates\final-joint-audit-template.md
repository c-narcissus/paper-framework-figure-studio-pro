# S7-FINAL-JOINT-AUDIT Report Template

Use this template when S7 audits the selected final figure and figure text together.

## Metadata

- artifact_id: s7-final-joint-audit
- canonical_relative_path: outputs/S7-final-joint-audit/final-joint-audit.md
- selected_reference_final:
- source_s6_report:
- verdict: PASS / TEXT-REPAIR / IMAGE-REPAIR / DIRECTION-REPAIR

## Selected Bundle

- Selected image path/display:
- Figure title:
- Caption:
- Legend / symbol notes:
- Body-reference sentence:
- Manuscript revision note:

## Bounded Audit Table

| Pass | Result | Evidence note | Repair route |
|---|---|---|---|
| Paper fidelity | OK / MINOR-TEXT-FIX / MAJOR-FIGURE-FIX / BLOCKER |  |  |
| Model / algorithm / process / math |  |  |  |
| Core innovation visual anchor |  |  |  |
| Arrow semantics |  |  |  |
| Color semantics |  |  |  |
| Icon relevance |  |  |  |
| Symbol / formula necessity |  |  |  |
| Figure-caption symbiosis |  |  |  |
| Story fidelity, if applicable |  |  |  |
| Reviewer readiness |  |  |  |

## Verdict

- Final verdict:
- Required return step if not PASS:
- Reason:

## Completion

If verdict is PASS: `S7-FINAL-JOINT-AUDIT complete. The whole workflow is complete.`

If verdict is not PASS: `S7-FINAL-JOINT-AUDIT ended with repair required. The workflow is not complete.`
