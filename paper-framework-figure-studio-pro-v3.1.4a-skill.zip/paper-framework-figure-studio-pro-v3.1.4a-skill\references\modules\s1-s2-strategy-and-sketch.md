# S1-S2 Strategy And Sketch Module

S1 diagnoses figure strategy and prepares S2 sketch cards.

S1 must include:

- reader question;
- figure role;
- candidate visual directions;
- paper-content anchors;
- core innovation modules and non-droppable core substeps;
- per-sketch candidate cards with title, explanation, legend, text budget, style-aware caption support note, story-paper closeness note when applicable, and reader understanding test.

The first S2 low-fidelity hand-drawn exploration batch must include story-driven or storyboard candidates by default. For the default 6-8 sketch set, at least 2 candidates should have a clear paper-close story arc unless the user explicitly forbids story-like sketches or the paper is genuinely unsuitable. S1 must label those candidates and write the story-paper closeness note before S2 image generation.

S2 generates 6-8 separate low-fidelity raster sketches. The sketches may be divergent and reader-hook oriented, but they must not invent paper facts.

Hard raster gate for S2: every sketch must be generated through Image Gen, ChatGPT Create Image, or another approved image-generation API and accepted as `.png`, `.jpg`, `.jpeg`, or `.webp`. SVG/HTML/Mermaid/canvas/PPT/PDF/code-drawn sketches are invalid.

S2 should use large icons, rough module groups, simple data-flow marks, sparse labels, and clear first-glance hooks.

Story-like or metaphorical sketches are required as part of the first S2 exploration batch by default, but only when the story stays close to the target paper's own mechanism and uses common concepts that readers can easily connect back to the paper. Do not use a distant analogy merely to make the sketch look interesting. The accompanying caption support note must explicitly bridge the story to the paper.

Do not add symbols, formula-like tokens, or decorative technical marks unless the sketch cannot express the paper's core idea without them.

Do not execute S3 in the same reply.
