# S6-FINAL-SELECT Final Selection Report Template

Use this template when S6-FINAL-SELECT selects the final architecture reference from S5-CANDIDATE-IMAGE candidates.

## Metadata

- artifact_id: s6-final-selection-report
- canonical_relative_path: outputs/S6-final-selection/final-selection-report.md
- selected_reference_final: outputs/S5-candidate-images/candidate-01.png
- default_next_step: S7-FOREGROUND-IMAGE

## Selected Final Reference

- Selected image:
- Candidate ID:
- Why this candidate is the final reference:
- Theme elements to preserve for S7/S8:
- Figure-vs-caption split:
- Semantic density budget:
- SVG/PPT buildability notes:
- Known limitations before S7-FOREGROUND-IMAGE:

## Paper Recheck

| Check | Paper/source evidence | Candidate result | Action |
|---|---|---|---|
| Core method/algorithm/model structure |  |  | keep/fix/drop |
| Required modules |  |  | keep/fix/drop |
| Terminology |  |  | keep/fix/drop |
| Arrow/data/control relations |  |  | keep/fix/drop |
| Key contribution claims |  |  | keep/fix/drop |
| Figure-vs-caption split |  |  | keep/fix/drop |
| SVG/PPT buildability |  |  | keep/fix/drop |
| Density/readability for a paper figure |  |  | keep/fix/drop |

## Reorganization / Writing Feedback

| Draft expression | Figure organization | Evidence anchor | Communication benefit | Risk | Suggested manuscript revision |
|---|---|---|---|---|---|
|  |  |  |  |  |  |

## Candidate Ranking

| Rank | Candidate | Paper fit | First-glance appeal | 10-second comprehension | Semantic density | SVG/PPT feasibility | Precision | Decision |
|---|---|---|---|---|---|---|---|---|
| 1 | candidate-01.png |  |  |  |  |  |  | select |

## S7-FOREGROUND-IMAGE Handoff Prompt

```text
请按照 paper-framework-figure-studio-pro skill 的要求，根据当前状态和已登记产物，进入 S7-FOREGROUND-IMAGE，以 S6-FINAL-SELECT 选中的 S5-CANDIDATE-IMAGE 最终架构图和已记录主题元素清单为来源，生成一张或多张 foreground-only 无底纹元素集合图，至少包含 `outputs/S7-foreground-image/rimg-no-texture-final-01.png`，必要时追加 `rimg-no-texture-final-02.png` 等。它不只是去掉底纹，还必须去掉边框、外框、分区框、格线、连接线、箭头、箭头头、文字标签、标题和说明，只保留 S8-SVG-PPT 需要分割并转换为 SVG 的可复用前景图元；布局要利于 SVG 提取，尽量减少遮挡、粘连、交错、嵌套和重叠。同时保存 `outputs/S7-foreground-image/foreground-only-manifest.json`，记录来源候选图、每张集合图覆盖的主题元素、生成方式、限制说明和 S8-SVG-PPT 输入路径。
```



