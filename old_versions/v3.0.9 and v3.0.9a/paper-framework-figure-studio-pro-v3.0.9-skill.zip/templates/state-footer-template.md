# State Banner Template

Every text or artifact-building reply must start with this visible banner before any analysis, table, report, or prompt:

```text
全流程：S0-PAPER-FOUNDATION -> S1-FIGURE-STRATEGY -> S2-SKETCH-EXPLORE -> S3-DIRECTION-SELECT -> S4-CANDIDATE-BRIEF -> S5-CANDIDATE-IMAGE -> S6-FINAL-SELECT -> S7-FOREGROUND-IMAGE -> S8-SVG-PPT -> S9-FIGURE-TEXT
当前 step：<current_step>
默认下一步：<default_next_step 或 已完成>
```

If state is not loaded, write `unknown` as the current step and immediately initialize or load `figure-studio-runs/<project_id>/state/project-state.json`.

After the main body, print key reports and decision prompts inline. Do not only save reports to files.


