# Prompt Template

All default prompts, option prompts, and fallback prompts must begin with the skill prefix for Chinese users:

```text
请按照 paper-framework-figure-studio-pro skill 的要求，根据当前状态和已登记产物，
```

Every text reply must end with this exact standalone line:

```text
如果不知道如何提问，请说：请使用 paper-framework-figure-studio-pro 根据当前状态判断下一步
```

## S2-SKETCH-EXPLORE Image Prompt

Generate low-fidelity global-exploration sketches for the target paper framework figure. Use the environment image route: Image Gen in Codex, Create Image / ChatGPT Images 2.0 in ChatGPT web, or another approved image API only if neither is available. Generate each sketch as a separate image call and save/register it separately. Do not create a contact sheet, stitched board, SVG/HTML/canvas/Mermaid/PPT-shape substitute, or hand-drawn replacement.

Default canvas aspect ratio is 16:9 unless changed by the user. Default and minimum count is 6 diverse sketches; maximum is 8. Keep the sketches broad and eye-catching across different reader hooks, visual metaphors, layout grammars, reader paths, density/detail levels, visual communication styles, and first-glance emphasis. They may be more divergent than later steps, but they must not invent paper facts.

Use the paper reading to distill the big framework, not to draw every paper detail. Use large clear icons, module silhouettes, rough grouping, simple data-flow symbols, and at most short module/step titles. Avoid dense labels, long text, many formulas, tiny icons, and tangled connectors.

Apply the vector-first minimal semantic rule: sketch only the figure layer. Move definitions, equation explanations, hyperparameters, repeated algorithm substeps, and long terminology mapping to later caption/legend/body text. Default to 3-6 main modules, one dominant flow, 0-3 secondary flows, and no formulas unless one formula is visually indispensable.

After the images, print only a compact next-step prompt and the unsure-user fallback.

## S5-CANDIDATE-IMAGE Prompt

Generate formal first-round paper-framework candidates for local refinement. Use the environment image route and generate every candidate separately. Do not create a contact sheet or stitched candidate board.

Default canvas aspect ratio is 16:9 unless changed by the user. Default count is 6 candidates as a `2 low-fidelity directions x 3 visual communication style treatments` matrix unless the user changed the matrix.

Keep paper meaning fixed across all candidates, but do not mechanically mirror the manuscript draft's current organization. Use the S0-PAPER-FOUNDATION deep-reading report, method/algorithm/model notes, S1-FIGURE-STRATEGY/S3-DIRECTION-SELECT decisions, and S4-CANDIDATE-BRIEF candidate board brief, especially the per-candidate theme element inventory and total-coverage check. Vary visual grammar, focal hierarchy, panel rhythm, label density, local-detail display, style treatment, callout strategy, reader path, and non-contradictory organization. These must remain paper framework figures: not posters, not hero images, and not dense PPT-slide pages.

If a candidate reorganizes draft modules, steps, or mechanism narration, record the source evidence, communication benefit, risk, and suggested manuscript revision in S4/S6 rather than treating the change as a silent assumption.

Design with later SVG/PPT conversion in mind: prefer separable icons, clear module bodies, simple geometric visual tokens, short labels, and controlled data-flow relations. Avoid painterly textures, photo-realism, complex translucency, tiny decorative details, and fused shapes that are difficult to vectorize.

Each candidate prompt must honor its figure-vs-caption split: keep the image as a clean cognitive map and leave formula definitions, detailed algorithm text, caveats, experimental context, and long explanations for S9-FIGURE-TEXT. Icons are landmarks for major objects/processes, not a dense dictionary of every term.

After the images, print only a compact next-step prompt and the unsure-user fallback. S6-FINAL-SELECT will review the candidates and select the final reference.

## S7-FOREGROUND-IMAGE Prompt

Use only after S6-FINAL-SELECT has selected the final S5-CANDIDATE-IMAGE reference.

Generate one or more foreground-only no-texture element collection sheets:

```text
outputs/S7-foreground-image/rimg-no-texture-final-01.png
outputs/S7-foreground-image/rimg-no-texture-final-02.png  # optional when needed
```

Use the environment image route and generate this image separately. In Codex, use Image Gen. In ChatGPT web, use Create Image / ChatGPT Images 2.0. If neither is available, use another approved image API and record the reason.

The source is the S6-FINAL-SELECT selected final reference and recorded theme-element inventory. The output is not merely the final without texture. It must remove texture, underlays, borders, outer frames, region boxes, grid lines, connector lines, arrows, arrowheads, all text labels, titles, descriptions, and explanatory callouts. It must keep only reusable foreground elements for S8-SVG-PPT SVG extraction. The layout must be SVG-friendly: reduce occlusion, fusion, overlap, nesting, contact between different icons, and crossed or tangled regions. Split into multiple collection sheets if that is cleaner for extraction.

Also save:

```text
outputs/S7-foreground-image/foreground-only-manifest.json
```

The manifest records the selected source reference path, generation route, limitations, S8-SVG-PPT input path, every collection sheet path, and which theme elements each sheet covers.

After the image and manifest, print the S8-SVG-PPT default prompt with the mandatory skill prefix.

## S8-SVG-PPT Artifact Prompt

Use only after S7-FOREGROUND-IMAGE has produced or registered `rimg-no-texture-final-01.png`.

S8-SVG-PPT must generate a self-contained PPTX and cannot be replaced by a single new image or concept explanation.

Before building, check whether S8-SVG-PPT already has prior outputs or state records. If yes, run S8-SVG-PPT rewind cleanup first. Then strictly follow the foreground SVG catalog route:

1. Confirm the S6-FINAL-SELECT selected final reference and S7-FOREGROUND-IMAGE foreground-only element collection sheet(s) exist.
2. Segment/identify reusable foreground elements from `rimg-no-texture-final-01.png` and any extra collection sheets listed in `foreground-only-manifest.json`.
3. Exclude connector lines, arrows, arrowheads, borders, frames, text, titles, descriptions, backgrounds, texture, and decorative underlays.
4. Write `outputs/S8-svg-ppt/_work/icon_catalog_spec.json`.
5. Generate safe titled SVG elements.
6. Build `outputs/S8-svg-ppt/s8-svg-ppt-delivery.pptx` with `scripts/figure_studio_s8_svg_catalog_ppt.js`, using `--reference-final` for the S6-FINAL-SELECT selected final reference and `--no-texture-final` for the primary foreground-only element collection sheet.

The PPTX must contain slide 1 with the grayscale S6-FINAL-SELECT selected final reference as the map page, slide 2 with the original S6-FINAL-SELECT selected final reference, and slide 3+ with movable, editable embedded SVG icon / foreground-element pages. The SVG assets must be embedded inside the PPTX. The completion reply must provide a download/artifact link to `outputs/S8-svg-ppt/s8-svg-ppt-delivery.pptx`; in Codex/local environments, render the actual PPTX path as a Markdown file link when possible, and in ChatGPT web attach/export the PPTX artifact. If the runtime cannot create PPTX artifacts, stop and report the limitation rather than producing an image.


