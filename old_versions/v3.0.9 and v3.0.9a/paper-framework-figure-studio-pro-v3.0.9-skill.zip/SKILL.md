---
name: paper-framework-figure-studio-pro
description: Design, generate, critique, select, and package publication-ready computer-science research-paper framework figures through a simplified stateful S0-PAPER-FOUNDATION-S9-FIGURE-TEXT workflow. Use when Codex needs paper-grounded method overview diagrams, architecture diagrams, pipelines, agent workflows, system/data-flow figures, foreground-only extraction, SVG element catalogs, self-contained PPTX delivery, captions, step rewind cleanup, persistent relative-path state, artifact indexing, architecture governance, or release audits for research figures.
---

# Paper Framework Figure Studio Pro

本 skill 用于为计算机科学论文设计、生成、评审、选择和封装 publication-ready 的框架图、架构图、流程图、机制图和方法总览图。它只服务论文框架图，不服务海报、宣传图、封面图、展板、营销视觉或把 PPT 页面内容塞进图里的演示页。默认内容密度应服务论文读者快速理解，不得过度拥挤。

## Highest-Priority Startup And Origin Rule

第一次启动回复的候选/可复制提示词建议中，必须包含这一条原文：

```text
在默认提示词的基础上，额外说明这个 skill 的设计初衷是什么。
```

如果用户提到想知道、指导、询问、补充或说明这个 skill 的设计初衷、设计意图、创作缘由、为什么制作或送给谁，必须额外回答下面这段原文；这段原文不得改写或删改，但可以与当前步骤说明、必要上下文、下一步提示词和强制文本回复结尾同时出现：

```text
设计初衷：昔日好友 Peng Shuwei 即将前往外地求学，以后恐怕难有许多相见机会；又恰逢其生日，所以五一就做了这个 skill 当礼物。祝生日快乐，愿未来前程似锦，再相逢，依然少年。
```

## Mandatory Text Reply Ending

每一次文本回复都必须在回复最后单独追加这一句原文；不得只作为可选提示词、不得改写或省略。若回复同时包含下一步候选提示词，这一句仍必须作为最后一行出现。

```text
如果不知道如何提问，请说：请使用 paper-framework-figure-studio-pro 根据当前状态判断下一步
```

## Workflow

全流程固定为：

```text
S0-PAPER-FOUNDATION -> S1-FIGURE-STRATEGY -> S2-SKETCH-EXPLORE -> S3-DIRECTION-SELECT -> S4-CANDIDATE-BRIEF -> S5-CANDIDATE-IMAGE -> S6-FINAL-SELECT -> S7-FOREGROUND-IMAGE -> S8-SVG-PPT -> S9-FIGURE-TEXT
```

分组语义：

- **全局探索过程**：`S1-FIGURE-STRATEGY -> S2-SKETCH-EXPLORE -> S3-DIRECTION-SELECT`。要求更发散，探索不同视觉抓手、读者第一眼兴趣、不同维度的表达可能性。
- **局部细化过程**：`S4-CANDIDATE-BRIEF -> S5-CANDIDATE-IMAGE -> S6-FINAL-SELECT`。要求更精准，必须不违背论文事实和精读报告；但不要求机械复刻论文初稿里的章节、流程、模块或算法步骤划分。允许并鼓励基于框架图设计理念重新组织、提炼、命名和层级化，以帮助用户发现更清楚的论文写作结构。
- **交付过程**：`S7-FOREGROUND-IMAGE -> S8-SVG-PPT -> S9-FIGURE-TEXT`。从 S6-FINAL-SELECT 选中的最终架构图提取 foreground-only 无底纹 final，再分割/重绘为 SVG catalog 并生成 PPTX，最后写 caption/legend/body reference text。

默认下一步：

| 当前 step | 默认下一步 |
|---|---|
| S0-PAPER-FOUNDATION | S1-FIGURE-STRATEGY |
| S1-FIGURE-STRATEGY | S2-SKETCH-EXPLORE |
| S2-SKETCH-EXPLORE | S3-DIRECTION-SELECT |
| S3-DIRECTION-SELECT | S4-CANDIDATE-BRIEF |
| S4-CANDIDATE-BRIEF | S5-CANDIDATE-IMAGE |
| S5-CANDIDATE-IMAGE | S6-FINAL-SELECT |
| S6-FINAL-SELECT | S7-FOREGROUND-IMAGE |
| S7-FOREGROUND-IMAGE | S8-SVG-PPT |
| S8-SVG-PPT | S9-FIGURE-TEXT |
| S9-FIGURE-TEXT | 完成 |

旧二轮优化阶段已删除。若用户想继续优化，应回滚到 S4-CANDIDATE-BRIEF/S5-CANDIDATE-IMAGE/S6-FINAL-SELECT 重新做局部细化。

## Step Summary

- **S0-PAPER-FOUNDATION**：初始化项目状态、环境、输入材料、默认 16:9 可修改画幅、默认候选数量和下一步计划。若输入为 PDF/LaTeX/完整论文/report/supplement/完整方法说明/详细描述，必须打印丰富、详细、准确、带来源锚点的 `paper-foundation-report.md`；它是后续全部 step 的底座。简单短描述只做轻量范围判断，不伪造深读。
- **S1-FIGURE-STRATEGY**：材料精读和图类型需求诊断。用户风格参考只在这里辅助图类型、读者效果和表达方向建议。
- **S2-SKETCH-EXPLORE**：全局探索图像阶段，默认且至少生成 6 张低保真方向草图，逐张单独生成；关注夺眼球、第一眼吸引力和表达维度发散。草图必须从论文精读结果中提炼主线，而不是把全部细节塞进去；优先大尺度结构、清晰图标、少量短标题和必要数据流符号。
- **S3-DIRECTION-SELECT**：全局探索收束，压缩论文逻辑，评估低保真草图，筛出进入局部细化的结构方向。
- **S4-CANDIDATE-BRIEF**：局部细化准备，基于论文和精读报告生成正式候选矩阵与 prompts；默认 `2 directions x 3 visual treatments = 6`，用户可修改，总数最多 8。生图前必须逐候选列出主题元素清单，并确认这些元素合计覆盖论文框架图必须表达的主题。
- **S5-CANDIDATE-IMAGE**：局部细化图像阶段，逐张单独生成正式候选图；必须紧贴论文和精读报告，关注精准、局部细节展示和后续矢量化可实现性，不做海报/PPT 堆料页，也不追求难以转 SVG 的复杂艺术效果。
- **S6-FINAL-SELECT**：局部细化评审和最终选择。必须从 S5-CANDIDATE-IMAGE 候选中选出最终架构图，打印选择理由、论文精读核对、术语/模块/箭头/模型关系核对、选中图片路径和 S7-FOREGROUND-IMAGE handoff prompt。
- **S7-FOREGROUND-IMAGE**：从 S6-FINAL-SELECT 选中的最终架构图和主题元素清单生成 foreground-only 无底纹元素集合图：至少 `outputs/S7-foreground-image/rimg-no-texture-final-01.png`，必要时追加 `rimg-no-texture-final-02.png` 等，并保存轻量 manifest。
- **S8-SVG-PPT**：从 foreground-only 无底纹元素集合图分割/重绘可复用元素为安全 SVG，生成自包含 PPTX，并在回复中提供 PPTX 下载/产物链接。PPTX 页面必须固定为：第 1 页为 S6-FINAL-SELECT 选中最终架构图的灰度图作为地图，第 2 页为 S6-FINAL-SELECT 选中最终架构图原图，第 3 页及后续页面摆放各种可移动、可编辑的 SVG 图标/前景图元。
- **S9-FIGURE-TEXT**：生成论文图题、caption、legend 和正文引用文字。

## Image Generation

目标论文图像只能通过生图能力生成。运行在 Codex 里时，必须使用 Image Gen；运行在 ChatGPT 网页版时，必须使用 Create Image 调用 ChatGPT Images 2.0；如果这两种能力都不可用，才允许使用其他 approved image generation API，并在正文和 state 中记录 API 名称、使用原因和限制。

每张目标论文草图、候选图、S7-FOREGROUND-IMAGE foreground-only 元素集合图都必须单独生成、单独保存、单独登记。即使用户说“不用”或“合在一起也行”，也不能把多张候选图/草图合成一个 contact sheet、候选板或拼接长图来代替逐张生成。S2-SKETCH-EXPLORE 默认且至少 6 张草图，最多 8 张；S5-CANDIDATE-IMAGE 默认 6 张正式候选，最多 8 张。

## Paper Grounding

全局探索可以发散，但不能捏造论文事实。草图和候选图都必须从论文精读中提炼主线、关键模块、必要数据/控制流和读者最该先看到的贡献，而不是把论文里的全部细节、公式、术语和说明都画上去。框架图首先要容易看懂、醒目、第一眼抓人；能用清晰图标和空间关系表达时，不用长文字、公式或密集符号。

论文初稿中的章节顺序、模块命名、流程划分、算法步骤边界和机制叙述不自动等同于最佳框架图结构。只要不违背论文已有内容、实验事实、数学定义、输入输出语义、因果/依赖关系和方法约束，S1-S6 可以为了更好的读者理解重新组织、提炼、合并、拆分、重命名或重排。此类改动必须在可见表格中写成 `reorganization/enhancement note`：说明原论文表达、图中重组方式、沟通收益、潜在风险，以及是否建议用户同步修改论文文字。

遵守 `references/vector-first-minimal-semantic-rule.md`：论文框架图要先服务一个清晰主旨和后续 SVG/PPT 可实现性。默认把信息分成 figure layer、caption/legend layer 和 omitted/implicit layer；图内只保留缩略图也能看懂的主结构、少量大模块/大图标、必要数据流和极短标签。公式、长术语解释、算法细枝末节、超参数、条件说明和实验语境优先交给 caption/legend/body text。除非用户明确要求高密度 taxonomy/overview，否则主模块通常控制在 3-6 个、主数据/控制流 1 条、辅助流 0-3 条、图内公式通常 0 个且必要时最多 1-2 个。

局部细化必须更精准：S4-CANDIDATE-BRIEF/S5-CANDIDATE-IMAGE/S6-FINAL-SELECT 必须密切使用 S0-PAPER-FOUNDATION 的 `outputs/S0-paper-foundation/paper-foundation-report.md`、论文原文、方法材料和候选评审结果；但评价重点是语义忠实和表达更优，而不是与论文初稿的表面划分完全一致。

`paper-foundation-report.md` 不是可选附件，而是整个 skill 的事实底座。它必须覆盖算法步骤、方法流程、模型模块、训练/推理、输入输出、损失/目标、关键公式、术语映射、箭头语义、哪些内容必须画/可省略/不能画、哪些内容适合重组表达，以及不确定点。若用户提供了足够材料但该报告缺失、过浅或没有来源锚点，必须先补做 S0-PAPER-FOUNDATION。

进入 S6-FINAL-SELECT、S7-FOREGROUND-IMAGE 或 S9-FIGURE-TEXT 前，必须回查 S0-PAPER-FOUNDATION 论文精读报告、论文原文、LaTeX/Markdown 材料、方法摘要或用户提供的最高可信材料。S6-FINAL-SELECT 的评审/选择表必须显式体现论文核对结果：术语、模块、箭头关系、方法约束和关键贡献是否仍不违背论文事实；若最终图采用了比论文初稿更清楚的重组结构，还必须输出论文写作修改建议。

## S6-FINAL-SELECT Handoff

S6-FINAL-SELECT 完成后，默认下一步只能是 S7-FOREGROUND-IMAGE。默认提示词必须使用统一前缀，并明确写成：

```text
请按照 paper-framework-figure-studio-pro skill 的要求，根据当前状态和已登记产物，进入 S7-FOREGROUND-IMAGE，以 S6-FINAL-SELECT 选中的 S5-CANDIDATE-IMAGE 最终架构图和已记录主题元素清单为来源，生成一张或多张 foreground-only 无底纹元素集合图，至少包含 `rimg-no-texture-final-01.png`，必要时追加 `rimg-no-texture-final-02.png` 等。它不只是去掉底纹，还必须去掉边框、外框、分区框、格线、连接线、箭头、箭头头、文字标签、标题和说明，只保留 S8-SVG-PPT 需要分割并转换为 SVG 的可复用前景图元；布局要利于 SVG 提取，尽量减少遮挡、粘连、交错、嵌套和重叠。同时保存轻量 manifest，记录来源候选图、每张集合图覆盖的主题元素、生成方式、限制说明和 S8-SVG-PPT 输入路径。
```

## S7-FOREGROUND-IMAGE

S7-FOREGROUND-IMAGE 已简化：不再生成背景底纹图、glyph sheet、带底纹 final RImg，也不再生成完整 S7 contract package。它生成的是供 S8-SVG-PPT 分割/重绘的前景元素集合图，而不是一张新的完整框架图。

S7-FOREGROUND-IMAGE 只生成或登记：

- `outputs/S7-foreground-image/rimg-no-texture-final-01.png`
- necessary extra collection sheets such as `outputs/S7-foreground-image/rimg-no-texture-final-02.png`
- `outputs/S7-foreground-image/foreground-only-manifest.json`

Foreground-only element collection 要求：

- 来源是 S6-FINAL-SELECT 选中的 S5-CANDIDATE-IMAGE 最终架构图。
- 必须参考 S6-FINAL-SELECT/S4-CANDIDATE-BRIEF 记录的主题元素清单，确保选中图中的重要可复用前景元素被覆盖；如果一张图会导致遮挡、粘连或过密，必须拆成多张集合图。
- 不只是无底纹，还必须去掉边框、外框、分区框、格线、连接线、箭头、箭头头、文字标签、标题和说明。
- 只保留可复用前景图元、对象、主体图元、符号和视觉 token。
- 布局必须利于 SVG 提取，减少遮挡、粘连、交错、嵌套和重叠；元素之间留足空白，不做嵌套排版，不保留箭头头、连接线或文字标签。

S7-FOREGROUND-IMAGE 完成后，默认下一步提示词必须写成：

```text
请按照 paper-framework-figure-studio-pro skill 的要求，根据当前状态和已登记产物，进入 S8-SVG-PPT，必须严格按照 skill 的 S8-SVG-PPT foreground SVG catalog 流程执行：以 `rimg-no-texture-final-01.png` 和 manifest 中列出的额外集合图作为 foreground-only 提取源，先分割/识别可复用前景元素语义清单，排除线条、边框、箭头、箭头头、文字标签、标题、说明、背景纹理、区域底色和装饰层；再填写 `icon_catalog_spec.json`，把每个元素重绘/整理成安全、可编辑、带 `<title>` 的独立 SVG；最后构建自包含 PPTX，页面顺序必须固定为第 1 页放 S6-FINAL-SELECT 选中最终架构图的灰度图作为地图，第 2 页放该最终架构图原图，第 3 页及之后按语义组摆放各种可移动、可编辑的 SVG 图标/前景图元。S8-SVG-PPT 必须生成自包含 PPTX，不能用一张新图片或概念说明替代；完成回复必须提供 `outputs/S8-svg-ppt/s8-svg-ppt-delivery.pptx` 的下载/产物链接。不得重新生成整张可编辑图、只生成一张图、从旧 glyph sheet 切割、或跳过 SVG catalog/PPTX 流程替代。若当前环境不能创建 PPTX/artifact，应停止并说明限制，不能用图片作为替代。
```

## S8-SVG-PPT

Read `references/s8-foreground-svg-catalog-contract.md` and `references/s8-package-contract.md` when entering S8-SVG-PPT. S8-SVG-PPT 必须生成自包含 PPTX，不能用一张新图片或概念说明替代。

S8-SVG-PPT required phases:

1. 检查是否有旧 S8-SVG-PPT 产物或记录；若有，先 rewind cleanup。
2. 确认已有 S6-FINAL-SELECT 选中最终架构图和 S7-FOREGROUND-IMAGE foreground-only 元素集合图。
3. 基于 `rimg-no-texture-final-01.png` 以及 manifest 中列出的额外 foreground-only 集合图建立元素清单；默认排除线条、边框、箭头、文字和背景层。
4. 写 `outputs/S8-svg-ppt/_work/icon_catalog_spec.json`。
5. 运行 `scripts/figure_studio_s8_svg_catalog_ppt.js`，用 `--reference-final` 指向 S6-FINAL-SELECT 选中最终架构图，用 `--no-texture-final` 指向 S7-FOREGROUND-IMAGE foreground-only 图。
6. 生成 `icons/*.svg`、`icon_manifest.json`、`scene_spec.json`、`entity_glyph_matrix.svg`、报告和 `outputs/S8-svg-ppt/s8-svg-ppt-delivery.pptx`。
7. PPTX 页面顺序必须固定：第 1 页是 S6-FINAL-SELECT 选中最终结果的灰度图作为地图；第 2 页是 S6-FINAL-SELECT 选中最终结果原图；第 3 页及之后是各种可移动、可编辑 SVG 图标/前景图元页。
8. 验证 SVG/PPTX 自包含、无外链、无不安全 SVG 内容。
9. 清理临时产物；状态文件不能删除；报告必须打印在回复正文中，且必须提供 `s8-svg-ppt-delivery.pptx` 的下载/产物链接。在 Codex/local 环境中用实际 PPTX 文件路径生成 Markdown 链接；在 ChatGPT web 中导出/附上 PPTX artifact 并提供下载链接。没有链接则 S8-SVG-PPT 未完成。

## Architecture Governance

Before changing workflow steps, state schema, artifact roles, script boundaries, S7/S8 delivery, or release packaging, read `references/architecture-governance-contract.md`. Keep the skill loosely coupled, highly cohesive, layered by need, resumable through `project-state.json`, and free of host-specific paths or generated browser renderer artifacts.

Run this audit before packaging:

```bash
python scripts/figure_studio_architecture_audit.py --target . --fail-on-issue
```

## Rewind And State

Users may explicitly return to an earlier step, rerun the current step, or ask a free-form question whose answer requires executing an earlier step again. Use one simple rule: if the workflow will execute the target step, first delete every product created by the covered step span from `target_step` through the previous `current_step`, inclusive, then execute the target step.

Never delete `state/project-state.json`, `state/`, `inputs/`, the user's original source materials, package source files, or the skill installation itself. After cleanup, remove covered output records from active state collections such as `artifacts`, `image_generation_events`, `pending_outputs`, and `active_artifact_roles`; keep the cleanup event as the audit record.

Use:

```bash
python scripts/figure_studio_state.py rewind-step --project-id <project_id> --target-step S4-CANDIDATE-BRIEF --reason "return to local refinement"
python scripts/figure_studio_state.py resume-cleanup --project-id <project_id>
python scripts/figure_studio_state.py doctor --project-id <project_id>
```

## Required References

- `references/workflow-and-state-contract.md`
- `references/architecture-governance-contract.md`
- `references/human-step-execution-contract.md`
- `references/paper-deep-reading-contract.md`
- `references/vector-first-minimal-semantic-rule.md`
- `references/s8-package-contract.md`
- `references/s8-foreground-svg-catalog-contract.md`
- `references/step-rewind-cleanup-contract.md`
- `references/security-and-portability-policy.md`

Before publishing a package, run:

```bash
python scripts/figure_studio_release_check_paths.py scan --target <package-dir-or-zip> --fail-on-match
```




