# Changelog

## 3.0.9-acknowledgement-wording-patch

- Updated README acknowledgement wording to thank `bristol的刘欣阳同学` for providing the semiDFL materials, placed after the opening description in both Chinese and English.

## 3.0.9-readme-architecture-docs-patch

- Added bilingual architecture diagrams named `Paper Figure Studio Workflow Architecture` under `assets/architecture/`.
- Rewrote the README as a Chinese/English guide covering design philosophy, internal resources, S0-S9 workflow, S7/S8 puzzle-workbench delivery, vector-first aesthetics, and non-contradictory paper-structure reorganization.

## 3.0.9-s8-pptx-and-final-line-wording-patch

- Changed the mandatory final text-reply line to `如果不知道如何提问，请说：请使用 paper-framework-figure-studio-pro 根据当前状态判断下一步`.
- Revised the S8-SVG-PPT high-priority rule to say S8-SVG-PPT must generate a self-contained PPTX and cannot be replaced by a single new image or concept explanation.

## 3.0.9-design-origin-additional-answer-patch

- Changed the design-origin trigger rule to an exact additional answer: the required original dedication text must be included unchanged, while normal step context, next prompts, and the mandatory final reply line may still appear.

## 3.0.9-vector-first-minimal-semantics-patch

- Added `references/vector-first-minimal-semantic-rule.md` to make one-visual-sentence design, figure-vs-caption splitting, semantic density budgets, and SVG/PPT buildability explicit workflow rules.
- Added default density budgets: usually 3-6 main modules, one dominant flow, 0-3 secondary flows, no visible formulas unless essential, and landmark icons instead of many tiny dictionary icons.
- Updated S0/S1/S2/S4/S5/S6 guidance, prompt templates, state schema, and review rubrics so details that hurt readability or vector conversion move to caption/legend/body text instead of the image.
- Made `如果不知道如何提问，请说：请使用 paper-framework-figure-studio-pro 根据当前状态判断下一步` a mandatory exact standalone final line for every text reply.
- Strengthened S8-SVG-PPT completion: it must provide the PPTX download/artifact link and enforce slide 1 as the grayscale S6-selected map, slide 2 as the original S6-selected final, and slide 3+ as movable/editable SVG icon pages.

## 3.0.9-design-origin-and-diversity-patch

- Added the mandatory first-startup design-origin prompt suggestion and exact design-origin response rule.
- Raised S2-SKETCH-EXPLORE to at least 6 separate low-fidelity sketches with taxonomy-angle diversity, paper-derived simplification, low text/formula density, and clear icon guidance.
- Added S4/S5 requirements for per-candidate theme element inventories, total coverage checks, local-detail strategy, and SVG/PPT vectorization-friendly candidate design.
- Strengthened S7-FOREGROUND-IMAGE into one or more foreground-only element collection sheets derived from the selected final reference and theme elements, with manifest coverage tracking.
- Added the non-contradictory reorganization principle: figures may improve manuscript draft structure without changing paper meaning, and must surface useful writing revision suggestions.

## 3.0.9-architecture-governance

- Added `references/architecture-governance-contract.md` to make loose coupling, high cohesion, layered on-demand calls, transformation isolation, failure resume, abstraction, memory, retrievability, and vulnerability checks part of the operational contract.
- Added `scripts/figure_studio_architecture_audit.py` for release-time architecture and hygiene checks.
- Removed generated browser renderer HTML/JS output from the S8-SVG-PPT builder.
- Updated state schema, SKILL.md, README, agent metadata, and release checklist to require architecture governance before packaging or structural changes.

## 3.0.8-step-name-refactor

- Simplified the workflow to `S0-PAPER-FOUNDATION -> S1-FIGURE-STRATEGY -> S2-SKETCH-EXPLORE -> S3-DIRECTION-SELECT -> S4-CANDIDATE-BRIEF -> S5-CANDIDATE-IMAGE -> S6-FINAL-SELECT -> S7-FOREGROUND-IMAGE -> S8-SVG-PPT -> S9-FIGURE-TEXT`.
- Grouped steps into global exploration, local refinement, and delivery.
- Promoted `outputs/S0-paper-foundation/paper-foundation-report.md` to the required rich, detailed, accurate, source-anchored foundation for every later step when paper/source material is available.
- Moved final reference selection into S6-FINAL-SELECT.
- Simplified S7-FOREGROUND-IMAGE to a single foreground-only no-texture final plus lightweight manifest.
- Updated S8-SVG-PPT to use `--reference-final` for the S6-FINAL-SELECT selected reference and `--no-texture-final` for the foreground-only extraction source.
- Removed obsolete finalization scripts, templates, and docs for the older multi-image support package route.
- Kept generalized covered-step rewind cleanup: clean covered products and active records, preserve the state file and cleanup audit event.


