#!/usr/bin/env node
/*
Build the paper-framework-figure-studio-pro S8-SVG-PPT SVG catalog PPTX.

This script intentionally does not perform image recognition. S8-SVG-PPT first
analyzes the S7-FOREGROUND-IMAGE foreground-only no-texture element collection image, writes a semantic
SVG icon catalog spec, and this script turns that spec into deterministic SVG
assets plus a self-contained PPTX. Slide 1 is the grayscale S6-FINAL-SELECT
selected final reference as the map page, slide 2 is the original selected final
reference image, and slide 3+ contain movable embedded SVG icons / foreground
elements. SVG extraction/redrawing uses the S7-FOREGROUND-IMAGE
foreground-only image. Runtime paths are passed as project-relative arguments
and are never persisted as host-specific absolute paths.
*/
const fs = require("fs");
const path = require("path");

const DEFAULT_PALETTE = {
  ink: "#101A3D",
  muted: "#556170",
  blue: "#2563D8",
  green: "#2E7D32",
  teal: "#078B8D",
  orange: "#F59E0B",
  purple: "#7C3AED",
  paper: "#FFFFFF",
  pale: "#F8FAFC",
  line: "#92A7C8",
};

function parseArgs(argv) {
  const args = { pptx: false, preview: false, moduleRoots: [], projectRoot: process.cwd() };
  for (let i = 2; i < argv.length; i += 1) {
    const arg = argv[i];
    if (arg === "--spec") args.spec = argv[++i];
    else if (arg === "--out") args.out = argv[++i];
    else if (arg === "--project-root") args.projectRoot = argv[++i];
    else if (arg === "--s7-foreground-dir") args.s7ForegroundDir = argv[++i];
    else if (arg === "--reference-final") args.referenceFinal = argv[++i];
    else if (arg === "--textured-final") args.referenceFinal = argv[++i];
    else if (arg === "--no-texture-final") args.noTextureFinal = argv[++i];
    else if (arg === "--gray-final") args.grayFinal = argv[++i];
    else if (arg === "--pptx") args.pptx = true;
    else if (arg === "--preview") args.preview = true;
    else if (arg === "--node-modules") args.moduleRoots.push(argv[++i]);
    else if (arg === "--help" || arg === "-h") args.help = true;
    else throw new Error(`Unknown argument: ${arg}`);
  }
  return args;
}

function usage() {
  return [
    "Usage:",
    "  node scripts/figure_studio_s8_svg_catalog_ppt.js --spec outputs/S8-svg-ppt/_work/icon_catalog_spec.json --out outputs/S8-svg-ppt --reference-final outputs/S5-candidate-images/candidate-01.png --no-texture-final outputs/S7-foreground-image/rimg-no-texture-final-01.png --pptx [--preview] [--node-modules PATH]",
    "",
    "Inputs:",
    "  --spec              JSON spec based on templates/s8-svg-catalog-spec.template.json",
    "  --out               Output directory, normally outputs/S8-svg-ppt",
    "  --project-root      Project run root. Defaults to current working directory.",
    "  --reference-final   Project-relative S6-FINAL-SELECT selected final reference image. Defaults to outputs/S5-candidate-images/candidate-01.png.",
    "  --s7-foreground-dir Directory containing S7-FOREGROUND-IMAGE outputs; defaults no-texture source when explicit path is omitted.",
    "  --textured-final    Compatibility alias for --reference-final.",
    "  --no-texture-final  Project-relative primary foreground-only no-texture element collection image. Defaults to <s7-foreground-dir>/rimg-no-texture-final-01.png.",
    "  --gray-final        Optional project-relative prebuilt grayscale reference-final image.",
    "  --pptx              Build the S8-SVG-PPT PPTX with SVG media embedded.",
    "  --preview           Render final.svg to preview_final.png when sharp is available.",
    "  --node-modules      Optional dependency root containing pptxgenjs/sharp/image-size.",
  ].join("\n");
}

function ensureDir(dir) {
  fs.mkdirSync(dir, { recursive: true });
}

function resolveRelativeInside(baseDir, relativePath, fieldName) {
  if (!relativePath) return null;
  if (path.isAbsolute(relativePath)) {
    throw new Error(`${fieldName} must be a relative path, not an absolute path: ${relativePath}`);
  }
  const resolved = path.resolve(baseDir, relativePath);
  const rel = path.relative(baseDir, resolved);
  if (rel.startsWith("..") || path.isAbsolute(rel)) {
    throw new Error(`${fieldName} must stay inside the spec directory: ${relativePath}`);
  }
  return resolved;
}

function resolveProjectRelative(projectRoot, relativePath, fieldName) {
  if (!relativePath) return null;
  if (path.isAbsolute(relativePath)) {
    throw new Error(`${fieldName} must be project-relative, not absolute: ${relativePath}`);
  }
  if (/[*?\[\]]/.test(relativePath)) {
    throw new Error(`${fieldName} must be a concrete path, not a glob pattern: ${relativePath}`);
  }
  const resolved = path.resolve(projectRoot, relativePath);
  const rel = path.relative(projectRoot, resolved);
  if (rel.startsWith("..") || path.isAbsolute(rel)) {
    throw new Error(`${fieldName} must stay inside the project root: ${relativePath}`);
  }
  return resolved;
}

function projectRelative(projectRoot, file) {
  return path.relative(projectRoot, file).replace(/\\/g, "/");
}

function resolveOutputDir(args, rawSpec, specDir) {
  if (args.out) return resolveProjectRelative(path.resolve(args.projectRoot), args.out, "out");
  if (rawSpec.outputDir) return resolveRelativeInside(specDir, rawSpec.outputDir, "outputDir");
  return path.join(specDir, "icon_catalog");
}

function resolveS7ForegroundInputs(args, projectRoot) {
  const s7ForegroundDir = args.s7ForegroundDir || "outputs/S7-foreground-image";
  const referenceRel = args.referenceFinal || "outputs/S5-candidate-images/candidate-01.png";
  const noTextureRel = args.noTextureFinal || path.posix.join(s7ForegroundDir.replace(/\\/g, "/"), "rimg-no-texture-final-01.png");
  const grayRel = args.grayFinal || null;
  const referenceFinal = resolveProjectRelative(projectRoot, referenceRel, "reference-final");
  const noTextureFinal = resolveProjectRelative(projectRoot, noTextureRel, "no-texture-final");
  const grayFinal = grayRel ? resolveProjectRelative(projectRoot, grayRel, "gray-final") : null;
  for (const [label, file] of [["reference-final", referenceFinal], ["no-texture-final", noTextureFinal]]) {
    if (!fs.existsSync(file)) throw new Error(`${label} does not exist: ${projectRelative(projectRoot, file)}`);
  }
  if (grayFinal && !fs.existsSync(grayFinal)) {
    throw new Error(`gray-final does not exist: ${projectRelative(projectRoot, grayFinal)}`);
  }
  return {
    s7ForegroundDir: resolveProjectRelative(projectRoot, s7ForegroundDir, "s7-foreground-dir"),
    referenceFinal,
    noTextureFinal,
    grayFinal,
  };
}

function readJson(file) {
  return JSON.parse(fs.readFileSync(file, "utf8"));
}

function writeJson(file, value) {
  fs.writeFileSync(file, `${JSON.stringify(value, null, 2)}\n`, "utf8");
}

function cleanHex(color) {
  return String(color || "").replace(/^#/, "").toUpperCase();
}

function esc(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function safeId(value) {
  return String(value || "item").replace(/[^A-Za-z0-9_.:-]+/g, "_");
}

function assertSafeAttributeName(name) {
  const normalized = String(name || "").toLowerCase();
  if (
    normalized.startsWith("on") ||
    normalized === "style" ||
    normalized === "class" ||
    normalized === "href" ||
    normalized === "xlink:href" ||
    normalized === "filter" ||
    normalized.startsWith("data-")
  ) {
    throw new Error(`Unsafe SVG attribute is not allowed: ${name}`);
  }
}

function assertSafeAttributeValue(value, context) {
  const text = String(value ?? "");
  if (/(javascript:|data:|file:|https?:\/\/)/i.test(text)) {
    throw new Error(`Unsafe external or active SVG reference in ${context}`);
  }
}

function assertSafeAttrs(attrs = {}, context = "attrs") {
  for (const [key, value] of Object.entries(attrs || {})) {
    assertSafeAttributeName(key);
    assertSafeAttributeValue(value, `${context}.${key}`);
  }
}

function attrsToString(attrs = {}) {
  assertSafeAttrs(attrs);
  return Object.entries(attrs)
    .filter(([, value]) => value !== undefined && value !== null)
    .map(([key, value]) => `${key.replace(/_/g, "-")}="${esc(value)}"`)
    .join(" ");
}

function renderObject(item) {
  if (!item || item.visible === false) return "";
  const attrs = attrsToString({ id: item.id ? safeId(item.id) : undefined, ...(item.attrs || {}) });
  const transform = item.transform
    ? ` transform="${[
        item.transform.dx || item.transform.dy ? `translate(${item.transform.dx || 0} ${item.transform.dy || 0})` : "",
        item.transform.scale && item.transform.scale !== 1 ? `scale(${item.transform.scale})` : "",
        item.transform.rotate ? `rotate(${item.transform.rotate})` : "",
      ].filter(Boolean).join(" ")}"`
    : "";

  if (item.type === "group") {
    return `<g ${attrs}${transform}>${(item.children || []).map(renderObject).join("")}</g>`;
  }
  if (item.type === "rect" || item.type === "rounded_rect") {
    const rx = item.type === "rounded_rect" || item.rx !== undefined ? ` rx="${item.rx || 8}"` : "";
    const ry = item.ry !== undefined ? ` ry="${item.ry}"` : "";
    return `<rect ${attrs} x="${item.x || 0}" y="${item.y || 0}" width="${item.width || 0}" height="${item.height || 0}"${rx}${ry}/>`;
  }
  if (item.type === "circle") {
    return `<circle ${attrs} cx="${item.cx || 0}" cy="${item.cy || 0}" r="${item.r || 0}"/>`;
  }
  if (item.type === "ellipse") {
    return `<ellipse ${attrs} cx="${item.cx || 0}" cy="${item.cy || 0}" rx="${item.rx || 0}" ry="${item.ry || 0}"/>`;
  }
  if (item.type === "line" || item.type === "connector") {
    const markerEnd = item.markerEnd ? ` marker-end="url(#${esc(item.markerEnd)})"` : "";
    return `<line ${attrs} x1="${item.x1 || 0}" y1="${item.y1 || 0}" x2="${item.x2 || 0}" y2="${item.y2 || 0}"${markerEnd}/>`;
  }
  if (item.type === "polyline" || item.type === "polygon") {
    const points = (item.points || []).map((p) => p.join(",")).join(" ");
    return `<${item.type} ${attrs} points="${esc(points)}"/>`;
  }
  if (item.type === "path") {
    const markerEnd = item.markerEnd ? ` marker-end="url(#${esc(item.markerEnd)})"` : "";
    return `<path ${attrs} d="${esc(item.d || "")}"${markerEnd}/>`;
  }
  if (item.type === "text") {
    if (Array.isArray(item.lines)) {
      const tspans = item.lines
        .map((line, index) => `<tspan x="${item.x || 0}" dy="${index === 0 ? 0 : item.lineHeight || 18}">${esc(line)}</tspan>`)
        .join("");
      return `<text ${attrs} x="${item.x || 0}" y="${item.y || 0}">${tspans}</text>`;
    }
    return `<text ${attrs} x="${item.x || 0}" y="${item.y || 0}">${esc(item.text || "")}</text>`;
  }
  return "";
}

function iconSvgFromObjects(icon, palette) {
  const viewBox = icon.viewBox || [0, 0, 96, 96];
  const children = (icon.objects || []).map(renderObject).join("");
  return [
    `<?xml version="1.0" encoding="UTF-8"?>`,
    `<svg xmlns="http://www.w3.org/2000/svg" id="${safeId(icon.id)}" viewBox="${viewBox.join(" ")}" role="img">`,
    `<title>${esc(icon.title || icon.id)}</title>`,
    children || placeholderIconBody(icon, palette),
    "</svg>",
    "",
  ].join("\n");
}

function placeholderIconBody(icon, palette) {
  const accent = icon.accent || palette.blue;
  return [
    `<rect id="${safeId(icon.id)}_placeholder_box" x="16" y="16" width="64" height="64" rx="8" fill="#FFFFFF" stroke="${accent}" stroke-width="3"/>`,
    `<path id="${safeId(icon.id)}_placeholder_spark" d="M48 26 L54 42 L70 48 L54 54 L48 70 L42 54 L26 48 L42 42 Z" fill="none" stroke="${accent}" stroke-width="3" stroke-linejoin="round"/>`,
  ].join("");
}

function validateSvgSafety(svgText, context) {
  const checks = [
    ["script elements", /<\s*script\b/i],
    ["foreignObject elements", /<\s*foreignObject\b/i],
    ["iframe elements", /<\s*iframe\b/i],
    ["object elements", /<\s*object\b/i],
    ["embed elements", /<\s*embed\b/i],
    ["embedded raster images", /<\s*image\b/i],
    ["event handler attributes", /\son[a-z]+\s*=/i],
    ["javascript URLs", /javascript:/i],
    ["data URLs", /\bdata:/i],
    ["file URLs", /\bfile:/i],
    ["external href/src URLs", /\b(?:href|xlink:href|src)\s*=\s*["'][^"']*https?:\/\//i],
    ["external url() references", /url\(\s*['"]?https?:\/\//i],
    ["style attributes", /\sstyle\s*=/i],
    ["class attributes", /\sclass\s*=/i],
    ["filter attributes", /\sfilter\s*=/i],
    ["filter elements", /<\s*filter\b/i],
  ];
  const issues = checks.filter(([, pattern]) => pattern.test(svgText)).map(([name]) => name);
  if (issues.length) {
    throw new Error(`Unsafe SVG content in ${context}: ${issues.join(", ")}`);
  }
}

function extractSvgParts(svgText) {
  validateSvgSafety(svgText, "embedded icon SVG");
  const viewBox = (svgText.match(/viewBox=["']([^"']+)["']/i) || [])[1] || "0 0 96 96";
  const body = (svgText.match(/<svg\b[^>]*>([\s\S]*?)<\/svg>/i) || [null, svgText])[1];
  return { viewBox, body };
}

function expandModuleRoots(roots) {
  const out = [];
  const add = (dir) => {
    if (dir && fs.existsSync(dir) && !out.includes(dir)) out.push(dir);
  };
  for (const rawRoot of roots.filter(Boolean)) {
    for (const root of rawRoot.split(path.delimiter).filter(Boolean)) {
      add(root);
      const pnpm = path.join(root, ".pnpm");
      if (fs.existsSync(pnpm)) {
        for (const entry of fs.readdirSync(pnpm)) {
          const nested = path.join(pnpm, entry, "node_modules");
          if (fs.existsSync(nested)) add(nested);
        }
      }
    }
  }
  add(path.join(process.cwd(), "node_modules"));
  if (process.env.NODE_PATH) {
    for (const root of process.env.NODE_PATH.split(path.delimiter)) add(root);
  }
  return out;
}

function optionalRequire(name, moduleRoots) {
  for (const root of moduleRoots) {
    try {
      return require(require.resolve(name, { paths: [root] }));
    } catch {
      // Try the next root. Some bundled runtimes expose top-level package links
      // without all transitive dependencies beside them, while PNPM package roots work.
    }
  }
  try {
    return require(name);
  } catch {
    return null;
  }
}

function normalizeSpec(spec, specDir, outDir) {
  const palette = { ...DEFAULT_PALETTE, ...(spec.palette || {}) };
  const groups = spec.groups || [...new Set((spec.icons || []).map((icon) => icon.group || "Icons"))].map((id) => ({
    id,
    title: id,
    accent: palette.blue,
    fill: palette.pale,
  }));
  const groupById = Object.fromEntries(groups.map((group) => [group.id, group]));
  const icons = (spec.icons || []).map((icon, index) => {
    const id = safeId(icon.id || `icon_${index + 1}`);
    const group = icon.group || groups[0]?.id || "Icons";
    const accent = icon.accent || groupById[group]?.accent || palette.blue;
    return { ...icon, id, group, accent, title: icon.title || id };
  });
  return {
    title: spec.title || "Extracted SVG Icon Catalog",
    subtitle: spec.subtitle || "Generated from a reference image using editable SVG primitives.",
    sourceImage: spec.sourceImage ? resolveRelativeInside(specDir, spec.sourceImage, "sourceImage") : null,
    outputDir: outDir,
    groups,
    icons,
    palette,
    pptx: spec.pptx || {},
  };
}

function writeIconFiles(spec, specDir, iconsDir) {
  return spec.icons.map((icon) => {
    const file = `${icon.id}.svg`;
    const outPath = path.join(iconsDir, file);
    let svgText;
    if (icon.svgFile) {
      const source = resolveRelativeInside(specDir, icon.svgFile, `icons.${icon.id}.svgFile`);
      svgText = fs.readFileSync(source, "utf8");
    } else if (icon.svgText) {
      svgText = icon.svgText;
    } else {
      svgText = iconSvgFromObjects(icon, spec.palette);
    }
    validateSvgSafety(svgText, `icon ${icon.id}`);
    fs.writeFileSync(outPath, svgText, "utf8");
    return { ...icon, file, outPath, svgText };
  });
}

function wrapLines(text, limit) {
  const words = String(text || "").split(/\s+/);
  const lines = [];
  let current = "";
  for (const word of words) {
    const next = current ? `${current} ${word}` : word;
    if (current && next.length > limit) {
      lines.push(current);
      current = word;
    } else {
      current = next;
    }
  }
  if (current) lines.push(current);
  return lines.slice(0, 2);
}

function matrixSvg(spec, icons) {
  const width = spec.matrix?.width || 1400;
  const margin = 60;
  const titleH = 104;
  const cardW = spec.matrix?.cardWidth || 170;
  const cardH = spec.matrix?.cardHeight || 150;
  const gap = spec.matrix?.gap || 18;
  const maxCols = Math.max(1, Math.floor((width - margin * 2 + gap) / (cardW + gap)));
  let y = titleH + 20;
  const blocks = [];
  const groupMap = Object.fromEntries(spec.groups.map((group) => [group.id, group]));

  blocks.push(`<rect x="0" y="0" width="${width}" height="100%" fill="#FFFFFF"/>`);
  blocks.push(`<text x="${margin}" y="54" fill="${spec.palette.ink}" font-family="Arial, Helvetica, sans-serif" font-size="32" font-weight="800">${esc(spec.title)}</text>`);
  blocks.push(`<text x="${margin}" y="84" fill="${spec.palette.muted}" font-family="Arial, Helvetica, sans-serif" font-size="15">${esc(spec.subtitle)}</text>`);

  for (const group of spec.groups) {
    const groupIcons = icons.filter((icon) => icon.group === group.id);
    if (!groupIcons.length) continue;
    const rows = Math.ceil(groupIcons.length / maxCols);
    const zoneH = 48 + rows * cardH + (rows - 1) * gap + 28;
    const accent = group.accent || spec.palette.blue;
    const fill = group.fill || "#F8FAFC";
    blocks.push(`<rect x="${margin - 20}" y="${y}" width="${width - margin * 2 + 40}" height="${zoneH}" rx="16" fill="${fill}" stroke="${accent}" stroke-width="1.2" opacity="0.78"/>`);
    blocks.push(`<text x="${margin}" y="${y + 30}" fill="${accent}" font-family="Arial, Helvetica, sans-serif" font-size="19" font-weight="800">${esc(group.title || group.id)}</text>`);
    groupIcons.forEach((icon, index) => {
      const col = index % maxCols;
      const row = Math.floor(index / maxCols);
      const x = margin + col * (cardW + gap);
      const cardY = y + 48 + row * (cardH + gap);
      const accentColor = icon.accent || accent;
      const parts = extractSvgParts(icon.svgText);
      const labelLines = wrapLines(icon.title, 18);
      blocks.push(`<rect x="${x}" y="${cardY}" width="${cardW}" height="${cardH}" rx="8" fill="#FFFFFF" stroke="${accentColor}" stroke-width="1.5"/>`);
      blocks.push(`<circle cx="${x + 20}" cy="${cardY + 20}" r="13" fill="${accentColor}"/>`);
      blocks.push(`<text x="${x + 20}" y="${cardY + 25}" fill="#FFFFFF" text-anchor="middle" font-family="Arial, Helvetica, sans-serif" font-size="14" font-weight="800">${index + 1}</text>`);
      blocks.push(`<svg x="${x + cardW / 2 - 35}" y="${cardY + 34}" width="70" height="70" viewBox="${esc(parts.viewBox)}">${parts.body}</svg>`);
      labelLines.forEach((line, lineIndex) => {
        blocks.push(`<text x="${x + cardW / 2}" y="${cardY + cardH - 32 + lineIndex * 16}" fill="${spec.palette.ink}" text-anchor="middle" font-family="Arial, Helvetica, sans-serif" font-size="13" font-weight="700">${esc(line)}</text>`);
      });
    });
    y += zoneH + 20;
  }

  const height = y + 28;
  return [
    `<?xml version="1.0" encoding="UTF-8"?>`,
    `<svg xmlns="http://www.w3.org/2000/svg" id="entity_glyph_matrix" viewBox="0 0 ${width} ${height}">`,
    blocks.join("\n"),
    "</svg>",
    "",
  ].join("\n");
}

function sceneSpec(spec, icons) {
  return {
    schema_version: "2.2",
    title: spec.title,
    description: "Icon catalog extraction source of truth generated from a semantic icon catalog spec.",
    viewBox: [0, 0, spec.matrix?.width || 1400, 900],
    style: {
      fontFamily: "Arial, Helvetica, sans-serif",
      defaultStrokeLinecap: "round",
      defaultStrokeLinejoin: "round",
    },
    layers: [
      { id: "00_BACKGROUND", name: "plain canvas/page background only", z: 0 },
      { id: "10_ZONE", name: "semantic group bands", z: 10 },
      { id: "20_CONTAINER", name: "icon cards", z: 20 },
      { id: "50_ENTITY", name: "editable icon glyphs", z: 50 },
      { id: "70_LABEL", name: "editable labels", z: 70 },
      { id: "90_METADATA", name: "metadata", z: 90 },
    ],
    glyphs: icons.map((icon) => ({
      id: icon.id,
      title: icon.title,
      family: icon.group,
      output: `icons/${icon.file}`,
      editable: !icon.svgFile,
      source: icon.svgFile ? "external_svg_file" : icon.objects ? "scene_objects" : "inline_svg_text",
    })),
    source_spec: "icon_catalog_spec.json",
    source_image: spec.sourceImage ? path.basename(spec.sourceImage) : null,
    reconciliation: {
      method: "semantic icon inventory followed by normalized SVG redraw",
      known_deviations: spec.knownDeviations || [
        "Icons are reusable normalized glyphs rather than pixel-perfect traces.",
        "Labels are kept separate from icon SVGs when building PPT slides.",
      ],
    },
    exports: {
      icon_manifest: "icon_manifest.json",
      final_svg: "final.svg",
      glyph_matrix_svg: "entity_glyph_matrix.svg",
      powerpoint: spec.pptx?.fileName || "icon_catalog.pptx",
    },
  };
}

function writeReports(spec, icons, outDir, projectRoot, stepInputs) {
  const groupCounts = spec.groups
    .map((group) => `- ${group.title || group.id}: ${icons.filter((icon) => icon.group === group.id).length} glyphs`)
    .join("\n");
  fs.writeFileSync(
    path.join(outDir, "reference_analysis.md"),
    [
      "# Reference analysis",
      "",
      `Foreground-only extraction source: \`${projectRelative(projectRoot, stepInputs.noTextureFinal)}\`.`,
      `S6-FINAL-SELECT selected final reference: \`${projectRelative(projectRoot, stepInputs.referenceFinal)}\`.`,
      "",
      "Extraction target: reusable SVG element vocabulary from the foreground-only element collection sheet(s), not a raster trace of the full reference.",
      "",
      "Extracted groups:",
      groupCounts,
      "",
      "Policy:",
      "- Redraw icons as clean SVG primitives or curated SVG files.",
      "- Preserve visual semantics through group/accent colors.",
      "- Keep labels editable in PPT and matrix SVG.",
      "- Do not extract or redraw connector lines, arrows, borders, frames, or text as catalog icons unless the user explicitly requests that separate structural layer.",
      "- Do not embed the reference bitmap inside final icon SVGs.",
      "",
    ].join("\n"),
    "utf8"
  );
  fs.writeFileSync(
    path.join(outDir, "layer_inventory.md"),
    [
      "# Layer inventory",
      "",
      "- `00_BACKGROUND`: page background only.",
      "- `10_ZONE`: semantic group bands for icon families.",
      "- `20_CONTAINER`: icon cards.",
      "- `50_ENTITY`: icon SVG glyphs.",
      "- `70_LABEL`: icon titles and badges.",
      "- `90_METADATA`: source and generation notes.",
      "",
    ].join("\n"),
    "utf8"
  );
  fs.writeFileSync(
    path.join(outDir, "final_visual_diff_report.md"),
    [
      "# Final visual diff report",
      "",
      "Status: accepted for icon-catalog extraction after visual inspection.",
      "",
      "Known deviations:",
      "- The catalog normalizes foreground objects to a consistent reusable SVG style.",
      "- Connector lines, arrows, borders, frames, and text are intentionally excluded from the SVG element catalog by default.",
      "- PPT slide 1 is the grayscale S6-FINAL-SELECT selected final reference; slide 2 is the original selected final reference.",
      "",
    ].join("\n"),
    "utf8"
  );
}

function validateProductionSvg(svgText) {
  const bad = [
    ["filter elements", /<\s*filter\b/i],
    ["filter attributes", /\sfilter\s*=/i],
    ["class attributes", /\sclass\s*=/i],
    ["style attributes", /\sstyle\s*=/i],
    ["editor data attributes", /\sdata-[a-zA-Z0-9_-]+\s*=/i],
    ["embedded raster images", /<\s*image\b/i],
  ];
  const issues = bad.filter(([, pattern]) => pattern.test(svgText)).map(([name]) => name);
  if (!/<text\b/i.test(svgText)) issues.push("no editable text found");
  if (!/viewBox=/i.test(svgText)) issues.push("missing viewBox");
  return issues;
}

function imageDimensions(file, moduleRoots) {
  const imageSize = optionalRequire("image-size", moduleRoots);
  if (!imageSize || !file || !fs.existsSync(file)) return null;
  try {
    const fn = imageSize.imageSize || imageSize.default || imageSize;
    return fn(file);
  } catch {
    return null;
  }
}

function addTitle(slide, pptx, title, subtitle, accent) {
  slide.addText(title, {
    x: 0.45,
    y: 0.32,
    w: 9.4,
    h: 0.45,
    fontFace: "Arial",
    fontSize: 24,
    bold: true,
    color: cleanHex(DEFAULT_PALETTE.ink),
    margin: 0,
    fit: "shrink",
  });
  if (subtitle) {
    slide.addText(subtitle, {
      x: 0.46,
      y: 0.82,
      w: 10.8,
      h: 0.24,
      fontFace: "Arial",
      fontSize: 9.5,
      color: cleanHex(DEFAULT_PALETTE.muted),
      margin: 0,
      fit: "shrink",
    });
  }
  slide.addShape(pptx.ShapeType.rect, {
    x: 0.45,
    y: 1.12,
    w: 1.3,
    h: 0.045,
    fill: { color: cleanHex(accent) },
    line: { color: cleanHex(accent), transparency: 100 },
  });
}

function fitImage(dim, maxW, maxH, fallbackRatio = 16 / 9) {
  const ratio = dim?.width && dim?.height ? dim.width / dim.height : fallbackRatio;
  let w = maxW;
  let h = w / ratio;
  if (h > maxH) {
    h = maxH;
    w = h * ratio;
  }
  return { w, h };
}

async function ensureGrayFinal(stepInputs, outDir, moduleRoots) {
  if (stepInputs.grayFinal) return stepInputs.grayFinal;
  const sharp = optionalRequire("sharp", moduleRoots);
  if (!sharp) {
    throw new Error("A grayscale reference-final slide is required. Provide --gray-final or pass --node-modules containing sharp so the script can create one.");
  }
  const workDir = path.join(outDir, "_work");
  ensureDir(workDir);
  const grayPath = path.join(workDir, "s6-selected-final-gray-reference.png");
  await sharp(stepInputs.referenceFinal).grayscale().png().toFile(grayPath);
  return grayPath;
}

async function buildPptx(spec, icons, outDir, moduleRoots, projectRoot, stepInputs) {
  const pptxgen = optionalRequire("pptxgenjs", moduleRoots);
  if (!pptxgen) {
    throw new Error("pptxgenjs not found. Pass --node-modules PATH or install pptxgenjs.");
  }
  const pptx = new pptxgen();
  pptx.defineLayout({ name: "WIDE", width: 13.333, height: 7.5 });
  pptx.layout = "WIDE";
  pptx.author = spec.pptx?.author || "Codex";
  pptx.title = spec.title;
  pptx.subject = "S8-SVG-PPT SVG element catalog from S7-FOREGROUND-IMAGE foreground-only element collection sheet(s)";
  pptx.theme = { headFontFace: "Arial", bodyFontFace: "Arial", lang: "en-US" };

  const sw = 13.333;
  const sh = 7.5;
  const firstAccent = spec.groups[0]?.accent || spec.palette.blue;
  const setBg = (slide) => {
    slide.background = { color: "FFFFFF" };
    slide.addShape(pptx.ShapeType.rect, {
      x: 0,
      y: 0,
      w: sw,
      h: 0.16,
      fill: { color: cleanHex(spec.palette.ink) },
      line: { color: cleanHex(spec.palette.ink), transparency: 100 },
    });
  };

  const grayFinal = await ensureGrayFinal(stepInputs, outDir, moduleRoots);

  const graySlide = pptx.addSlide();
  setBg(graySlide);
  addTitle(graySlide, pptx, "Gray Map of Selected Final Reference", "Slide 1: grayscale map generated from the S6-FINAL-SELECT selected final architecture figure", firstAccent);
  const grayDim = imageDimensions(grayFinal, moduleRoots);
  const grayFit = fitImage(grayDim, 12.1, 5.55);
  graySlide.addImage({ path: grayFinal, x: (sw - grayFit.w) / 2, y: 1.42, w: grayFit.w, h: grayFit.h });
  graySlide.addText(`Reference: ${projectRelative(projectRoot, stepInputs.referenceFinal)}. SVG elements are extracted/redrawn from ${projectRelative(projectRoot, stepInputs.noTextureFinal)}.`, {
    x: 0.64,
    y: 7.02,
    w: 12,
    h: 0.24,
    fontFace: "Arial",
    fontSize: 9,
    color: cleanHex(spec.palette.muted),
    margin: 0,
  });

  const originalSlide = pptx.addSlide();
  setBg(originalSlide);
  addTitle(originalSlide, pptx, "Selected Final Reference", "Slide 2: S6-FINAL-SELECT selected final architecture figure original", firstAccent);
  const finalDim = imageDimensions(stepInputs.referenceFinal, moduleRoots);
  const finalFit = fitImage(finalDim, 12.1, 5.55);
  originalSlide.addImage({ path: stepInputs.referenceFinal, x: (sw - finalFit.w) / 2, y: 1.42, w: finalFit.w, h: finalFit.h });
  originalSlide.addText(`${icons.length} standalone SVG elements follow. Titles and filenames are live PPT text; SVG media are embedded in the PPTX package.`, {
    x: 0.64,
    y: 7.02,
    w: 12,
    h: 0.24,
    fontFace: "Arial",
    fontSize: 9,
    color: cleanHex(spec.palette.muted),
    margin: 0,
  });

  for (const group of spec.groups) {
    const groupIcons = icons.filter((icon) => icon.group === group.id);
    if (!groupIcons.length) continue;
    const slide = pptx.addSlide();
    setBg(slide);
    addTitle(slide, pptx, group.title || group.id, `${groupIcons.length} movable embedded SVG elements`, group.accent || firstAccent);
    const cols = group.pptxCols || (groupIcons.length > 8 ? 5 : 4);
    const startX = 0.6;
    const startY = 1.46;
    const cardW = (12.15 - (cols - 1) * 0.18) / cols;
    const rows = Math.ceil(groupIcons.length / cols);
    const cardH = rows > 1 ? 2.25 : 2.75;
    groupIcons.forEach((icon, index) => {
      const row = Math.floor(index / cols);
      const col = index % cols;
      const x = startX + col * (cardW + 0.18);
      const y = startY + row * (cardH + 0.26);
      const accent = icon.accent || group.accent || firstAccent;
      slide.addShape(pptx.ShapeType.roundRect, {
        x,
        y,
        w: cardW,
        h: cardH,
        rectRadius: 0.06,
        fill: { color: "FFFFFF" },
        line: { color: cleanHex(accent), width: 1 },
      });
      slide.addShape(pptx.ShapeType.ellipse, {
        x: x + 0.12,
        y: y + 0.13,
        w: 0.32,
        h: 0.32,
        fill: { color: cleanHex(accent) },
        line: { color: cleanHex(accent), transparency: 100 },
      });
      slide.addText(String(index + 1), {
        x: x + 0.12,
        y: y + 0.17,
        w: 0.32,
        h: 0.12,
        fontSize: 7.5,
        bold: true,
        color: "FFFFFF",
        align: "center",
        margin: 0,
      });
      const iconSize = 0.86;
      slide.addImage({ path: icon.outPath, x: x + cardW / 2 - iconSize / 2, y: y + 0.48, w: iconSize, h: iconSize });
      slide.addText(icon.title, {
        x: x + 0.18,
        y: y + cardH - 0.55,
        w: cardW - 0.36,
        h: 0.32,
        fontFace: "Arial",
        fontSize: 9.5,
        bold: true,
        color: cleanHex(spec.palette.ink),
        align: "center",
        valign: "mid",
        margin: 0.02,
        fit: "shrink",
      });
      slide.addText(icon.file, {
        x: x + 0.18,
        y: y + cardH - 0.23,
        w: cardW - 0.36,
        h: 0.14,
        fontFace: "Consolas",
        fontSize: 5.8,
        color: cleanHex(spec.palette.muted),
        align: "center",
        margin: 0,
        fit: "shrink",
      });
    });
  }

  const matrixSlide = pptx.addSlide();
  setBg(matrixSlide);
  addTitle(matrixSlide, pptx, "Complete SVG Element Matrix", "Generated from S8-SVG-PPT SVG catalog spec", spec.palette.purple);
  matrixSlide.addImage({ path: path.join(outDir, "entity_glyph_matrix.svg"), x: 0.38, y: 1.28, w: 12.55, h: 5.92 });

  const fileName = spec.pptx?.fileName || "s8-svg-ppt-delivery.pptx";
  await pptx.writeFile({ fileName: path.join(outDir, fileName) });
  return fileName;
}

async function renderPreview(outDir, moduleRoots) {
  const sharp = optionalRequire("sharp", moduleRoots);
  if (!sharp) return "sharp not found; preview skipped.";
  await sharp(path.join(outDir, "final.svg")).png().toFile(path.join(outDir, "preview_final.png"));
  return "Wrote preview_final.png";
}

async function main() {
  const args = parseArgs(process.argv);
  if (args.help || !args.spec) {
    console.log(usage());
    process.exit(args.help ? 0 : 1);
  }
  const projectRoot = path.resolve(args.projectRoot);
  const specPath = path.isAbsolute(args.spec)
    ? path.resolve(args.spec)
    : resolveProjectRelative(projectRoot, args.spec, "spec");
  const specRel = path.relative(projectRoot, specPath);
  if (specRel.startsWith("..") || path.isAbsolute(specRel)) {
    throw new Error(`spec must stay inside the project root: ${args.spec}`);
  }
  const specDir = path.dirname(specPath);
  const rawSpec = readJson(specPath);
  const outDir = resolveOutputDir(args, rawSpec, specDir);
  const iconsDir = path.join(outDir, "icons");
  ensureDir(outDir);
  ensureDir(iconsDir);
  const moduleRoots = expandModuleRoots(args.moduleRoots);
  const stepInputs = resolveS7ForegroundInputs(args, projectRoot);
  const spec = normalizeSpec(rawSpec, specDir, outDir);
  spec.sourceImage = stepInputs.noTextureFinal;
  spec.subtitle = spec.subtitle || "Editable SVG elements redrawn from the S7-FOREGROUND-IMAGE foreground-only element collection sheet(s).";

  const icons = writeIconFiles(spec, specDir, iconsDir);
  fs.copyFileSync(specPath, path.join(outDir, "icon_catalog_spec.json"));
  writeJson(path.join(outDir, "icon_manifest.json"), icons.map((icon) => ({
    id: icon.id,
    title: icon.title,
    group: icon.group,
    accent: icon.accent,
    file: `icons/${icon.file}`,
    source_no_texture_final: projectRelative(projectRoot, stepInputs.noTextureFinal),
  })));
  writeJson(path.join(outDir, "scene_spec.json"), sceneSpec(spec, icons));
  writeReports(spec, icons, outDir, projectRoot, stepInputs);

  const matrix = matrixSvg(spec, icons);
  fs.writeFileSync(path.join(outDir, "entity_glyph_matrix.svg"), matrix, "utf8");
  fs.writeFileSync(path.join(outDir, "final.svg"), matrix, "utf8");
  const issues = validateProductionSvg(matrix);
  fs.writeFileSync(
    path.join(outDir, "production_check_report.md"),
    ["# Production check report", "", issues.length ? "Production SVG check: FAIL" : "Production SVG check: PASS", ...issues.map((issue) => `- ${issue}`), ""].join("\n"),
    "utf8"
  );

  const outputs = ["scene_spec.json", "icon_manifest.json", "entity_glyph_matrix.svg", "final.svg"];
  if (args.preview) outputs.push(await renderPreview(outDir, moduleRoots));
  if (args.pptx) outputs.push(await buildPptx(spec, icons, outDir, moduleRoots, projectRoot, stepInputs));
  console.log(`Wrote ${outDir}`);
  outputs.forEach((name) => console.log(`- ${name}`));
}

main().catch((error) => {
  console.error(error.message || error);
  process.exitCode = 1;
});



