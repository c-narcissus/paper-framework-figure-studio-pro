"""State schema defaults and workflow state construction."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from .constants import (
    ARTIFACT_ROLES,
    CANONICAL_OUTPUTS,
    DEFAULT_ROOT,
    DEFAULT_NEXT_STEP_BY_STEP,
    PENDING_CANONICAL_OUTPUTS,
    PREFERENCE_ANALYSIS_PATH,
    PREFERENCE_REFERENCE_ROOT,
    SCHEMA_VERSION,
    SKILL_NAME,
    SKILL_VERSION,
    STATE_RELATIVE_PATH,
    STEP_CLEANUP_EXTRA_DIRS,
    STEP_SEQUENCE,
    TEXT_REPLY_STEP_BANNER_TEMPLATE,
    WORKFLOW_STEPS,
    ATLAS_DISPLAY_POLICY,
    ATLAS_MANIFEST_PATH,
    ATLAS_BOARD_ROOT,
    ATLAS_BOARD_IDS,
)
from .paths import normalize_relative_path, safe_join, utc_now

def workflow_state(current_step: str = "S0-PAPER-FOUNDATION") -> list[dict[str, Any]]:
    rows = []
    current_index = [step for step, _, _, _ in WORKFLOW_STEPS].index(current_step)
    for step, mode, purpose, output_dir in WORKFLOW_STEPS:
        if step == current_step:
            status = "in_progress"
        elif WORKFLOW_STEPS.index((step, mode, purpose, output_dir)) < current_index:
            status = "completed"
        else:
            status = "pending"
        rows.append(
            {
                "step": step,
                "mode": mode,
                "purpose": purpose,
                "output_dir": output_dir,
                "canonical_output": CANONICAL_OUTPUTS[step],
                "default_next_step": DEFAULT_NEXT_STEP_BY_STEP[step],
                "status": status,
            }
        )
    return rows

def step_attempt_id(step: str, epoch: int) -> str:
    normalized_step = step.lower().replace("-", "_")
    return f"{normalized_step}-e{epoch:04d}"

def initial_step_runs(current_step: str, now: str) -> dict[str, dict[str, Any]]:
    current_index = [step for step, _, _, _ in WORKFLOW_STEPS].index(current_step)
    rows: dict[str, dict[str, Any]] = {}
    for index, (step, _, _, output_dir) in enumerate(WORKFLOW_STEPS):
        epoch = 1 if step == current_step else 0
        if step == current_step:
            status = "in_progress"
        elif index < current_index:
            status = "completed"
        else:
            status = "pending"
        rows[step] = {
            "step": step,
            "epoch": epoch,
            "attempt_id": step_attempt_id(step, epoch),
            "status": status,
            "output_dir": output_dir,
            "started_at": now if status == "in_progress" else None,
            "updated_at": now,
        }
    return rows

def ensure_step_runs(state: dict[str, Any]) -> dict[str, dict[str, Any]]:
    now = utc_now()
    current_step = state.get("current_step", "S0-PAPER-FOUNDATION")
    step_runs = state.setdefault("step_runs", {})
    for step, _, _, output_dir in WORKFLOW_STEPS:
        row = step_runs.setdefault(step, {})
        row.setdefault("step", step)
        row.setdefault("output_dir", output_dir)
        row.setdefault("epoch", 1 if step == current_step else 0)
        row.setdefault("attempt_id", step_attempt_id(step, int(row.get("epoch") or 0)))
        row.setdefault("status", "in_progress" if step == current_step else "pending")
        row.setdefault("started_at", now if step == current_step else None)
        row.setdefault("updated_at", now)
    return step_runs

def current_step_epoch(state: dict[str, Any], step: str) -> int:
    step_runs = ensure_step_runs(state)
    return int(step_runs.get(step, {}).get("epoch") or 0)

def mark_step_run_in_progress(state: dict[str, Any], step: str, bump_if_zero: bool = True) -> dict[str, Any]:
    step_runs = ensure_step_runs(state)
    row = step_runs[step]
    epoch = int(row.get("epoch") or 0)
    now = utc_now()
    if bump_if_zero and epoch == 0:
        epoch = 1
        row["epoch"] = epoch
        row["attempt_id"] = step_attempt_id(step, epoch)
        row["started_at"] = now
    row["status"] = "in_progress"
    row["updated_at"] = now
    step_order = [name for name, _, _, _ in WORKFLOW_STEPS]
    current_index = step_order.index(step)
    for other_step, other_row in step_runs.items():
        if other_step == step:
            continue
        if other_step not in step_order:
            continue
        other_index = step_order.index(other_step)
        other_epoch = int(other_row.get("epoch") or 0)
        other_row["status"] = "completed" if other_index < current_index and other_epoch > 0 else "pending"
        other_row["updated_at"] = now
    return row

def bump_step_epoch(state: dict[str, Any], step: str, status: str) -> dict[str, Any]:
    step_runs = ensure_step_runs(state)
    row = step_runs[step]
    now = utc_now()
    old_epoch = int(row.get("epoch") or 0)
    new_epoch = old_epoch + 1
    row.update(
        {
            "epoch": new_epoch,
            "attempt_id": step_attempt_id(step, new_epoch),
            "status": status,
            "started_at": now if status == "in_progress" else None,
            "updated_at": now,
        }
    )
    return {
        "step": step,
        "old_epoch": old_epoch,
        "new_epoch": new_epoch,
        "attempt_id": row["attempt_id"],
        "status": status,
    }

def ensure_output_dirs(run_dir: Path) -> None:
    safe_join(run_dir, "state").mkdir(parents=True, exist_ok=True)
    safe_join(run_dir, PREFERENCE_REFERENCE_ROOT).mkdir(parents=True, exist_ok=True)
    for _, _, _, output_dir in WORKFLOW_STEPS:
        safe_join(run_dir, output_dir).mkdir(parents=True, exist_ok=True)
    for extra_dirs in STEP_CLEANUP_EXTRA_DIRS.values():
        for output_dir in extra_dirs:
            safe_join(run_dir, output_dir).mkdir(parents=True, exist_ok=True)

def initial_state(project_id: str, run_dir: Path, title: str | None) -> dict[str, Any]:
    now = utc_now()
    return {
        "project_state_schema_version": SCHEMA_VERSION,
        "skill_name": SKILL_NAME,
        "skill_version": SKILL_VERSION,
        "project_id": project_id,
        "project_title": title or project_id,
        "created_at": now,
        "updated_at": now,
        "current_step": "S0-PAPER-FOUNDATION",
        "workflow_plan": workflow_state("S0-PAPER-FOUNDATION"),
        "step_sequence": list(STEP_SEQUENCE),
        "default_next_step_by_step": DEFAULT_NEXT_STEP_BY_STEP,
        "step_runs": initial_step_runs("S0-PAPER-FOUNDATION", now),
        "output_root": normalize_relative_path(Path(DEFAULT_ROOT) / project_id),
        "state_file": normalize_relative_path(STATE_RELATIVE_PATH),
        "path_storage_policy": "all paths stored in project-state.json are relative; live host-specific image embed paths are not persisted",
        "paper_framework_non_poster_policy": (
            "This skill is only for research-paper framework/architecture/pipeline/mechanism figures. "
            "It must not produce posters, marketing visuals, cover art, decorative exhibition boards, hero-style illustrations, or PPT-slide content pages. "
            "All candidate images, S7-FOREGROUND-IMAGE foreground-only outputs, and S8-SVG-PPT PPTX artifacts must avoid posterization, avoid crowded PPT-like content dumping unless explicitly requested, and prioritize paper logic, module relations, arrow semantics, terminology accuracy, and reviewer readability."
        ),
        "default_canvas_policy": {
            "default_aspect_ratio": "16:9",
            "user_editable": True,
            "first_reply_disclosure_required": True,
            "applies_to_steps": ["S2-SKETCH-EXPLORE", "S5-CANDIDATE-IMAGE", "S7-FOREGROUND-IMAGE"],
            "user_adjustment_examples": ["4:3", "1:1", "3:2", "double-column landscape", "journal-specified size"],
            "state_recording_policy": "If the user changes the aspect ratio, record the requested ratio in project state and carry it through later image prompts.",
        },
        "default_density_policy": (
            "Default figure density is readable and not crowded. "
            "Do not turn a paper framework figure into a poster or a PPT-slide content page with many bullet blocks, long paragraphs, tiny labels, dense callout boxes, or tangled connectors. "
            "Use vector-first minimal semantics by default: keep the image as a cognitive map, move definitions/equations/caveats/details to caption/legend/body text, and increase density only when the user explicitly asks for a high-density, survey-style, taxonomy, overview, or information-first figure while still preserving target-size readability."
        ),
        "vector_first_minimal_semantic_policy": {
            "status": "active",
            "contract": "references/vector-first-minimal-semantic-rule.md",
            "one_visual_sentence": True,
            "default_main_module_range": "3-6",
            "default_dominant_flow_count": 1,
            "default_secondary_flow_range": "0-3",
            "default_formula_policy": "usually 0 visible formulas; at most 1-2 only when essential to the mechanism",
            "icon_policy": "Use large landmark icons for major entities/modules/processes, not many tiny dictionary icons.",
            "figure_caption_split": "Figure carries the cognitive map; caption/legend/body text carries definitions, equation meaning, constraints, caveats, hyperparameters, and long explanations.",
            "vector_buildability": "Candidates should be rebuildable from simple SVG/PPT primitives, separable foreground icons, short editable labels, and clean connector grammar.",
        },
        "artifact_role_registry": ARTIFACT_ROLES,
        "active_artifact_roles": {},
        "s0_paper_foundation_policy": {
            "status": "input_depth_sensitive",
            "contract": "references/paper-deep-reading-contract.md",
            "output_artifact": "outputs/S0-paper-foundation/paper-foundation-report.md",
            "must_print_in_reply_body": True,
            "foundation_status": "required_foundation_for_all_later_steps",
            "quality_bar": "When triggered, the paper foundation report must be rich, detailed, source-anchored, accurate, and sufficient for every later visual decision; generic summaries are invalid.",
            "simple_description_policy": "If the user only provides a short/simple description, do lightweight scoping and record deep_reading_status as not_triggered_simple_description. Do not invent a deep report from missing paper evidence.",
            "triggering_inputs": [
                "paper PDF",
                "LaTeX source",
                "Markdown/full paper text",
                "paper report",
                "supplement",
                "complete method notes",
                "detailed method description",
            ],
            "if_material_missing": "Record deep_reading_status as pending_input and do not pretend the method was read.",
            "required_sections": [
                "problem/assumptions/related-work gap",
                "source section/page/evidence anchors",
                "ordered algorithm steps",
                "model architecture/components/modules",
                "training flow",
                "inference flow",
                "inputs/outputs/data flow",
                "losses/objectives/equations",
                "constraints/assumptions",
                "terminology-to-module-to-arrow map",
                "figure/table/experiment interpretation when available",
                "reviewer/defense lens",
                "figure-relevant exclusions and uncertainty list",
            ],
            "minimum_detail_requirements": [
                "section/page/source anchors for every important claim when available",
                "ordered method pipeline in the paper's own terms",
                "algorithm/model/module inventory with inputs, outputs, roles, and dependencies",
                "equation/objective/loss interpretation tied to visual implications",
                "terminology normalization table: paper term -> figure label -> allowed shorthand",
                "arrow semantics table: source -> target -> meaning -> evidence anchor",
                "what must be visible, what may stay implicit, and what must not be drawn",
                "semantic density budget: figure layer, caption/legend layer, omitted/implicit layer, label/formula limits, icon landmark plan, and vector-buildability risks",
            ],
            "explanation_pattern": "intuition -> formula_or_algorithm_step -> concrete_example -> limitation_or_assumption -> figure_implication",
            "reuse_policy": "All later S1-S9 decisions, prompts, reviews, selections, and delivery notes must use this report as the paper_content_anchor and algorithm_model_anchor; do not rely only on a core-innovation summary.",
            "non_goals": ["code reading", "paper-code crosswalk", "static reader", "external skill files or assets"],
        },
        "artifact_epoch_policy": (
            "Every generated artifact records artifact_role, step_epoch, and attempt_id when possible. "
            "Rewinding or rerunning a step bumps the covered target_step..from_step epochs; covered artifact records "
            "are removed from active state and remain represented only by the cleanup event audit trail."
        ),
        "s0_paper_foundation_template": "references/s0-paper-foundation-template.md",
        "preference_reference_transfer_policy": "references/preference-reference-transfer-policy.md",
        "human_step_execution_contract": "references/human-step-execution-contract.md",
        "response_prompt_options_policy": "references/response-prompt-options-policy.md",
        "architecture_governance_contract": "references/architecture-governance-contract.md",
        "release_absolute_path_scan_checklist": "references/release-absolute-path-scan-checklist.md",
        "architecture_governance_policy": {
            "status": "active",
            "contract": "references/architecture-governance-contract.md",
            "audit_command": "python scripts/figure_studio_architecture_audit.py --target . --fail-on-issue",
            "loose_coupling": "Workflow constants, state schema, artifact indexing, image registration, cleanup, SVG/PPTX building, delivery validation, and release checks stay in separate modules.",
            "high_cohesion": "Each script owns one responsibility; shared Python helpers live under scripts/figure_studio_core and S8 package construction stays in the Node builder.",
            "layered_on_demand_calls": "Load step/module references only when needed; S0/S1 paper grounding, S2/S5 image generation, S7 foreground extraction, S8 SVG/PPTX delivery, and S9 text writing stay separate.",
            "transformation_isolation": "S0 reports, S2 sketches, S5 candidates, S6 selection, S7 foreground-only output, S8 SVG/PPTX delivery, and S9 text outputs use distinct output roots and artifact roles.",
            "failure_resume": "State, step_runs, step_epoch, attempt_id, cleanup events, and project-relative artifact records are the resumable checkpoint system.",
            "abstraction": "Scripts accept relative paths, specs, artifact roles, and CLI arguments; no paper-specific coordinates, local user paths, or hard-coded project folders.",
            "memory": "After interruption, project-state.json is the source of truth; chat memory alone is never enough for selected references or pending outputs.",
            "retrievability": "Durable artifacts need stable artifact_role, relative_path, summary, tags, source relation, and active/pending state records.",
            "vulnerability_checks": [
                "python scripts/figure_studio_state.py validate --project-id <project_id>",
                "python scripts/figure_studio_state.py doctor --project-id <project_id>",
                "python scripts/figure_studio_architecture_audit.py --target . --fail-on-issue",
                "python scripts/figure_studio_validate_production_svg.py outputs/S8-svg-ppt/final.svg",
                "python scripts/figure_studio_s8_clean_delivery.py validate --output-dir outputs/S8-svg-ppt",
                "python scripts/figure_studio_release_check_paths.py scan --target <package-dir-or-zip> --fail-on-match",
            ],
            "forbidden_release_remnants": [
                "__pycache__",
                "*.pyc",
                ".skill_test_runs",
                "editable_renderer.html",
                "renderer_core.js",
                "host-specific absolute paths",
                "secrets or credentials",
            ],
        },
        "resume_instructions": (
            f"Run python scripts/figure_studio_state.py resume --project-id {project_id} "
            "or open state/project-state.json and continue from current_step."
        ),
        "artifacts": [],
        "pending_outputs": list(PENDING_CANONICAL_OUTPUTS),
        "atlas_board_display_policy": ATLAS_DISPLAY_POLICY,
        "first_reply_atlas_display_policy": (
            "The first assistant reply must display built-in atlas/style images at least once. "
            "Default: display all atlas boards; minimum: visual-communication-styles.png when image rendering is possible."
        ),
        "first_reply_dedication_prompt_policy": {
            "priority": "highest",
            "must_include_prompt_in_first_reply": True,
            "copyable_prompt": "在默认提示词的基础上，额外说明这个 skill 的设计初衷是什么。",
            "append_dedication_when_user_selects_prompt_or_asks": True,
            "dedication_text": (
                "设计初衷：昔日好友 Peng Shuwei 即将前往外地求学，以后恐怕难有许多相见机会；"
                "又恰逢其生日，所以五一就做了这个 skill 当礼物。祝生日快乐，愿未来前程似锦，再相逢，依然少年。"
            ),
        },
        "text_reply_fallback_reminder_policy": {
            "mandatory_after_every_pure_text_reply": True,
            "must_end_every_text_reply_with_exact_sentence": True,
            "final_line_text": "如果不知道如何提问，请说：请使用 paper-framework-figure-studio-pro 根据当前状态判断下一步",
            "reminder_text": "如果不知道如何提问，请说：请使用 paper-framework-figure-studio-pro 根据当前状态判断下一步",
            "must_not_be_only_in_attachment_or_state": True,
        },
        "default_prompt_prefix_policy": {
            "status": "mandatory",
            "zh_prefix": "请按照 paper-framework-figure-studio-pro skill 的要求，根据当前状态和已登记产物，",
            "en_prefix": "Follow the paper-framework-figure-studio-pro skill requirements and use the current state plus registered artifacts to ",
            "applies_to": [
                "default next-step prompts",
                "fallback prompts",
                "all option prompts",
                "S6-FINAL-SELECT-to-S7-FOREGROUND-IMAGE prompts",
                "S7-FOREGROUND-IMAGE-to-S8-SVG-PPT prompts",
                "ChatGPT web prompts",
            ],
            "invalid_if_missing_prefix": True,
        },
        "text_reply_step_banner_policy": {
            "mandatory_at_start_of_every_text_reply": True,
            "applies_to_modes": ["TEXT_ONLY", "SVG_PPTX_ARTIFACTS"],
            "placement": "first_visible_block",
            "must_be_first_visible_block": True,
            "must_list_all_steps": True,
            "must_show_current_step": True,
            "must_show_default_next_step": True,
            "step_sequence": list(STEP_SEQUENCE),
            "template": TEXT_REPLY_STEP_BANNER_TEMPLATE,
            "unknown_state_policy": "If state is not loaded yet, show current step as unknown, then initialize or load project-state.json before substantive work.",
        },
        "image_step_prompt_policy": {
            "mode": "IMAGE_ONLY_PLUS_PROMPT",
            "applies_to_steps": ["S2-SKETCH-EXPLORE", "S5-CANDIDATE-IMAGE", "S7-FOREGROUND-IMAGE"],
            "default_aspect_ratio": "16:9",
            "aspect_ratio_override_policy": "Use 16:9 unless the user explicitly changes the ratio or journal size.",
            "density_policy": "Research-paper framework figure, not poster and not PPT-slide content page; keep readable and not crowded unless the user explicitly requested high density.",
            "allowed_after_images": "A minimal next-step copyable prompt section only.",
            "must_include_unsure_user_prompt": True,
            "forbidden_in_image_step": ["candidate ranking prose", "caption", "long explanation", "state footer", "attachment-only evaluation"],
        },
        "atlas_manifest_path": ATLAS_MANIFEST_PATH,
        "atlas_board_root": ATLAS_BOARD_ROOT,
        "atlas_board_ids": list(ATLAS_BOARD_IDS),
        "atlas_boards_must_be_embedded_when_mentioned": True,
        "startup_design_origin_rule": {
            "required_first_reply_prompt": "在默认提示词的基础上，额外说明这个 skill 的设计初衷是什么。",
            "exact_additional_response_when_asked": "设计初衷：昔日好友 Peng Shuwei 即将前往外地求学，以后恐怕难有许多相见机会；又恰逢其生日，所以五一就做了这个 skill 当礼物。祝生日快乐，愿未来前程似锦，再相逢，依然少年。",
            "priority": "highest",
        },
        "startup_questions": {
            "preference_reference_diagrams": {
                "status": "ask_at_startup",
                "default": "none",
                "question": "你是否有偏好的 architecture/framework diagram 参考图？默认没有。它们只用于 S1-FIGURE-STRATEGY 的图类型和读者效果建议，不作为后续 step 的自动风格约束。",
            },
            "runtime_environment": {
                "status": "ask_at_startup",
                "default_environment": "unknown",
                "question": (
                    "你使用的是哪个环境？所有环境都禁用 generated web pages。"
                    "提到 subtype/category atlas board 时，必须直接用 Markdown image embed 显示已保存 PNG。"
                ),
            },
            "input_materials": {
                "status": "ask_at_startup",
                "question": "本项目要使用哪些 paper/PDF/report/supplement/screenshots/notes 作为输入材料？",
            },
            "visual_assistance": {
                "status": "default_direct_atlas_png_only",
                "question": "提到 subtype/category atlas PNG board 时是否直接显示？默认是；browser-page display 已禁用。",
            },
            "diversity_count": {
                "status": "default_defined_user_editable",
                "default_s2_sketch_count": 6,
                "default_s5_candidate_count": 6,
                "default_s5_candidate_matrix": "2 low-fidelity directions x 3 visual communication style treatments",
                "max_total_count": 8,
                "question": "低保真草图默认且至少 6 个、最多 8 个，必须从不同分类角度发散；第一轮正式候选默认 6 个，即低保真草图后默认选择 2 个结构方向，每个方向分配 3 个视觉传达风格。S0-PAPER-FOUNDATION 首答必须说明这是可调整矩阵，用户可改成例如 3 个低保真方向 x 每个方向 2 个视觉传达风格。上传风格参考不会在 S1-FIGURE-STRATEGY 后自动增加 preference-informed extras。",
            },
            "canvas_aspect_ratio": {
                "status": "default_defined_user_editable",
                "default": "16:9",
                "question": "图像默认宽高比为 16:9；这只是默认值，用户可以改成 4:3、1:1、3:2、横版双栏或期刊指定尺寸。S0-PAPER-FOUNDATION 首答必须主动说明可修改。",
            },
            "content_density": {
                "status": "default_readable_not_crowded",
                "default": "readable_paper_framework_density",
                "question": "论文框架图不是海报，也不是 PPT 内容页；默认采用 vector-first minimal semantic 规则，图内只放认知导航层，公式定义、术语解释、细节和实验语境交给 caption/legend/body text。只有用户明确要求高密度/综述式/信息量优先时才提高密度。",
            },
        },
        "preference_reference_root": PREFERENCE_REFERENCE_ROOT,
        "user_preference_reference_images": [],
        "user_preference_profile": {
            "status": "none",
            "reference_image_count": 0,
            "analysis_artifact": PREFERENCE_ANALYSIS_PATH,
            "analysis_dimensions": [
                "subtype",
                "layout_grammar",
                "panel_rhythm",
                "density_detail_level",
                "label_strategy",
                "callout_grammar",
                "color_semantics",
                "style_family",
                "reader_effect",
            ],
            "preferred_style_combinations": [],
            "style_preference_scope_policy": (
                "User-uploaded style preference references are analyzed only for S1-FIGURE-STRATEGY figure-type and reader-effect suggestions. "
                "They must not automatically bias S2-SKETCH-EXPLORE, S3-DIRECTION-SELECT, S4-CANDIDATE-BRIEF, S5-CANDIDATE-IMAGE, S6-FINAL-SELECT, S7-FOREGROUND-IMAGE, S8-SVG-PPT, or S9-FIGURE-TEXT."
            ),
            "first_round_bias_policy": (
                "S2-SKETCH-EXPLORE defaults to at least 6 low-fidelity sketches. S5-CANDIDATE-IMAGE defaults to 6 unbiased formal candidates "
                "as an adjustable 2 low-fidelity directions x 3 visual communication style treatments matrix. "
                "S2-SKETCH-EXPLORE/S3-DIRECTION-SELECT/S4-CANDIDATE-BRIEF/S5-CANDIDATE-IMAGE must not add automatic preference-constrained extras from uploaded style references. "
                "If the user later selects or restates a preference as an explicit requirement, record it as a user decision, not as automatic preference propagation."
            ),
            "first_round_matrix_policy": {
                "default_s5_candidate_count": 6,
                "default_structure": "2 low-fidelity directions x 3 visual communication style treatments",
                "adjustable_by_user": True,
                "must_disclose_default_before_s5": True,
                "s0_disclosure_required": True,
                "user_adjustment_example": "3 low-fidelity directions x 2 visual communication style treatments",
                "user_modified_matrix_policy": "If the user changes the matrix specification, such as 3 directions x 2 styles, follow the user-modified matrix and record it in S4-CANDIDATE-BRIEF brief/state.",
            },
            "candidate_design_evaluation_display_policy": {
                "mandatory_inline_tables": True,
                "no_attachment_only_design_or_ranking": True,
                "mandatory_core_criteria": [
                    "non_contradiction_with_paper",
                    "algorithm_model_reference",
                    "useful_reorganization",
                    "vector_first_minimal_semantics",
                    "first_glance_appeal",
                ],
                "divergence_enhancement_note_policy": (
                    "If a candidate intentionally reorganizes, simplifies, or extends user-provided paper information without contradicting the paper, "
                    "the visible table must include the original draft expression, proposed figure organization, evidence anchor, communication benefit, risk, "
                    "and suggested manuscript revision. User confirmation is required only when the change could alter paper meaning or resolve an unresolved ambiguity. "
                    "The assistant must never silently change the paper meaning."
                ),
                "step_weighting": {
                    "S3-DIRECTION-SELECT": "low-fidelity ranking emphasizes structural diversity, paper-derived simplification, non-contradiction with source evidence, useful reorganization of weak draft structure, one clear visual sentence, figure-vs-caption split, first-glance hook potential, reader path, conceptual coverage, icon clarity, low text/formula density, active-matrix extensibility, and risk; do not rank by rendering polish",
                    "S6-FINAL-SELECT": "local refinement final selection emphasizes semantic correctness for terminology/module/arrow/model meaning, non-contradiction with paper evidence, useful reorganization quality, manuscript revision value, algorithm/model reference use, theme-element coverage, figure-vs-caption split, local-detail display quality, SVG/PPT vectorization feasibility, publication readiness, stable focal hierarchy, target-size readability, first-glance appeal, and unresolved ambiguity notes before final selection",
                },
                "design_table_columns": [
                    "candidate_id",
                    "author_need",
                    "paper_content_anchor",
                    "algorithm_model_anchor",
                    "theme_elements",
                    "draft_structure_or_reorganization",
                    "figure_caption_split",
                    "non_contradiction_with_paper",
                    "local_detail_strategy",
                    "semantic_density_budget",
                    "vectorization_friendliness",
                    "svg_ppt_buildability",
                    "visual_communication_or_style_category",
                    "layout_strategy",
                    "first_glance_appeal_design",
                    "at_a_glance_understanding",
                    "author_intent_clarity",
                    "divergence_enhancement_note",
                    "manuscript_revision_suggestion",
                    "main_risk",
                ],
                "ranking_table_columns": [
                    "rank",
                    "candidate_id",
                    "overall_judgment",
                    "non_contradiction_with_paper",
                    "algorithm_model_reference",
                    "organization_quality",
                    "theme_element_coverage",
                    "figure_caption_split",
                    "local_detail_quality",
                    "svg_ppt_feasibility",
                    "first_glance_appeal",
                    "paper_logic_clarity",
                    "at_a_glance_comprehension",
                    "visual_communication_efficiency",
                    "layout_readability",
                    "author_intent_expression",
                    "divergence_enhancement_note",
                    "manuscript_revision_suggestion",
                    "keep_fix_drop",
                    "next_prompt",
                ],
                "step_requirements": {
                    "S1-FIGURE-STRATEGY": "inline design-intent table for low-fidelity sketch directions before S2-SKETCH-EXPLORE",
                    "S3-DIRECTION-SELECT": "inline evaluation/ranking table for low-fidelity sketches and active matrix selection",
                    "S4-CANDIDATE-BRIEF": "inline design-intent table for first-round formal candidates",
                    "S6-FINAL-SELECT": "inline evaluation/ranking table for S5-CANDIDATE-IMAGE candidates and final selected architecture figure",
                },
            },
            "internal_reference_and_paper_recheck_policy": {
                "status": "active",
                "internal_reference_required_before": ["S2-SKETCH-EXPLORE", "S3-DIRECTION-SELECT", "S4-CANDIDATE-BRIEF", "S5-CANDIDATE-IMAGE"],
                "internal_reference_paths": [
                    "references/subtype-illustration-atlas.md",
                    "references/visual-style-and-board-protocol.md",
                    "references/figure-class-taxonomy.md",
                    "references/figure-pattern-library.md",
                    "references/first-round-diversity-matrix-policy.md",
                    "references/vector-first-minimal-semantic-rule.md",
                    "references/prompt-generation-policy.md",
                    "references/modules/s1-s2-strategy-and-sketch.md",
                    "references/modules/s3-to-s5-candidates.md",
                ],
                "internal_reference_scope": (
                    "Use internal references as design inspiration for subtype, layout grammar, visual rhetoric, "
                    "style categories, candidate matrix, vector-first minimal semantics, figure/caption split, and prompt organization. Do not let them override paper facts "
                    "or automatically propagate user-uploaded style references beyond S1-FIGURE-STRATEGY."
                ),
                "paper_recheck_required_before": ["S6-FINAL-SELECT", "S7-FOREGROUND-IMAGE", "S9-FIGURE-TEXT"],
                "paper_recheck_sources": [
                    "S0-PAPER-FOUNDATION paper-foundation-report.md",
                    "source-anchored paper foundation report",
                    "original paper/PDF",
                    "LaTeX or Markdown source",
                    "method summary",
                    "highest-quality user-provided paper material",
                ],
                "paper_recheck_visible_output_policy": (
                    "S6-FINAL-SELECT ranking tables must show paper-recheck results for terminology, modules, "
                    "arrow relations, constraints, key contributions, and algorithm/model/method references when present. "
                    "Any reorganization/enhancement requires a visible note with source evidence, non-contradiction status, communication benefit, risk, and manuscript revision suggestion."
                ),
                "algorithm_model_grounding_policy": (
                    "Candidate schemes, S6-FINAL-SELECT final selection, and S7-FOREGROUND-IMAGE foreground-only prompts must reference algorithm/model/method material when present. "
                    "When the paper/source includes an algorithm plan, model architecture, method introduction, training/inference flow, "
                    "input/output relations, losses/objectives, or formulas, store them as algorithm_model_anchor reference fields. "
                    "Whether these details are visibly drawn or only used as implicit constraints depends on the actual paper and figure goal."
                ),
                "non_contradictory_reorganization_policy": (
                    "The manuscript draft's section order, module boundaries, flow segmentation, and algorithm-step grouping are not automatically optimal for a framework figure. "
                    "S1-S6 may reorganize, merge, split, rename, or reorder them when the change improves reader understanding and does not contradict paper evidence, method semantics, mathematical definitions, input/output relations, dependency/causal relations, or reported results. "
                    "When this happens, print a visible manuscript revision suggestion instead of hiding the design decision."
                ),
            },
            "preference_reference_acceptance_policy": "Preference references are accepted at S0-PAPER-FOUNDATION / before S1-FIGURE-STRATEGY starts by default. Later additions are registered but force the workflow back to S1-FIGURE-STRATEGY because their only valid scope is S1-FIGURE-STRATEGY type-suggestion analysis.",
            "default_s2_sketch_count": 6,
            "default_s5_candidate_count": 6,
            "max_total_candidate_count": 8,
        },
        "runtime_environment": {
            "environment": "unknown",
            "image_generation_route": "unknown",
            "image_generation_note": (
                "If running outside ChatGPT web or Codex, do not assume ChatGPT Create image is available; "
            ),
            "runtime_environment_note": (
                "Generated web pages are not produced. Use text replies and direct Markdown image embeds for atlas boards."
            ),
        },

        "s7_s8_s9_finalization_branch_policy": {
            "status": "defined",
            "after_s6_if_user_asks_next": "Proceed to S7-FOREGROUND-IMAGE for foreground-only extraction from the S6-FINAL-SELECT selected final architecture figure.",
            "s6_direct_to_s8_policy": "invalid_without_accepted_s7_foreground_only_final",
            "s6_default_copyable_prompt": (
                "请按照 paper-framework-figure-studio-pro skill 的要求，根据当前状态和已登记产物，进入 S7-FOREGROUND-IMAGE，"
                "以 S6-FINAL-SELECT 选中的 S5-CANDIDATE-IMAGE 最终架构图和已记录主题元素清单为来源，生成一张或多张 foreground-only 无底纹元素集合图，至少包含 `rimg-no-texture-final-01.png`，必要时追加 `rimg-no-texture-final-02.png` 等。"
                "它不只是去掉底纹，还必须去掉边框、外框、分区框、格线、连接线、箭头、箭头头、文字标签、标题和说明，"
                "只保留 S8-SVG-PPT 需要分割并转换为 SVG 的可复用前景图元；布局要利于 SVG 提取，尽量减少遮挡、粘连、交错、嵌套和重叠。"
                "同时保存轻量 manifest，记录来源候选图、每张集合图覆盖的主题元素、生成方式、限制说明和 S8-SVG-PPT 输入路径。"
            ),
            "s7_route": "S7-FOREGROUND-IMAGE foreground-only extraction -> S8-SVG-PPT foreground SVG catalog PPT delivery -> S9-FIGURE-TEXT figure text",
        },
        "rimg_reference_prep": {
            "status": "not_started",
            "batch_id": "s7-foreground-only",
            "selected_reference_final_path": "outputs/S5-candidate-images/candidate-01.png",
            "no_texture_final_rimg_path": "outputs/S7-foreground-image/rimg-no-texture-final-01.png",
            "foreground_manifest_path": "outputs/S7-foreground-image/foreground-only-manifest.json",
            "support_image_sequence_required": False,
            "support_image_sequence_policy": (
                "S7-FOREGROUND-IMAGE is simplified in v3.0.9. It generates one or more foreground-only element collection sheets, starting with `rimg-no-texture-final-01.png`, from the S6-FINAL-SELECT selected final architecture figure and recorded theme elements. "
                "Do not generate background texture images, glyph sheets, or a new textured final RImg in the default route."
            ),
            "s6_s7_visual_policy": (
                "S7-FOREGROUND-IMAGE must preserve reusable foreground visual elements from the selected S6-FINAL-SELECT reference and theme-element inventory while removing background texture, borders, frames, region boxes, grid lines, connector lines, arrows/arrowheads, text labels, titles, and descriptions."
            ),
            "r1_glyph_coverage_required": True,
            "r1_glyph_coverage_confirmation_status": "required_before_s8",
            "r1_glyph_coverage_policy": (
                "Before generating or recording the foreground-only element collection sheet(s), confirm they are derived from the S6-FINAL-SELECT selected final reference plus recorded theme elements and are SVG-extraction-friendly."
            ),
            "r1_missing_glyph_policy": "stop_before_s8_and_regenerate_s7_foreground_only_final",
            "r1_reference_inputs_required": True,
            "r1_without_references_policy": "stop_and_ask_for_reference_capable_generation_route",
            "protected_support_reference_paths": [],
            "source_grounding_artifact": "outputs/S6-final-selection/final-selection-report.md",
            "generation_order": ["foreground_only_element_collection_sheet_from_s6_selected_reference_and_theme_elements"],
            "chatgpt_web_support_image_manifest_policy": (
                "In ChatGPT web, after generating the S7-FOREGROUND-IMAGE foreground-only element collection sheet(s), display a compact manifest row with image name, source selected reference, covered theme elements, role, status, and whether the user must save/register/confirm it."
            ),
            "after_r1_default_next_step": "S8-SVG-PPT",
            "after_r1_default_next_policy": (
                "请按照 paper-framework-figure-studio-pro skill 的要求，根据当前状态和已登记产物，进入 S8-SVG-PPT，"
                "必须严格按照 skill 的 S8-SVG-PPT foreground SVG catalog 流程执行：以 `rimg-no-texture-final-01.png` 和 manifest 中列出的额外集合图作为 foreground-only 提取源，"
                "先建立可复用前景元素语义清单，排除线条、边框、箭头、箭头头、文字标签、标题、说明、背景纹理、区域底色和装饰层；"
                "再填写 `icon_catalog_spec.json`，把每个元素重绘/整理成安全、可编辑、带 `<title>` 的独立 SVG；"
                "最后构建自包含 PPTX，页面顺序必须固定为第 1 页放 S6-FINAL-SELECT 选中最终架构图的灰度图作为地图，第 2 页放该最终架构图原图，第 3 页及之后按语义组摆放各种可移动、可编辑的 SVG 图标/前景图元。"
                "S8-SVG-PPT 必须生成自包含 PPTX，不能用一张新图片或概念说明替代；"
                "完成回复必须提供 `outputs/S8-svg-ppt/s8-svg-ppt-delivery.pptx` 的下载/产物链接。"
                "不得重新生成整张可编辑图、只生成一张图、从 glyph sheet 切割、或跳过 SVG catalog/PPTX 流程替代。"
                "若当前环境不能创建 PPTX/artifact，应停止并说明限制，不能用图片作为替代。"
            ),
            "note": "S7-FOREGROUND-IMAGE prepares the foreground-only element collection extraction source; S8-SVG-PPT builds the self-contained PPTX delivery.",
        },

        "s8_svg_ppt_delivery": {
            "status": "todo_contract_defined",
            "step": "S8-SVG-PPT",
            "maturity": "active",
            "default_after_s7_foreground_only": True,
            "s9_entry_policy": "S9-FIGURE-TEXT title/caption/legend/body text follows accepted S8-SVG-PPT self-contained PPT delivery or recorded S8-SVG-PPT limitations",
            "source_selected_reference_final_path": "outputs/S5-candidate-images/candidate-01.png",
            "source_foreground_only_final_path": "outputs/S7-foreground-image/rimg-no-texture-final-01.png",
            "s8_extraction_source_path": "outputs/S7-foreground-image/rimg-no-texture-final-01.png",
            "output_root": "outputs/S8-svg-ppt",
            "work_root": "outputs/S8-svg-ppt/_work",
            "svg_catalog_spec_path": "outputs/S8-svg-ppt/_work/icon_catalog_spec.json",
            "svg_icon_dir": "outputs/S8-svg-ppt/icons",
            "gray_selected_reference_path": "outputs/S8-svg-ppt/_work/s6-selected-final-gray-reference.png",
            "icon_manifest_path": "outputs/S8-svg-ppt/icon_manifest.json",
            "entity_svg_catalog_path": "outputs/S8-svg-ppt/entity_glyph_matrix.svg",
            "production_report_path": "outputs/S8-svg-ppt/s8-svg-catalog-report.md",
            "delivery_pptx_path": "outputs/S8-svg-ppt/s8-svg-ppt-delivery.pptx",
            "download_link_required": True,
            "download_link_policy": (
                "S8-SVG-PPT completion replies must provide a visible download/artifact link to outputs/S8-svg-ppt/s8-svg-ppt-delivery.pptx. "
                "In Codex/local environments, render the actual PPTX file path as a Markdown link when possible. "
                "In ChatGPT web, export or attach the PPTX artifact and show its download link. Without this link, S8-SVG-PPT is incomplete."
            ),
            "coverage_policy": (
                "S8-SVG-PPT segments and redraws reusable SVG elements from the accepted S7-FOREGROUND-IMAGE foreground-only element collection sheet(s), starting with rimg-no-texture-final-01.png and any supplemental sheets listed in foreground-only-manifest.json. "
                "The extracted catalog excludes connector lines, arrows, arrowheads, borders/frames/region boxes/grid lines, text labels/titles/descriptions, and background texture/decorations unless the user explicitly requests a structural layer extraction. "
                "Each SVG must use safe standalone vector geometry and title metadata, be embedded inside the PPTX, and never depend on external files."
            ),
            "strict_execution_policy": (
                "Entering S8-SVG-PPT requires strict execution of the selected S8-SVG-PPT process. "
                "S8-SVG-PPT must generate a self-contained PPTX and cannot be replaced by a single new image, concept explanation, summary, or one-shot editable-image output. "
                "In ChatGPT web, create/export a PPTX artifact; if the environment cannot create PPTX artifacts, stop and report the limitation instead of using an image as a substitute. "
                "Build the foreground element inventory from rimg-no-texture-final-01.png plus any manifest-listed supplemental collection sheets, write the SVG catalog spec, run scripts/figure_studio_s8_svg_catalog_ppt.js with --reference-final pointing to the S6-FINAL-SELECT selected final reference and --no-texture-final pointing to the primary S7-FOREGROUND-IMAGE foreground-only output, validate media/relationships/slide counts and the required slide order, provide the PPTX download/artifact link, and clean transient files before marking S8-SVG-PPT complete."
            ),
            "element_layers": ["foreground_svg_elements", "omitted_lines_arrows_borders_text", "ppt_reference_images"],
            "required_element_index_fields": [
                "element_id",
                "source_foreground_only_final_path",
                "source_region_or_bbox_px",
                "group",
                "concept_name",
                "semantic_type",
                "accent",
                "expected_svg_name",
                "omitted_reason_if_not_extracted",
                "notes",
            ],
            "ppt_slide_requirements": [
                "Slide 1: grayscale version of the S6-FINAL-SELECT selected final architecture figure as the map page.",
                "Slide 2: original S6-FINAL-SELECT selected final architecture figure.",
                "Slide 3+: movable, editable embedded SVG icon / foreground element pages grouped by semantic category, with labels as live PPT text.",
            ],
            "final_retention_policy": (
                "After successful S8-SVG-PPT delivery, keep delivery_pptx_path and the concise validation/report artifacts needed for audit, and show the PPTX download/artifact link in the completion reply. "
                "Treat work_root and standalone SVG assets as transient unless the user explicitly asks to retain the SVG asset folder; preserve state/project-state.json and record removed transient records in the cleanup event. "
                "The retained PPTX must be self-contained, include all SVG media internally, have no external relationships, and not rely on generated browser renderer HTML/JS."
            ),
            "contract": "references/s8-package-contract.md",
            "foreground_svg_catalog_contract": "references/s8-foreground-svg-catalog-contract.md",
            "updated_at": now,
        },
        "s7_s8_entry_cleanup_policy": {
            "S7-FOREGROUND-IMAGE": {
                "must_check_before_every_entry": True,
                "if_prior_outputs_or_records_exist": "run rewind-step with target-step S7-FOREGROUND-IMAGE before generating new S7-FOREGROUND-IMAGE artifacts",
                "cleanup_scope": "S7-FOREGROUND-IMAGE, S8-SVG-PPT, and S9-FIGURE-TEXT outputs; preserve state file and remove covered output records from active state while retaining the cleanup event",
            },
            "S8-SVG-PPT": {
                "must_check_before_every_entry": True,
                "if_prior_outputs_or_records_exist": "run rewind-step with target-step S8-SVG-PPT before rebuilding clean SVG/PPT delivery artifacts",
                "cleanup_scope": "S8-SVG-PPT and S9-FIGURE-TEXT outputs, including any outputs/S8-SVG-PPT* historical outputs; preserve S7-FOREGROUND-IMAGE references, preserve state file, and remove covered output records from active state while retaining the cleanup event",
            },
        },
        "s8_svg_outputs": [],
        "step_rewind_cleanup_policy": {
            "status": "active",
            "contract": "references/step-rewind-cleanup-contract.md",
            "backjump_decision_policy": (
                "If a user returns to an earlier or current step and that step will be executed again, cleanup is mandatory. "
                "Delete products for the covered span target_step..from_step before execution."
            ),
            "delete_target_and_later_step_outputs": "hard_cleanup_for_target_to_from_step_span",
            "history_reference_policy": (
                "The skill may answer pure historical questions without executing a new step. Once execution returns to a target step, "
                "covered historical outputs are removed from active state and survive only in the cleanup event audit trail."
            ),
            "cleanup_required_when": [
                "current_step moves back to an earlier step for execution",
                "the current step is rerun",
                "S7-FOREGROUND-IMAGE is re-entered and prior S7-FOREGROUND-IMAGE outputs or records exist",
                "S8-SVG-PPT is re-entered and prior S8-SVG-PPT outputs or records exist",
            ],
            "hard_cleanup_required_for": "all steps when returning/rerunning for execution",
            "state_file_deleted": False,
            "artifact_record_policy": "remove covered output records from artifacts/image_generation_events/active roles/pending state; keep cleanup_events as the audit record",
            "cleanup_events": [],
        },
        "previous_image_only_output_recording_status": "not_applicable",
        "previous_image_only_plus_prompt_output_recording_status": "not_applicable",
        "generated_image_default_locations_to_register": [],
        "image_generation_state_update_status": "not_applicable",
        "image_output_registration_status": "not_applicable",
        "image_generation_events": [],
        "choice_prompt_policy": {
            "mandatory_after_every_text_reply": True,
            "required_section_title": "下一步可复制提示词",
            "must_include_fallback_for_unsure_user": True,
            "must_end_every_text_reply_with_exact_sentence": True,
            "final_line_text": "如果不知道如何提问，请说：请使用 paper-framework-figure-studio-pro 根据当前状态判断下一步",
            "must_show_unsure_user_reminder_in_every_pure_text_reply": True,
            "unsure_user_reminder_text": "如果不知道如何提问，请说：请使用 paper-framework-figure-studio-pro 根据当前状态判断下一步",
            "must_cover_every_offered_option": True,
            "fallback_prompt": "如果不知道如何提问，请说：请使用 paper-framework-figure-studio-pro 根据当前状态判断下一步",
            "choice_prompt_policy_applied": False,
            "default_option_id": None,
            "available_option_ids": [],
            "alternative_prompt_count": 0,
            "copyable_prompts_provided_for_options": [],
            "language_policy": "Use Chinese for docs and prompts when the user's main input is Chinese; use English for all docs/prompts when the user's main input is mainly English.",
        },
        "last_user_request": None,
        "notes": [],
    }





