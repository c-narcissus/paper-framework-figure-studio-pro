#!/usr/bin/env python3
"""Validate a production SVG for common editability and portability problems."""
import argparse, re
from pathlib import Path

BAD_PATTERNS = {
    'filter elements': r'<\s*filter\b',
    'filter attributes': r'\sfilter\s*=',
    'class attributes': r'\sclass\s*=',
    'style attributes': r'\sstyle\s*=',
    'editor data attributes': r'\sdata-[a-zA-Z0-9_-]+\s*=',
    'embedded raster images': r'<\s*image\b',
}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('svg')
    args = ap.parse_args()
    text = Path(args.svg).read_text(encoding='utf-8')
    issues = []
    for name, pat in BAD_PATTERNS.items():
        if re.search(pat, text):
            issues.append(name)
    if '<text' not in text:
        issues.append('no editable text found')
    if 'viewBox=' not in text:
        issues.append('missing viewBox')
    if issues:
        print('Production SVG check: FAIL')
        for issue in issues:
            print(f'- {issue}')
        raise SystemExit(1)
    print('Production SVG check: PASS')

if __name__ == '__main__':
    main()
