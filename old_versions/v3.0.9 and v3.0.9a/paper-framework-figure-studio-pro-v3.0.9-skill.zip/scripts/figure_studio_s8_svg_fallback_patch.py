#!/usr/bin/env python3
from __future__ import annotations
import argparse, re, shutil, tempfile, zipfile, posixpath, json
from pathlib import Path
from xml.etree import ElementTree as ET
import cairosvg

REL_NS = 'http://schemas.openxmlformats.org/package/2006/relationships'
P_NS = 'http://schemas.openxmlformats.org/presentationml/2006/main'
A_NS = 'http://schemas.openxmlformats.org/drawingml/2006/main'
R_NS = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'
ASVG_NS = 'http://schemas.microsoft.com/office/drawing/2016/SVG/main'
ET.register_namespace('p', P_NS); ET.register_namespace('a', A_NS); ET.register_namespace('r', R_NS)
ET.register_namespace('asvg', ASVG_NS)

REDX_PNG_SIZES = {1594,1595,1600}

def rels_for_slide(slide_name: str) -> str:
    base = posixpath.basename(slide_name)
    return posixpath.dirname(slide_name) + '/_rels/' + base + '.rels'

def parse_rels(data: bytes) -> dict[str, str]:
    root = ET.fromstring(data)
    rels = {}
    for rel in root:
        rid = rel.attrib.get('Id')
        target = rel.attrib.get('Target')
        if rid and target:
            rels[rid] = target
    return rels

def resolve_target(rels_name: str, target: str) -> str:
    if target.startswith('/'):
        return target.lstrip('/')
    rel_dir = posixpath.dirname(rels_name)
    # rels lives in ppt/slides/_rels, target path is relative to ppt/slides
    if rel_dir.endswith('/_rels'):
        base = posixpath.dirname(rel_dir)
    else:
        base = rel_dir
    return posixpath.normpath(posixpath.join(base, target))

def patch_pptx(infile: Path, outfile: Path, scale: int = 4) -> dict:
    with tempfile.TemporaryDirectory() as td:
        root = Path(td) / 'pptx'
        with zipfile.ZipFile(infile, 'r') as z:
            z.extractall(root)
        replacements = []
        slide_files = sorted((root/'ppt'/'slides').glob('slide*.xml'), key=lambda p: int(re.findall(r'\d+', p.stem)[0]))
        for slide_path in slide_files:
            rel_path = slide_path.parent/'_rels'/(slide_path.name + '.rels')
            if not rel_path.exists():
                continue
            rels_name = str(rel_path.relative_to(root)).replace('\\','/')
            rels = parse_rels(rel_path.read_bytes())
            tree = ET.parse(slide_path)
            root_xml = tree.getroot()
            for pic in root_xml.findall(f'.//{{{P_NS}}}pic'):
                blip = pic.find(f'.//{{{A_NS}}}blip')
                if blip is None:
                    continue
                fallback_rid = blip.attrib.get(f'{{{R_NS}}}embed')
                svg_blip = pic.find(f'.//{{{ASVG_NS}}}svgBlip')
                if svg_blip is None:
                    continue
                svg_rid = svg_blip.attrib.get(f'{{{R_NS}}}embed')
                if not fallback_rid or not svg_rid or fallback_rid not in rels or svg_rid not in rels:
                    continue
                fallback_target = resolve_target(rels_name, rels[fallback_rid])
                svg_target = resolve_target(rels_name, rels[svg_rid])
                fallback_file = root / fallback_target
                svg_file = root / svg_target
                if not svg_file.exists():
                    continue
                # Estimate size from xfrm if possible
                width_px, height_px = 960, 600
                xfrm = pic.find(f'.//{{{A_NS}}}xfrm')
                if xfrm is not None:
                    ext = xfrm.find(f'{{{A_NS}}}ext')
                    if ext is not None:
                        try:
                            # EMU per inch 914400, assume 96 DPI
                            width_px = max(128, int(int(ext.attrib.get('cx','914400')) / 914400 * 96 * scale))
                            height_px = max(128, int(int(ext.attrib.get('cy','914400')) / 914400 * 96 * scale))
                        except Exception:
                            pass
                svg_bytes = svg_file.read_bytes()
                if b'url(#arr)' in svg_bytes and b'id="arr"' not in svg_bytes:
                    svg_text = svg_bytes.decode('utf-8', errors='replace')
                    svg_text = svg_text.replace('>\n<rect', '><defs><marker id="arr" markerWidth="8" markerHeight="8" refX="6" refY="4" orient="auto"><path d="M0,0 L8,4 L0,8 Z" fill="#16A34A"/></marker></defs>\n<rect', 1)
                    svg_bytes = svg_text.encode('utf-8')
                    svg_file.write_bytes(svg_bytes)
                png_bytes = cairosvg.svg2png(bytestring=svg_bytes, output_width=width_px, output_height=height_px)
                fallback_file.write_bytes(png_bytes)
                replacements.append({'slide': slide_path.name, 'svg': svg_target, 'fallback_png': fallback_target, 'bytes': len(png_bytes)})
        # Check external relationships and missing refs roughly
        out_tmp = Path(td) / 'patched.pptx'
        with zipfile.ZipFile(out_tmp, 'w', zipfile.ZIP_DEFLATED) as z:
            for f in root.rglob('*'):
                if f.is_file():
                    z.write(f, f.relative_to(root).as_posix())
        shutil.copy2(out_tmp, outfile)
    with zipfile.ZipFile(outfile, 'r') as z:
        names = z.namelist()
        svg_count = len([n for n in names if n.startswith('ppt/media/') and n.lower().endswith('.svg')])
        pngs = [n for n in names if n.startswith('ppt/media/') and n.lower().endswith('.png')]
        redx_like = [n for n in pngs if z.getinfo(n).file_size in REDX_PNG_SIZES]
        external = []
        missing = []
        name_set = set(names)
        for n in names:
            if n.endswith('.rels'):
                txt = z.read(n).decode('utf-8', errors='ignore')
                if 'TargetMode="External"' in txt:
                    external.append(n)
                for m in re.finditer(r'Target="([^"]+)"', txt):
                    target = m.group(1)
                    if '://' in target or target.startswith('file:'):
                        external.append(f'{n}:{target}')
                        continue
                    if target.startswith('/'):
                        t = target.lstrip('/')
                    else:
                        d = posixpath.dirname(n)
                        base = posixpath.dirname(d) if d.endswith('/_rels') else d
                        t = posixpath.normpath(posixpath.join(base, target))
                    if t.startswith('ppt/') and t not in name_set:
                        missing.append(f'{n}:{target}')
    return {'ok': not external and not missing and not redx_like, 'replacements': replacements, 'replacement_count': len(replacements), 'svg_count': svg_count, 'png_count': len(pngs), 'redx_like_pngs': redx_like, 'external_relationships': external, 'missing_internal_targets': missing}

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--in', dest='infile', required=True, type=Path)
    ap.add_argument('--out', dest='outfile', required=True, type=Path)
    ap.add_argument('--json', action='store_true')
    args = ap.parse_args()
    result = patch_pptx(args.infile, args.outfile)
    if args.json:
        print(json.dumps(result, indent=2))
    else:
        print('ok' if result['ok'] else 'failed', result)
    return 0 if result['ok'] else 1

if __name__ == '__main__':
    raise SystemExit(main())
