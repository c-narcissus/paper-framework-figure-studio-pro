# S8-SVG-PPT Foreground SVG Asset And PPT Embedding Rules

S8-SVG-PPT produces a self-contained PPTX derived from the S7-FOREGROUND-IMAGE foreground-only element collection sheet(s), starting with `rimg-no-texture-final-01.png` and including any extra sheets listed in `foreground-only-manifest.json`. Standalone SVG files are build assets; they must be embedded into the PPTX and treated as transient unless the user explicitly asks to keep the SVG asset folder.

## Asset Identity

Every SVG asset must have a stable identity:

- `element_id`: stable row ID from the S8-SVG-PPT foreground inventory.
- `source_foreground_only_final_path`: usually `outputs/S7-foreground-image/rimg-no-texture-final-01.png`, or a manifest-listed supplemental sheet.
- `source_region_or_bbox_px`: approximate source region when useful for audit.
- `concept_name`: human-readable concept name.
- `short_title`: short name/token from S7-FOREGROUND-IMAGE metadata/contract, S8-SVG-PPT inventory, or manual spec.
- `semantic_type`: useful bucket such as `client`, `classifier`, `generator`, `data`, `chart`, `formula symbol`, `mixed-data symbol`, `aggregation symbol`, or paper-specific object.
- `expected_svg_name`: transient SVG file name before embedding into PPT.

Do not encode local file paths or temporary host-specific data into IDs.

## Foreground-Only Source Standard

The foreground-only element collection sheet(s) should make SVG inventory practical:

- one reusable foreground element per clearly identifiable region where possible;
- minimal overlap between different icon/object regions;
- no connector lines, arrows, arrowheads, borders, frames, text labels, or background texture;
- no baked-in labels, titles, or explanations;
- no heavy occlusion, fusion, or ambiguous nesting between unrelated elements.

If the source violates these constraints so badly that the inventory is guesswork, S8-SVG-PPT must stop and request a corrected S7-FOREGROUND-IMAGE foreground-only element collection sheet.

## SVG Standard

Each SVG must be:

- semantic and controllable, preferably using paths, shapes, strokes, and simple vector text only when text is part of a symbol;
- titled with `<title>short_title</title>`;
- named consistently with `expected_svg_name`;
- free of embedded raster images;
- safe for PPT embedding.

Reject scripts, event handlers, `foreignObject`, external URLs, `data:` URLs, `<image>`, `style`, `class`, and filters.

## PPT Embedding

The retained PPT is:

```text
outputs/S8-svg-ppt/s8-svg-ppt-delivery.pptx
```

The PPTX must include all generated SVGs as internal package media, not references to local files. It must use live PPT text for labels and filenames.

Required slide order:

1. grayscale S6-FINAL-SELECT selected final reference as the map page;
2. original S6-FINAL-SELECT selected final reference;
3. one or more movable, editable SVG icon / foreground-element catalog slides.

The S8-SVG-PPT completion reply must provide a visible download/artifact link to `outputs/S8-svg-ppt/s8-svg-ppt-delivery.pptx`; without that link, the step is incomplete.

## Cleanup

After validation, delete or mark transient `_work/` files and generated standalone SVGs as unavailable unless the user explicitly requests a retained SVG asset folder. Keep the self-contained PPTX and concise validation/report artifacts.

