# Open-Source PPT / Clean SVG Practice Review

This review records permissive or otherwise clearly licensed open-source practices useful for S8-SVG-PPT clean SVG/PPT delivery. The skill does not copy third-party source code; it records whether a project contributes direct API usage, optional dependency/tooling, or design ideas only.

## Adopted Pattern

1. Keep final SVG assets explicit and named.
2. Use SVG for all final icons, symbols, text/formula assets, line segments, and arrows.
3. Use a light-gray reference map as a manual composition slide in the delivery PPT.
4. Include SVG icon/name tables so coverage can be audited visually.
5. Delete transient segmentation and cleanup files after final delivery, while preserving state records.

## Dependency Policy

- Prefer standard library helpers where possible.
- Use Pillow/OpenCV for segmentation, sheet recutting, light-gray maps, and vectorization support.
- Use python-pptx when available for the delivery PPT.
- Do not copy third-party source code into the skill unless license obligations and attribution are explicitly handled.

## Attribution Statement

When S8-SVG-PPT output is delivered, include a short statement that the package uses self-contained scripts plus optional local dependencies and does not vendor third-party project source code.

