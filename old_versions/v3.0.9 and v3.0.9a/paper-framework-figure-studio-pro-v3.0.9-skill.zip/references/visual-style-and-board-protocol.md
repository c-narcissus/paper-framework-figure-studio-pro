# Visual Style And Board Protocol

This skill uses two design phases.

## Global Exploration

S1-FIGURE-STRATEGY, S2-SKETCH-EXPLORE, and S3-DIRECTION-SELECT are broad and divergent. They explore:

- reader hook;
- visual metaphor;
- subtype and layout grammar;
- first-glance appeal;
- rough hierarchy;
- alternative ways to make the paper easier to notice.

These steps may use saved atlas boards and internal references as inspiration, but they must not invent paper facts or replace target-paper sketches/candidates.

S2-SKETCH-EXPLORE must produce at least 6 separate sketches. The set must be diverse before reading text: different overall silhouettes, focal hierarchy, reader paths, and visual hooks. It should look like large-scale chapter/outline planning, not a dense final poster. Use extracted paper logic to choose what to show and what to omit.

Global exploration may treat the manuscript draft as provisional writing. It can propose a cleaner framework, mechanism, flow, module hierarchy, or algorithm-step grouping than the draft currently states, provided the proposal is anchored in source evidence and does not alter paper meaning.

Before sketching, apply `vector-first-minimal-semantic-rule.md`: decide the figure layer, caption/legend layer, and omitted/implicit layer. S2 should test different visual sentences and silhouettes, not different ways to cram every term into one image.

## Local Refinement

S4-CANDIDATE-BRIEF, S5-CANDIDATE-IMAGE, and S6-FINAL-SELECT are precise and paper-grounded. They must use the S0-PAPER-FOUNDATION `paper-foundation-report.md` and source material. The focus is:

- faithful method/algorithm/model meaning, even when the visual organization differs from the draft exposition;
- one clear visual sentence and an explicit figure-vs-caption split;
- stable terminology mapping, including improved figure labels when draft labels are unclear;
- required modules, allowing better grouping or splitting when evidence supports it;
- correct arrow/data/control relations;
- readable density;
- vector-first buildability from simple shapes, large separable icons, short editable labels, and clean connector grammar;
- publication suitability.

S5-CANDIDATE-IMAGE candidates must be generated one by one. They cannot be a contact sheet or stitched board. S6-FINAL-SELECT ranks the candidates, rechecks the paper/source, and selects one final reference.

Before S5-CANDIDATE-IMAGE, S4-CANDIDATE-BRIEF must list each candidate's theme elements and local-detail strategy. The second image round should be precise and vectorization-aware: prefer clean shapes, separable icons, clear module bodies, readable short labels, and controllable data-flow relations; avoid texture-heavy or painterly effects that are hard to rebuild as SVG/PPT elements. If the chosen visual organization is better than the manuscript draft, S4/S6 must surface it as paper-writing feedback, not hide it as a silent design assumption.

## Density

The default figure should be readable as a paper framework figure. Avoid crowding, long paragraphs, many bullets, tiny labels, tangled arrows, and decorative panels unless the user explicitly asks for a high-density taxonomy/overview figure.

Default density budget: 3-6 main modules, one dominant data/control flow, 0-3 secondary flows, usually no formulas and at most 1-2 essential formulas, short module labels only, and landmark icons rather than many small dictionary icons. If a detail is scientifically important but visually expensive, move it to S9 caption/legend/body text instead of forcing it into the image.

## S7/S8 Delivery Style

S7-FOREGROUND-IMAGE preserves reusable foreground visual elements while removing texture, framing, grids, lines, arrows, arrowheads, and text. It may use one or more foreground-only element collection sheets when a single sheet would cause overlap or fusion. S8-SVG-PPT then builds editable SVG elements and PPTX delivery. Do not weaken paper logic only to simplify extraction, but do keep elements separable where possible.



