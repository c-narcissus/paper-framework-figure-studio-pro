# Skill Architecture Review Guidelines

Use `references/architecture-governance-contract.md` as the normative contract when revising the skill. This file is a short review checklist.

- **Loose coupling:** separate workflow policy, state helpers, image generation gates, S7-FOREGROUND-IMAGE contracts, S8-SVG-PPT package helpers, cleanup helpers, and release checks.
- **High cohesion:** each script should do one job; shared helpers live under `scripts/figure_studio_core/`.
- **Layered on-demand calls:** read paper material, build text decisions, generate images, build contracts, build complete clean SVG/PPT delivery assets, and write figure text in separate layers.
- **Transformation isolation:** image-generation artifacts, contract artifacts, S8-SVG-PPT clean-delivery artifacts, cleanup events, and release-check artifacts should not overwrite one another.
- **Failure checkpointing:** every step writes resumable state and project-relative artifacts; cleanup writes `planned`, `running`, and `completed` checkpoints.
- **Abstraction:** reusable code must be paper-agnostic and accept specs, artifact roles, and relative paths rather than hard-coded paper coordinates or duplicated product names.
- **Memory/state:** persistent state is the source of truth after interruption; do not rely only on chat memory. Use step epochs to distinguish active products from stale history.
- **Retrievability:** artifact ids, artifact roles, step epochs, relative paths, tags, and summaries should be searchable.
- **Vulnerability checks:** run `validate`, `doctor`, and release path scans; prevent local path leakage; avoid storing secrets, absolute host paths, or sandbox paths.
- **No dead code:** remove browser-page display/web markup remnants, obsolete step references that conflict with the active route, generated renderer HTML/JS, and paper-specific helper scripts from releases.

Before release, run:

```bash
python scripts/figure_studio_architecture_audit.py --target . --fail-on-issue
python scripts/figure_studio_release_check_paths.py scan --target . --fail-on-match
```


