# S8-SVG-PPT Foreground SVG Catalog Contract

The primary extraction source is:

```text
outputs/S7-foreground-image/rimg-no-texture-final-01.png
```

This image is foreground-only and is generated from the S6-FINAL-SELECT selected final architecture reference and its theme-element inventory. If `foreground-only-manifest.json` lists additional `rimg-no-texture-final-02.png`, `rimg-no-texture-final-03.png`, etc., S8-SVG-PPT must use those sheets as supplementary extraction sources for the element inventory and SVG catalog.

The S7 images are element collection sheets, not complete framework figures. They must contain only reusable foreground elements with enough whitespace for segmentation.

## Include

- reusable foreground objects;
- concept icons;
- visual tokens;
- body glyphs;
- formula-symbol glyphs when they are visual elements rather than text labels;
- subject-specific symbols that need to be reusable in the PPT.

## Exclude By Default

- connector lines;
- arrows and arrowheads;
- borders, frames, region boxes, grid lines;
- text labels, titles, descriptions, formulas used as text;
- background texture, region fills, card fills, and decorative layers.
- labels attached to elements; semantic names belong in the S8 spec and SVG `<title>`, not in the S7 pixels.

## SVG Requirements

Each SVG must:

- have a `viewBox`;
- include a `<title>`;
- use standalone vector geometry;
- avoid scripts, event handlers, `foreignObject`, external URLs, `data:` URLs, `<image>`, `style`, `class`, and filters;
- be embeddable as internal PPTX media.

## PPT Reference

The final PPTX uses the S6-FINAL-SELECT selected final architecture reference for slides 1 and 2. Slide 1 is the grayscale selected final reference as a map page. Slide 2 is the original selected final reference. Slide 3 and later pages contain movable, editable embedded SVG icons / foreground elements built from the S7-FOREGROUND-IMAGE foreground-only image(s).

S8-SVG-PPT completion must provide a visible download/artifact link to `outputs/S8-svg-ppt/s8-svg-ppt-delivery.pptx`.

