# S0-PAPER-FOUNDATION 启动模板

第一次进入项目时使用本模板。S0-PAPER-FOUNDATION 是 `TEXT_ONLY`：建立状态、确认信息，并按输入材料决定深读强度；不生成目标论文图像。

## S0-PAPER-FOUNDATION 深读强度

- 如果用户只给一句简单描述、简单图意或短需求，S0-PAPER-FOUNDATION 不强行长篇深读；只做轻量需求澄清、记录 best-effort scope，并提示用户提供 PDF、LaTeX、论文正文或详细方法描述后会切换到深读。
- 如果用户提供 paper PDF、LaTeX、Markdown 正文、paper report、supplement、完整方法说明或足够详细的论文描述，S0-PAPER-FOUNDATION 必须深读算法、方法和模型介绍部分，输出并打印 `paper-foundation-report.md`。这份论文精读报告是整个 workflow 的底座，不能写成泛泛摘要。
- 如果材料不足以深读，必须在状态中记录 `deep_reading_status = pending_input`，不能假装已经理解论文方法。

## 必问信息

1. **运行环境**
   - 询问当前环境：ChatGPT web、Codex、Claude Code，还是其他环境。
   - 说明任何环境都不使用 generated browser-page display。
   - 如果不是 ChatGPT web 或 Codex，询问可用的 image-generation route。

2. **输入材料**
   - 询问要使用哪些材料：paper PDF、supplement、report、screenshots、已有草图、notes 或当前项目中的链接。
   - 工具支持时，把材料登记为 project inputs。
   - 判断输入属于 `simple_description` 还是 `paper_source_or_detailed_method`。只有后者触发 S0-PAPER-FOUNDATION 深读。

3. **论文精读底座报告**
   - 当输入触发深读时，必须读取论文中 algorithm、method、model、training、inference、objective/loss、experiment setting 相关内容。
   - 在回复正文打印丰富、详细、准确、带来源锚点的 Markdown 报告，不能只保存到文件，也不能只打印几条概括。
   - 记录到 `outputs/S0-paper-foundation/paper-foundation-report.md`，并在 state 中登记为后续 `paper_content_anchor`、`algorithm_model_anchor`、`terminology_anchor` 和 `arrow_semantics_anchor`。
   - 必须覆盖：source section/page/evidence anchors、ordered algorithm steps、model architecture/components/modules、training flow、inference flow、inputs/outputs/data flow、losses/objectives/equations、constraints/assumptions、terminology-to-module-to-arrow map、unresolved paper-only questions。
   - 必须输出 semantic density budget：哪些进入 figure layer，哪些交给 caption/legend layer，哪些省略或隐含；默认主模块 3-6 个、主数据/控制流 1 条、辅助流 0-3 条、图内公式通常 0 个且必要时最多 1-2 个；说明图标哪些是 landmark icon，哪些不应画成小图标。
   - 必须区分：哪些是论文事实约束，哪些只是初稿当前的写作/章节/模块/算法步骤表达。后续制图可以在不违背事实约束的前提下重组表达，并把更清楚的组织方式反馈为论文写作修改建议。
   - 后续 S1-FIGURE-STRATEGY 到 S9-FIGURE-TEXT 的图类型判断、候选构思、候选提示词、候选评审、最终选择、foreground-only 提取、SVG/PPTX 交付和 caption/legend 都必须回到这份报告核对；若报告缺失或过浅，必须先补 S0-PAPER-FOUNDATION，而不是继续生成图。

4. **偏好/参考框架图**
   - 询问用户是否有体现风格倾向的 architecture/framework diagram 参考图。
   - 默认：没有。
   - 明确说明：这些参考图只用于 S1-FIGURE-STRATEGY 的图类型、读者效果和表达方向建议，不会自动传递到 S2-SKETCH-EXPLORE、S3-DIRECTION-SELECT、S4-CANDIDATE-BRIEF、S5-CANDIDATE-IMAGE 或后续 step。
   - 如果 S1-FIGURE-STRATEGY 后新增偏好参考图，必须注册后返回 S1-FIGURE-STRATEGY 重新分析，不直接混入后续生成。
   - 如果用户提供图片，存到 `inputs/preference-reference-images/`，注册到 `project-state.json`，并设置 `user_preference_profile.status = analysis_pending`。

5. **已有 atlas PNG 辅助**
   - 告诉用户 browser-page display 已禁用。
   - 第一次回答必须至少展示一次内置 atlas/style 图；默认展示全部 atlas PNG，最低也要展示 `assets/subtype-atlas/boards/visual-communication-styles.png`。
   - 提到 subtype/category atlas PNG board 时，直接用 Markdown 图片嵌入。

6. **多样性数量和矩阵**
   - 低保真草图默认且至少 6 个，最多 8 个；必须从不同分类角度发散，例如 subtype、layout grammar、reader path、density/detail、visual communication style 和 first-glance hook。
   - 第一轮正式候选默认 6 个：低保真草图后默认选择 2 个结构方向，每个方向分配 3 个视觉传达风格。
   - 这个 2x3 分配是默认矩阵，不是写死值；如果用户想更改，可以改成例如“3 个低保真方向，每个方向 2 个视觉传达风格”。
   - 上传偏好参考图本身不会增加后续候选数量。

7. **默认画幅和密度**
   - 第一次回答必须告诉用户：图像默认宽高比为 16:9，但可以修改为 4:3、1:1、3:2、横版双栏或期刊指定尺寸。
   - 必须说明本 skill 做的是论文框架图，不是海报，也不是 PPT 内容页；默认不把大量 bullet、段落、小字、说明框和复杂连线塞进一张图。
   - 必须说明默认采用 vector-first minimal semantic 规则：图本体负责认知导航，caption/legend/body text 负责公式定义、术语解释、实验语境和细节说明；候选图必须优先可拆成 SVG/PPT 的简单形状、大图标、短标签和清晰连接关系。
   - 只有用户明确要求高密度、综述式、taxonomy map 或信息量优先时，才提高内容密度，并且仍要保持目标尺寸可读。

8. **下一步计划**
   - 默认下一步是 S1-FIGURE-STRATEGY：材料精读 + 图类型需求判断。
   - 如果给出多个下一步选项，必须为每个选项都提供可复制提示词。
   - 每次文本回复最后都必须原样单独追加：`如果不知道如何提问，请说：请使用 paper-framework-figure-studio-pro 根据当前状态判断下一步`。

## 可直接使用的 S0-PAPER-FOUNDATION 中文话术

```text
我会先建立项目状态，并确认以下信息：

1. 你当前使用的环境是 ChatGPT web、Codex、Claude Code，还是其他环境？
2. 本项目要使用哪些输入材料？例如论文 PDF、LaTeX、补充材料、报告、详细方法说明、已有草图、参考截图或笔记。如果你只给一句简单描述，我会先轻量澄清；如果给的是 PDF/LaTeX/论文正文/详细方法描述，我会在 S0-PAPER-FOUNDATION 深读算法、方法和模型介绍，并打印丰富、详细、准确、带来源锚点的论文精读底座报告。
3. 你是否有偏好的 architecture/framework diagram 参考图？默认没有。如果有，请尽量在 S0-PAPER-FOUNDATION / S1-FIGURE-STRATEGY 开始前提供。注意：这些参考图只用于 S1-FIGURE-STRATEGY 的图类型、读者效果和表达方向建议，不会自动传递到后续 step 作为风格约束。
4. 低保真草图默认且至少 6 个，最多 8 个，会从 subtype、layout grammar、reader path、density/detail、visual communication style 和 first-glance hook 等不同角度发散；第一轮正式候选默认 6 个，即低保真草图后默认选择 2 个结构方向，每个方向分配 3 个视觉传达风格。这个 2x3 分配是默认矩阵，不是写死值；如果你想更改，可以改成例如“3 个低保真方向，每个方向 2 个视觉传达风格”。上传偏好参考图本身不会增加后续候选数量。
5. 图像默认宽高比为 16:9，但可以改成 4:3、1:1、3:2、横版双栏或期刊指定尺寸。这个 skill 做的是论文框架图，不是海报，也不是 PPT 内容页；默认采用 vector-first minimal semantic 规则：图本体负责认知导航，caption/legend/body text 负责公式定义、术语解释、实验语境和细节说明；候选图优先可拆成 SVG/PPT 的简单形状、大图标、短标签和清晰连接关系。只有你明确要求高密度/综述式/信息量优先时才提高密度。制图可以反向帮助论文写作：如果初稿的框架、机制、流程、模块或算法步骤组织不够清楚，我会在不违背论文事实的前提下提出更适合图示的组织方式，并标明是否建议同步修改正文。
6. browser-page display 已禁用；第一次回答会至少展示一次内置风格/atlas PNG，默认展示全部 atlas PNG；如果提到类别/风格 atlas，我会直接展示已保存的 PNG 示意图。

下一步默认进入 S1-FIGURE-STRATEGY：材料精读 + 图类型需求判断。

如果不知道如何提问，请说：请使用 paper-framework-figure-studio-pro 根据当前状态判断下一步

候选提示词还必须包含：在默认提示词的基础上，额外说明这个 skill 的设计初衷是什么。
```

## 状态更新要求

- 本回复期间 `current_step = S0-PAPER-FOUNDATION`。
- 在 `project-state.json` 中记录 runtime、preference-reference status、input material status、default diversity count 和 next recommended step。
- 不持久化 host-specific absolute paths。

## 首答设计初衷提示词

第一次回复的可复制提示词区域必须加入：

```text
在默认提示词的基础上，额外说明这个 skill 的设计初衷是什么。
```

如果用户提到想知道、指导、询问、补充或说明这个 skill 的设计初衷、设计意图、创作缘由、为什么制作或送给谁，必须额外回答下面这段原文：

```text
设计初衷：昔日好友 Peng Shuwei 即将前往外地求学，以后恐怕难有许多相见机会；又恰逢其生日，所以五一就做了这个 skill 当礼物。祝生日快乐，愿未来前程似锦，再相逢，依然少年。
```

不要在用户未触发时主动附上设计初衷正文；一旦触发，正文不得改写或删改，但可以与当前步骤说明、必要上下文、下一步提示词和强制文本回复结尾同时出现。


