# Paper Foundation Report Contract

S0-PAPER-FOUNDATION is the base of the whole skill. If the user provides a PDF, LaTeX, full paper text, detailed method/model description, report, supplement, or comparable source material, S0 must produce and print a rich, detailed, accurate paper foundation report before the workflow relies on the paper.

If the user provides only a simple short description, do not fake depth. Perform lightweight scoping, record `deep_reading_status = not_triggered_simple_description`, and say that the full foundation report becomes required once paper/source material is provided.

## Required Output

Save and print the report:

```text
outputs/S0-paper-foundation/paper-foundation-report.md
```

The report is not optional background. S1-FIGURE-STRATEGY through S9-FIGURE-TEXT must treat it as the paper-content anchor and algorithm/model anchor.

## Minimum Content

The report must include:

- source inventory: file names, sections/pages/anchors read, and missing material;
- problem setting, assumptions, task definition, and related-work gap;
- paper contribution stated conservatively, without marketing language;
- method pipeline in ordered steps using the paper's own terms;
- model/component/module inventory with each module's role, input, output, and dependency;
- training flow, inference flow, data flow, and control flow when present;
- equations/objectives/losses/algorithm blocks translated into figure-relevant meaning;
- terminology table: paper term, allowed figure label, forbidden paraphrase, evidence anchor;
- arrow semantics table: source, target, relation meaning, evidence anchor;
- visual implication table: what must be drawn, what may be implicit, what must not be drawn;
- semantic density budget: figure layer, caption/legend layer, omitted/implicit layer, expected main-module count, label/formula limits, icon landmark plan, and vector-buildability risks;
- organization diagnosis: which paper sections/module boundaries/algorithm-step groupings are source facts, which are draft exposition choices, and which could be reorganized for a clearer framework figure without changing the paper meaning;
- uncertainty list and user-confirmation questions;
- density guidance for the eventual framework figure.

## Quality Bar

The report must be detailed enough that S4-CANDIDATE-BRIEF, S5-CANDIDATE-IMAGE, and S6-FINAL-SELECT can check whether a visual module, arrow, label, or implied algorithm step is faithful to the paper.

Generic summaries are invalid. Do not write only "the paper proposes a framework" or only a core-innovation summary. Every important visual claim should point back to a source section, page, equation, algorithm block, table, figure, or user-provided method note when available.

## Reuse Rule

Every later step must explicitly reuse the foundation report:

- S1-FIGURE-STRATEGY uses it for figure type and reader-effect diagnosis.
- S2-SKETCH-EXPLORE may explore boldly, but must not invent mechanisms absent from the report.
- S3-DIRECTION-SELECT records paper-fact risks against the report.
- S4-CANDIDATE-BRIEF builds candidate prompts from report anchors.
- S5-CANDIDATE-IMAGE preserves method/algorithm/model facts.
- S6-FINAL-SELECT prints a paper recheck table against the report before choosing the final reference.
- S7-FOREGROUND-IMAGE preserves reusable foreground elements from the selected reference without changing paper meaning.
- S8-SVG-PPT does not reinterpret the paper; it packages extracted elements.
- S9-FIGURE-TEXT writes caption/legend/body text from the report and final artifacts.

## Non-Contradictory Reorganization Rule

The paper foundation report is a factual anchor, not a command to mirror the draft's current exposition. Draft section order, module names, flow segmentation, mechanism narration, and algorithm-step grouping may be weak or provisional. Later design steps may reorganize, merge, split, rename, or reorder these elements when doing so improves reader comprehension, as long as the figure does not contradict source evidence, method semantics, mathematical definitions, input/output relations, causal/dependency relations, or reported results.

When a design reorganizes the draft, it must record a visible reorganization/enhancement note: original draft expression, proposed figure organization, evidence anchor, communication benefit, risk, and whether the paper text should be revised to match the clearer structure.

## Vector-First Minimal Semantics

Follow `references/vector-first-minimal-semantic-rule.md` when converting paper reading into figure decisions. Do not treat every formula, term, or algorithm substep as a required visual element. Important details may be preserved in caption/legend/body text instead of the image when they would damage readability or SVG/PPT buildability.

## Non-Goals

Do not import code-reading workflows, paper-code crosswalks, or external skill dependencies. This skill only borrows the paper deep-reading discipline: careful reading, source anchoring, method decomposition, terminology precision, and visual implication extraction.

