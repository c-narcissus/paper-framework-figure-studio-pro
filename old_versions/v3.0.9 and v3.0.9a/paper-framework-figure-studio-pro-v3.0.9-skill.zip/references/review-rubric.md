# Review Rubric

Use this rubric for text review steps.

## Global Exploration

S1-FIGURE-STRATEGY through S3-DIRECTION-SELECT emphasize:

- first-glance appeal;
- reader hook;
- diverse visual grammars;
- broad figure subtype fit;
- useful reorganization of weak draft structure without contradicting source evidence;
- figure-vs-caption split and semantic density discipline;
- large landmark icons instead of many tiny dictionary icons;
- clear risk notes when a sketch simplifies or enhances the source.

## Local Refinement

S4-CANDIDATE-BRIEF through S6-FINAL-SELECT emphasize:

- semantic fidelity to the paper's method/algorithm/model evidence, not mechanical mirroring of draft section/module boundaries;
- terminology mapping: paper terms, improved figure labels, and any shorthand must remain traceable;
- required modules and their relations, allowing better grouping/splitting when evidence supports it;
- arrow/data/control semantics that do not contradict the paper;
- readable density for a paper figure;
- vector-first buildability for SVG/PPT: simple primitives, separable foreground elements, short editable labels, few formulas, and clean connectors;
- preservation of important omitted details through caption/legend/body text instead of image crowding;
- first-glance appeal without posterization;
- explicit divergence/enhancement notes.

S6-FINAL-SELECT must recheck the paper/source and print a table covering terminology, modules, arrows, constraints, contribution claims, design reorganization notes, and paper-writing revision suggestions before selecting the final reference.

## Delivery

S7-FOREGROUND-IMAGE must produce a foreground-only extraction source from the selected final reference. It must remove texture, borders, frames, region boxes, grids, connectors, arrows, text, titles, and descriptions.

S8-SVG-PPT must build a foreground SVG catalog and self-contained PPTX from that foreground-only source. It cannot be replaced by a single new image, concept explanation, or skipped PPTX/SVG artifacts.

Cleanup is required before rerunning any executed earlier/current step.


