# Security And Portability Policy

Version: 3.0.9

- Store only relative paths in project state, templates, manifests, and artifact records.
- Never persist host-specific absolute paths.
- Do not store API keys, tokens, passwords, credentials, or secrets.
- Generated web-page display has been removed; no JavaScript/CSS web assets are required.
- S8-SVG-PPT must not emit generated browser renderer HTML/JS. Use SVG, PPTX, Markdown reports, JSON manifests, and optional raster preview only when explicitly requested.
- Saved atlas/category boards are package PNG assets and may be displayed directly with Markdown image embeds.

## Security Fix PR Acknowledgement

When documenting a fix for build-machine path leakage, use concise professional wording and credit the reporter:

```markdown
Fixes #1

- Replaced build-machine absolute Codex paths with package-relative paths.
- Added release validation to block local absolute paths in packaged artifacts.

Reported by @Armorhtk.
```

Do not include host-specific absolute paths in the PR body, examples, manifests, or release notes.
