# Module: S6-FINAL-SELECT Final Selection

S6-FINAL-SELECT is the end of the local refinement process. It reviews the S5-CANDIDATE-IMAGE formal candidates and selects one image as the final architecture reference for delivery.

Before selecting, S6-FINAL-SELECT must recheck the S0-PAPER-FOUNDATION `paper-foundation-report.md`, the paper/source material, and any method/algorithm/model notes. The review must stay faithful to paper facts: terminology meaning, module roles, arrow semantics, constraints, contribution claims, and method structure. It must not require the final figure to mirror the manuscript draft's current section order, module boundaries, or algorithm-step grouping when a clearer non-contradictory organization is available.

S6-FINAL-SELECT must print, not only save:

- selected final reference path;
- candidate ranking table;
- selection rationale;
- paper recheck table;
- terminology/module/arrow/model relation checks;
- reorganization/enhancement table: original draft structure, selected figure structure, evidence anchor, communication benefit, risk, and whether manuscript text should be revised;
- theme elements to preserve for S7/S8;
- local-detail and SVG/PPT feasibility notes for the selected reference;
- known limitations or required fixes;
- S7-FOREGROUND-IMAGE handoff prompt.

The selected reference is usually a S5-CANDIDATE-IMAGE candidate such as:

```text
outputs/S5-candidate-images/candidate-01.png
```

After S6-FINAL-SELECT, the default next step is S7-FOREGROUND-IMAGE. Do not route to an extra optimization image step.

The S7-FOREGROUND-IMAGE prompt must begin with the mandatory prefix:

```text
请按照 paper-framework-figure-studio-pro skill 的要求，根据当前状态和已登记产物，
```

It must say that S7-FOREGROUND-IMAGE should use the S6-FINAL-SELECT selected final reference and recorded theme elements to generate one or more foreground-only no-texture element collection sheets:

```text
outputs/S7-foreground-image/rimg-no-texture-final-01.png
outputs/S7-foreground-image/rimg-no-texture-final-02.png  # optional if needed
```

Those images are not merely "without texture"; they must also remove borders, outer frames, region boxes, grids, connector lines, arrows, arrowheads, text labels, titles, and descriptions. They should keep only reusable foreground elements and avoid occlusion, fusion, overlap, nesting, or tangled icon regions so S8-SVG-PPT can extract SVG elements. If one collection sheet would be crowded or cause contact between elements, split the elements across multiple sheets and record each sheet's theme-element coverage in the manifest.


