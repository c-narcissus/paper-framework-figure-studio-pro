# Module: S7-FOREGROUND-IMAGE To S9-FIGURE-TEXT Finalization

Finalization route:

```text
S6-FINAL-SELECT -> S7-FOREGROUND-IMAGE -> S8-SVG-PPT -> S9-FIGURE-TEXT
```

## S7-FOREGROUND-IMAGE

S7-FOREGROUND-IMAGE uses the S6-FINAL-SELECT selected final reference plus the recorded theme-element inventory and generates one or more SVG-extraction-friendly foreground-only element collection images:

```text
outputs/S7-foreground-image/rimg-no-texture-final-01.png
outputs/S7-foreground-image/rimg-no-texture-final-02.png  # optional if needed
```

It also saves:

```text
outputs/S7-foreground-image/foreground-only-manifest.json
```

The foreground-only output must remove texture, underlays, borders, outer frames, region boxes, grid lines, connector lines, arrows, arrowheads, labels, titles, descriptions, and explanatory callouts. It keeps only reusable foreground elements. Each element must be separated enough for SVG extraction; split into multiple collection sheets when needed to reduce overlap, contact, occlusion, fusion, and ambiguous nesting. The manifest must record which theme elements each sheet covers.

## S8-SVG-PPT

S8-SVG-PPT must generate a self-contained PPTX and cannot be replaced by a single new image or concept explanation.

Steps:

1. Run cleanup if previous S8-SVG-PPT outputs or records exist.
2. Confirm the selected final reference and foreground-only image exist.
3. Segment/identify reusable foreground elements from `rimg-no-texture-final-01.png` and any additional collection sheets listed in `foreground-only-manifest.json`.
4. Write `outputs/S8-svg-ppt/_work/icon_catalog_spec.json`.
5. Use `scripts/figure_studio_s8_svg_catalog_ppt.js` with `--reference-final` and `--no-texture-final`.
6. Validate SVG/PPTX outputs and print a delivery report.

PPTX slides:

1. grayscale selected final reference;
2. original selected final reference;
3. SVG catalog pages.

## S9-FIGURE-TEXT

S9-FIGURE-TEXT writes caption, legend, body reference text, and final usage notes. It must recheck the paper/source and print the final text inline.

