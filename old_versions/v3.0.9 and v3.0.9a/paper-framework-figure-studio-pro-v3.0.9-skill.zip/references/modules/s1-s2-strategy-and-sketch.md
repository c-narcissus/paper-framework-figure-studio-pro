# Module: S1-FIGURE-STRATEGY Reading 与 S2-SKETCH-EXPLORE

## S1-FIGURE-STRATEGY：材料精读 + 图类型需求诊断

S1-FIGURE-STRATEGY 读取目标论文/PDF/report，并输出：

- source inventory 和材料质量说明；
- paper problem、method mechanism、key entities、evidence anchors；
- S0-PAPER-FOUNDATION `paper-foundation-report.md` 的延续或补全：algorithm steps、model components、training/inference flow、inputs/outputs、losses/objectives、terminology map、arrow semantics、paper-only unresolved questions；
- figure-type diagnosis：framework overview、architecture、pipeline、data/model-flow、mechanism、agent workflow、case walkthrough、evidence schematic 或 hybrid；
- broad diagram direction，以及这张图需要防止读者误解什么；
- draft-structure diagnosis：论文初稿的章节、模块、流程或算法步骤划分是否适合直接制图；若不适合，提出不违背论文事实的重组/提炼方向；
- semantic density budget：figure layer / caption-legend layer / omitted-implicit layer、主模块数量、图内标签/公式限制、landmark icon 计划和 SVG/PPT 可绘制性风险；
- 是否进入 S2-SKETCH-EXPLORE 的建议。

若用户只提供简单短描述，S1-FIGURE-STRATEGY 可以保持轻量级图类型诊断，不强行生成完整 paper deep-reading report；但必须标注依据来自 user description，而不是 paper source。若用户提供 PDF、LaTeX、论文正文、report、supplement 或详细方法描述，S1-FIGURE-STRATEGY 必须继续深读，不能把算法/方法/模型理解简化成“核心创新点摘要”。

触发深读时，S1-FIGURE-STRATEGY 必须按 `references/paper-deep-reading-contract.md` 继续 paper-only 精读。这里不执行代码深读，不建立 paper-code crosswalk，也不把外部实现细节作为论文事实。

用户上传的风格参考图只在 S1-FIGURE-STRATEGY 中使用：辅助判断图类型、读者效果和表达方向。S1-FIGURE-STRATEGY 输出必须明确说明这些偏好不会自动传递到后续 step。

S1-FIGURE-STRATEGY 不生成目标论文图像。如果提到 subtype/category boards，直接嵌入已保存的 atlas PNG。

进入 S2-SKETCH-EXPLORE 前，必须查看 skill 内部参考资料作为低保真方向借鉴，至少覆盖：

- `references/subtype-illustration-atlas.md`
- `references/visual-style-and-board-protocol.md`
- `references/figure-class-taxonomy.md`
- `references/figure-pattern-library.md`
- `references/modules/s1-s2-strategy-and-sketch.md`

这些资料用于借鉴图类型、结构方向、读者路径、视觉语法和候选组织方式；不能覆盖论文事实，也不能把用户上传风格参考自动传递到草图阶段。

进入 S2-SKETCH-EXPLORE 前，S1-FIGURE-STRATEGY 必须在正文中用 Markdown 表格展示至少 6 个低保真方向草图的设计思想。表格至少比较：候选 ID、作者需求、文章内容锚点、算法/模型依据、从论文精读中提炼出的核心主线、是否沿用或重组论文初稿结构、figure-vs-caption 分工、矢量优先/密度预算、与论文事实的非违背性、视觉传达/风格类别、排版策略、第一眼吸引力设计、看图理解程度、作者意图表达清晰度、偏离/增强备注、论文写作可改进点、主要风险。不能只把这些内容写入附件或状态。

## S2-SKETCH-EXPLORE：低保真方向草图

S2-SKETCH-EXPLORE 是 `IMAGE_ONLY_PLUS_PROMPT`，默认且至少生成 6 个 low-fidelity sketches，最多 8 个，除非用户明确要求更多且不超过上限；不得少于 6 个。每张草图必须按环境使用生图工具单独生成：Codex 用 Image Gen，ChatGPT 网页版用 Create Image / ChatGPT Images 2.0，两者都没有才用其他 approved image generation API。不得用 contact sheet、拼接草图板、SVG/HTML/canvas/Mermaid/PPT 形状或手工绘图替代。上传的风格参考图不自动增加 preference-informed extras，也不作为草图风格约束。

S2-SKETCH-EXPLORE 的草图构思必须体现已查看的内部参考资料中的结构启发，例如 subtype、layout grammar、reader path、density/detail、visual communication style 和 first-glance hook。6 张草图必须从这些不同角度提出各不相同的建议，不能只是同一布局换配色。所有 paper-specific 内容仍以 S1-FIGURE-STRATEGY 精读材料为准。

草图必须从论文精读中提炼最重要的模块、数据/控制流、读者路径和贡献表达，只画大尺度框架。默认把图内内容控制成 3-6 个主模块、1 条主数据/控制流、0-3 条辅助流、少量大图标和极短标题；公式通常不进入草图，除非它是论文机制的视觉核心。草图可以重组论文初稿的模块边界、流程顺序或算法步骤层级，但必须保留论文事实的语义约束。允许内容：block layout、lanes、rough arrows、rough grouping、placeholder labels、必要的数据流符号，以及极少量 paper-specific entity names。

禁止内容：polished final rendering、dense labels、长段文字、密集公式、过多符号、fake results、final-style color system，或把 sketches 当成 S5-CANDIDATE-IMAGE formal candidates。能用清晰图标表达时，不用文字/公式；图标必须足够大，不得把图标缩成难以辨认的小装饰。每张草图最多给模块或大步骤使用简短标题，并只保留必要的数据流符号或无法用图标表示时的公式；科学上重要但视觉上过密的细节应在后续 S9 caption/legend/body text 中解释，而不是塞进图里。

草图后，只附极简下一步提示词，告诉用户可以进入 S3-DIRECTION-SELECT 做低保真草图评价排序或要求重生成草图。若提供多个方向选择，下一次文本回复必须为每个方向提供可复制提示词；并且每次文本回复最后仍必须单独追加 `如果不知道如何提问，请说：请使用 paper-framework-figure-studio-pro 根据当前状态判断下一步`。



