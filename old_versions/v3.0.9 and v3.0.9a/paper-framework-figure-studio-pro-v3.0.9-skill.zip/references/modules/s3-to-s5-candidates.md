# Module: S3-DIRECTION-SELECT 到 S5-CANDIDATE-IMAGE 正式候选

## S3-DIRECTION-SELECT：论文逻辑压缩 + 第一轮方向矩阵准备

S3-DIRECTION-SELECT 不能在未参考方法材料时只抽取核心创新点。若论文材料包含算法流程、模型结构、系统流程、训练/推理过程、输入输出关系、损失/目标函数、公式或方法介绍，必须把这些内容作为 compressed paper logic、Figure Effect Contract 和后续 active matrix 的 `algorithm_model_anchor` 参考来源。是否显性画出这些细节按实际论文情况和 figure 目标决定。S3 可以提出比论文初稿更清楚的框架、机制、流程、模块或算法步骤组织，但必须标注证据锚点、非违背性和写作修改建议。

基于 S2-SKETCH-EXPLORE 的 low-fidelity direction board，S3-DIRECTION-SELECT 输出：

- compressed paper logic；
- Figure Effect Contract；
- 从低保真草图中选择 active matrix 所需数量的结构上不同方向；默认是 2 个方向，除非用户明确修改矩阵规格或锁定更少方向；
- 为后续 S4-CANDIDATE-BRIEF/S5-CANDIDATE-IMAGE 准备 active first-round matrix；默认是 `2 directions x 3 style treatments = 6`；
- exact 或 near-exact labels；
- improved figure labels when draft labels are unclear, with paper-term mapping and non-contradiction notes；
- required modules 和 evidence anchors；
- draft-structure reorganization notes and paper-writing improvement suggestions when the visual structure is clearer than the manuscript draft；
- figure-vs-caption split, semantic density budget, and vector-first buildability constraints from `vector-first-minimal-semantic-rule.md`；
- style-family assignment 与 color semantics；
- 推荐选项和所有备选项的可复制提示词。

S3-DIRECTION-SELECT 必须在筛选低保真方向前查看 skill 内部参考资料，尤其是 `references/subtype-illustration-atlas.md`、`references/visual-style-and-board-protocol.md`、`references/figure-class-taxonomy.md`、`references/figure-pattern-library.md`、`references/first-round-diversity-matrix-policy.md` 和 `references/prompt-generation-policy.md`。这些资料用于借鉴结构差异、风格分类、版式语法、候选矩阵和 prompt 组织，不得替代论文事实。

不要因为 S0-PAPER-FOUNDATION/S1-FIGURE-STRATEGY 上传的风格参考图自动增加偏好方案。只有用户在当前 step 明确选择或重述某个偏好时，才把它作为新的用户决策记录。

如果 S2-SKETCH-EXPLORE 少于 2 个可用方向，S3-DIRECTION-SELECT 应建议补充低保真方向或记录 first-round diversity limitation。不要默认把一个方向扩成 6 个轻微风格变体。

## S4-CANDIDATE-BRIEF：第一轮正式生成设置

S4-CANDIDATE-BRIEF 定义 fixed content、variation axes、candidate count、generation strategy、prompts 和 S5-CANDIDATE-IMAGE 的比较标准。

S4-CANDIDATE-BRIEF 必须继续使用内部参考资料校准第一轮候选矩阵：每个候选的 subtype、layout grammar、visual rhetoric、style treatment、density/detail 和 reader path 都要有来源于内部参考资料的设计理由。S4-CANDIDATE-BRIEF brief/state 应记录 `internal_reference_consulted = true` 以及实际参考的 package-relative 文件列表。

Candidate count 默认是 6 个 unbiased formal candidates，结构为 `2 low-fidelity directions x 3 visual communication style treatments`。上传的风格参考图不会自动增加 preference-informed extras。总数仍不得超过 8。

默认矩阵按最佳视觉传达实践分配：

- `D1-A`: 低保真方向 1 + schematic precision treatment（formal architecture schematic 或 blueprint / technical drawing）。
- `D1-B`: 低保真方向 1 + editorial clarity treatment（clean editorial flat 或 minimal line-art schematic）。
- `D1-C`: 低保真方向 1 + mechanism/evidence treatment（mechanism snapshot、mini-evidence infographic 或 premium scientific illustration）。
- `D2-A`: 低保真方向 2 + schematic precision treatment。
- `D2-B`: 低保真方向 2 + editorial clarity treatment。
- `D2-C`: 低保真方向 2 + mechanism/evidence treatment。

S4-CANDIDATE-BRIEF 必须说明每个 D 方向来自哪个低保真草图、为什么保留、各 style treatment 的读者效果差异，以及矩阵内候选共享哪些论文逻辑。不要把第一轮写成同一布局的轻微配色变化。

S3-DIRECTION-SELECT 必须在正文中用 Markdown 表格评价并排序低保真草图。低保真评价不按渲染精细度排序，而按最佳视觉传达实践排序：是否不违背论文事实、是否吸引眼球、是否承载论文主线、是否比初稿结构更利于读者理解、读者路径是否清楚、是否能看图大致理解文章、是否表达作者意图、是否能扩展成 active matrix、主要风险。原则上必须符合论文事实；不要求完全沿用论文初稿描述。若某个方向为了更好的框架图表达而重组或增强了用户提供信息，必须写出偏离/增强备注，并说明证据锚点、沟通收益、风险、是否建议用户同步修改论文正文。

S4-CANDIDATE-BRIEF 必须在正文中用 Markdown 表格展示第一轮正式候选设计思想，列出候选 ID、作者需求、文章内容锚点、算法/模型依据、主题元素清单、是否沿用/重组初稿结构、figure-vs-caption 分工、局部细节展示策略、矢量化友好策略、密度预算、与论文事实的非违背性、视觉传达/风格类别、排版策略、第一眼吸引力设计、看图理解程度、作者意图表达、偏离/增强备注、论文写作建议和主要风险。不能只把这些内容写入附件或 brief。

S4-CANDIDATE-BRIEF 生图前必须详细列出每个候选图会包含哪些主题元素，并给出总覆盖核对：这些主题元素合计必须覆盖论文框架图必须表达的核心模块、输入输出、关键数据/控制流、方法阶段、模型/算法主体、必要符号和可省略内容。每个候选还必须写清哪些重要信息移交给 caption/legend/body text，不进入图像本体。若某个重要主题无法用图标表达，才能使用短公式或极短文字；否则优先使用清晰大图标、空间关系和少量数据流符号。

S0-PAPER-FOUNDATION 首答已经必须告知默认 2x3 矩阵：低保真草图后默认选择 2 个结构方向，每个方向分配 3 个视觉传达风格。S3-DIRECTION-SELECT/S4-CANDIDATE-BRIEF 只需声明当前 active matrix 是默认 2x3，还是用户修改后的矩阵规格，例如 3 个低保真方向 x 每个方向 2 个视觉传达风格。若用户更改规格，则按用户更改后的矩阵执行，并在 S4-CANDIDATE-BRIEF brief/state 中记录 `first_round_matrix_source = user_modified`。

## S5-CANDIDATE-IMAGE：第一轮正式候选图

S5-CANDIDATE-IMAGE 是 `IMAGE_ONLY_PLUS_PROMPT`。默认生成 6 张正式 target-paper framework figure candidates。每张候选图必须按环境使用生图工具单独生成：Codex 用 Image Gen，ChatGPT 网页版用 Create Image / ChatGPT Images 2.0，两者都没有才用其他 approved image generation API。不得用 contact sheet、候选拼接板、SVG/HTML/canvas/Mermaid/PPT 形状或手工绘图替代。图像之后只附极简下一步提示词和“不知道怎么问”的兜底提示；不输出候选评价、caption、长说明或 state footer。

S5-CANDIDATE-IMAGE 生成 prompt 必须基于 S4-CANDIDATE-BRIEF 的内部参考借鉴记录、算法/模型参考依据、主题元素清单和总覆盖核对执行：候选应在结构方向、视觉修辞、密度、读者路径、局部细节展示和 callout 策略上真实差异化；可以采用比初稿更清晰的组织方式，但不得引入未被论文材料支持的新机制、模块或关系，也不得在未参考论文已有算法或模型介绍时只表现核心创新点。

S5-CANDIDATE-IMAGE 必须从后续 SVG/PPT 矢量化可实现性出发设计：避免照片质感、复杂纹理、半透明叠影、过度写实、密集微小装饰、难以拆分的融合图形和艺术化笔触；优先使用可拆成独立 SVG 的清晰形状、图标、模块主体、少量短标题和明确但不纠缠的数据流关系。局部细节展示应使用放大窗、局部机制片段、剖面/截面、mini-evidence 或模块内部结构等可矢量化方式，而不是堆满文字说明。若生成 prompt 想加入大量文字、公式、符号或小图标，必须先删减到 figure layer，只保留对第一眼理解不可替代的内容。

S5-CANDIDATE-IMAGE 输出命名建议：

- `candidate-D1-A.png`
- `candidate-D1-B.png`
- `candidate-D1-C.png`
- `candidate-D2-A.png`
- `candidate-D2-B.png`
- `candidate-D2-C.png`

生成后，记录 image generation event 和可用的 generated paths。



