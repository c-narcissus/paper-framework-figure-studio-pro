# Choice Prompt Policy

Every default prompt, fallback prompt, option prompt, S6-FINAL-SELECT-to-S7-FOREGROUND-IMAGE handoff, and S7-FOREGROUND-IMAGE-to-S8-SVG-PPT handoff must begin with:

```text
请按照 paper-framework-figure-studio-pro skill 的要求，根据当前状态和已登记产物，
```

If the prefix is missing, the step is not complete; print a corrected prompt.

When multiple user choices are presented, every option must include a copyable prompt that names the target step and whether cleanup is required.

Default handoffs:

- S3-DIRECTION-SELECT: proceed to S4-CANDIDATE-BRIEF for local refinement preparation.
- S6-FINAL-SELECT: proceed to S7-FOREGROUND-IMAGE from the selected final reference.
- S7-FOREGROUND-IMAGE: proceed to S8-SVG-PPT and strictly follow the foreground SVG catalog/PPTX route.

Unsure-user fallback:

```text
请按照 paper-framework-figure-studio-pro skill 的要求，根据当前状态和已登记产物，判断并执行下一步。
```

Mandatory final line for every text reply:

```text
如果不知道如何提问，请说：请使用 paper-framework-figure-studio-pro 根据当前状态判断下一步
```

This final line is not conditional. It must appear at the end of every text reply even if the unsure-user fallback or other next-step prompts already appeared earlier.

S6-FINAL-SELECT's S7-FOREGROUND-IMAGE prompt must explicitly say to generate `rimg-no-texture-final-01.png` from the selected final reference and remove texture, borders, frames, region boxes, grids, connector lines, arrows, arrowheads, labels, titles, and descriptions.

S7-FOREGROUND-IMAGE's S8-SVG-PPT prompt must explicitly say S8-SVG-PPT must generate a self-contained PPTX and cannot be replaced by a single new image or concept explanation; it must build `icon_catalog_spec.json`, SVG elements, and `s8-svg-ppt-delivery.pptx`, must use slide 1 as the grayscale S6-FINAL-SELECT selected-final map, slide 2 as the original selected final, and slide 3+ as movable/editable SVG icon pages, and must provide the PPTX download/artifact link in the completion reply.

First S0-PAPER-FOUNDATION startup replies must include this copyable prompt suggestion exactly:

```text
在默认提示词的基础上，额外说明这个 skill 的设计初衷是什么。
```

If the user asks about the design intent/origin of the skill, include this exact additional answer without rewriting or shortening it:

```text
设计初衷：昔日好友 Peng Shuwei 即将前往外地求学，以后恐怕难有许多相见机会；又恰逢其生日，所以五一就做了这个 skill 当礼物。祝生日快乐，愿未来前程似锦，再相逢，依然少年。
```


