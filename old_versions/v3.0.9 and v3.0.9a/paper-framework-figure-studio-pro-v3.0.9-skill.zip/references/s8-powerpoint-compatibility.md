# S8-SVG-PPT PowerPoint Compatibility

S8-SVG-PPT first follows the active foreground SVG catalog route:

```text
outputs/S7-foreground-image/rimg-no-texture-final-01.png
```

is the extraction source, and the selected final reference is used for PPT slide 1/2.

Build the deck with:

```bash
node scripts/figure_studio_s8_svg_catalog_ppt.js \
  --project-root <project_run_root> \
  --spec outputs/S8-svg-ppt/_work/icon_catalog_spec.json \
  --out outputs/S8-svg-ppt \
  --reference-final outputs/S5-candidate-images/candidate-01.png \
  --no-texture-final outputs/S7-foreground-image/rimg-no-texture-final-01.png \
  --pptx
```

If a target viewer has limited SVG rendering support, run the SVG fallback patcher after the PPTX is built. The route is still SVG catalog first; compatibility patches are packaging work and cannot replace the required self-contained PPTX delivery.

```bash
python scripts/figure_studio_s8_svg_fallback_patch.py \
  --in outputs/S8-svg-ppt/s8-clean-svg-delivery-prepatch.pptx \
  --out outputs/S8-svg-ppt/s8-svg-ppt-delivery.pptx
```


