# S7/S8 Runtime Dependencies

## Required

- Python 3.9 or newer.
- Standard library support is enough for S7-FOREGROUND-IMAGE contract generation.

## S8-SVG-PPT Optional Dependencies

Install these when foreground SVG catalog generation or PPT output is needed:

```bash
npm install pptxgenjs sharp image-size
python -m pip install lxml
```

- Node + pptxgenjs: `s8-svg-ppt-delivery.pptx`.
- sharp: grayscale textured-final reference generation and optional SVG preview rendering.
- image-size: aspect-ratio fitting for reference images.
- lxml or standard XML tooling: optional SVG validation helpers.

If a PPTX-capable runtime is unavailable, S8-SVG-PPT cannot complete the required PPT delivery. Record the limitation in state and do not mark S8-SVG-PPT complete until the self-contained PPTX exists and embeds its SVG assets internally.

## Not Required

- No standalone web-preview pages.
- No browser automation.
- No Cairo/CairoSVG dependency is required by default.


