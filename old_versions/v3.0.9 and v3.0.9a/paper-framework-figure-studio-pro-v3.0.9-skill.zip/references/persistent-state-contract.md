# Persistent State Contract

Persistent state lives at:

```text
figure-studio-runs/<project_id>/state/project-state.json
```

All stored paths must be project-run relative. The state file is the workflow memory, artifact index, and interruption-recovery checkpoint.

Allowed current-step values:

```text
S0-PAPER-FOUNDATION
S1-FIGURE-STRATEGY
S2-SKETCH-EXPLORE
S3-DIRECTION-SELECT
S4-CANDIDATE-BRIEF
S5-CANDIDATE-IMAGE
S6-FINAL-SELECT
S7-FOREGROUND-IMAGE
S8-SVG-PPT
S9-FIGURE-TEXT
```

Required top-level state groups include workflow plan, step runs, artifact role registry, active artifact roles, artifacts, pending outputs, runtime environment, user preference status, image generation events, cleanup policy, and S8-SVG-PPT delivery state.

## Step Runs And Epochs

`step_runs` stores `step`, `epoch`, `attempt_id`, `status`, `output_dir`, `started_at`, and `updated_at`.

When a step is rerun or the workflow returns to an earlier step for execution, bump the epoch for every step in the cleanup span from `target_step` through the previous `current_step`, inclusive.

## Artifact Records

Every created artifact record includes `artifact_id`, `step`, `kind`, `relative_path`, `artifact_role`, `step_epoch`, `attempt_id`, sources, summary, tags, status, timestamps, and optional content hash.

Prefer artifact roles such as:

- `s6.final_selection`
- `s6.selected_reference_final`
- `s7.foreground_only_final`
- `s7.foreground_manifest`
- `s8.delivery_pptx`

## S7-FOREGROUND-IMAGE State

S7-FOREGROUND-IMAGE is complete only when the active foreground-only image exists:

```text
outputs/S7-foreground-image/rimg-no-texture-final-01.png
```

and the lightweight manifest exists:

```text
outputs/S7-foreground-image/foreground-only-manifest.json
```

The foreground-only image is generated from the S6-FINAL-SELECT selected reference and removes texture, borders, frames, region boxes, grids, connector lines, arrows, arrowheads, labels, titles, and descriptions.

## Cleanup State

`step_rewind_cleanup_policy.cleanup_events` records each rerun or rollback cleanup. Events move through `planned`, `running`, and `completed`.

Covered output records must be removed from active state collections, including `artifacts`, `image_generation_events`, `pending_outputs`, and `active_artifact_roles`. Keep cleanup events as the audit trail and never delete the state file.

Health check:

```bash
python scripts/figure_studio_state.py doctor --project-id <project_id>
```

`doctor` must report an error if S8-SVG-PPT is active but the S7-FOREGROUND-IMAGE foreground-only image is missing.



