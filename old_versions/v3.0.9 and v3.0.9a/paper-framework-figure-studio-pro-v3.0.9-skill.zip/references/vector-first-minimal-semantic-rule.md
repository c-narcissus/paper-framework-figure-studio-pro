# Vector-First Minimal Semantic Figure Rule

Use this rule whenever S1-S6 decide what a research-paper framework figure should show, and whenever S7-S8 prepare reusable foreground elements for SVG/PPT delivery.

## Core Principle

A top-conference/top-journal framework figure should make one main claim visually clear. It is not a compressed poster version of the whole paper. The figure carries the cognitive map; the caption, legend, and body text carry definitions, caveats, equations, and explanatory detail.

The preferred tradeoff is:

- fewer elements, clearer hierarchy;
- larger icons, fewer icons;
- short module labels, not sentence labels;
- one dominant reader path, not many competing flows;
- simple vector primitives, not painterly effects;
- source-grounded reorganization, not mechanical copying of weak draft structure.

## Three-Layer Information Model

Before S2-SKETCH-EXPLORE and before S4-CANDIDATE-BRIEF, separate content into three layers:

1. **Figure layer**: the minimum visible structure needed to understand the paper's main method or mechanism at a glance.
2. **Caption/legend layer**: definitions, equation meanings, important constraints, shorthand explanations, and small methodological caveats.
3. **Omitted/implicit layer**: secondary implementation details, repeated substeps, hyperparameters, minor variants, and anything that would make the figure crowded without improving first-glance understanding.

If a detail cannot justify being in the figure layer, keep it out of the image and move it to caption/legend/body text.

## Density Budgets

Use these as defaults unless the user explicitly asks for a high-density taxonomy or survey-style overview:

- main visible modules: usually 3-6;
- dominant data/control flow: 1;
- secondary flows: usually 0-3;
- formulas visible inside the figure: usually 0, at most 1-2 when essential;
- module or large-step labels: short phrases only;
- icon usage: one clear landmark icon per major entity/module/process when useful, not one tiny icon per term;
- callouts: few, large, and structurally meaningful;
- decorative or repeated micro-icons: avoid.

The figure should still read when scaled down to a paper column or slide thumbnail. If the design only works at full-screen size, it is too dense.

## Vector-First Buildability

Every S4/S5 candidate must pass a vector-buildability check:

- Can the main design be rebuilt from rectangles, rounded rectangles, circles, simple paths, lines, arrows, and simplified icons?
- Are important icons large enough to redraw as independent SVGs?
- Are labels few enough to become editable PPT text rather than raster text?
- Are arrows and connectors separated, with minimal crossings?
- Are local-detail windows and mechanism snapshots clean enough to redraw without texture?
- Can S7 remove frames, arrows, text, and region boxes while leaving reusable foreground elements?

Avoid photo-realism, dense gradients, complex shadows, translucent layer stacks, texture-heavy backgrounds, fused shapes, tiny decorative glyphs, and deeply nested micro-panels unless the user explicitly accepts that SVG/PPT conversion will be harder.

## Figure-Caption Split

Use the figure for:

- spatial hierarchy;
- module grouping;
- method flow;
- mechanism intuition;
- key input/output relation;
- visually memorable foreground elements.

Use caption/legend/body text for:

- equation definitions;
- loss/objective details;
- hyperparameters;
- algorithmic substeps not needed for first-glance understanding;
- exact dataset/experimental context;
- limitations and assumptions;
- long terminology mapping.

S9-FIGURE-TEXT should explicitly absorb details removed from the figure when those details are still important for scientific accuracy.

## Review Questions

Ask these during S3-DIRECTION-SELECT, S4-CANDIDATE-BRIEF, and S6-FINAL-SELECT:

- What is the one visual sentence this figure should say?
- Can a reader understand the input, core mechanism, and output in a few seconds?
- Which elements are true paper facts, and which are draft exposition choices?
- Which details belong in the caption instead of the image?
- Which icons are landmarks, and which are unnecessary visual noise?
- Could this be rebuilt as editable SVG/PPT without tracing an illustration by hand?
- Does the design still work in grayscale and without relying only on color?
