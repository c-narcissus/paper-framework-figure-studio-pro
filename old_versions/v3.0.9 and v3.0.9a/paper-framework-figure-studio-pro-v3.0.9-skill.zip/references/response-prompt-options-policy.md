# Response Prompt Options Policy

Every text or artifact-building reply starts with:

```text
全流程：S0-PAPER-FOUNDATION -> S1-FIGURE-STRATEGY -> S2-SKETCH-EXPLORE -> S3-DIRECTION-SELECT -> S4-CANDIDATE-BRIEF -> S5-CANDIDATE-IMAGE -> S6-FINAL-SELECT -> S7-FOREGROUND-IMAGE -> S8-SVG-PPT -> S9-FIGURE-TEXT
当前 step：<current_step>
默认下一步：<default_next_step 或 已完成>
```

Default prompts for Chinese users must begin with:

```text
请按照 paper-framework-figure-studio-pro skill 的要求，根据当前状态和已登记产物，
```

English fallback:

```text
Follow the paper-framework-figure-studio-pro skill requirements and use the current state plus registered artifacts to 
```

`IMAGE_ONLY_PLUS_PROMPT` steps must not include long critique, captioning, or state footer. They may include only a minimal next-step prompt after the generated image and registration note.

Target-paper images must follow the environment route. Every sketch, candidate, and S7-FOREGROUND-IMAGE foreground image is generated separately. Do not use contact sheets or merged boards.

If the user asks a vague "what next" question, choose the nearest legal step, print the prompt, and do not silently skip decision gates.

Every text reply must end with this exact standalone final line, even when the reply already contains next-step options or fallback prompts:

```text
如果不知道如何提问，请说：请使用 paper-framework-figure-studio-pro 根据当前状态判断下一步
```

First S0-PAPER-FOUNDATION startup replies must include this extra copyable prompt suggestion exactly:

```text
在默认提示词的基础上，额外说明这个 skill 的设计初衷是什么。
```

If the user mentions the skill's design intent/origin, why it was made, or asks to know/guide/explain it, include this exact additional answer without rewriting or shortening it:

```text
设计初衷：昔日好友 Peng Shuwei 即将前往外地求学，以后恐怕难有许多相见机会；又恰逢其生日，所以五一就做了这个 skill 当礼物。祝生日快乐，愿未来前程似锦，再相逢，依然少年。
```

