# Architecture Governance Contract

This contract turns the skill architecture principles into operational rules. Read it before changing workflow steps, state schema, artifact roles, scripts, S7/S8 delivery, or release packaging.

## Design Pattern Map

- **Facade:** `scripts/figure_studio_state.py` is the single CLI facade for project state, artifact registration, cleanup, validation, and doctor checks.
- **Registry:** `scripts/figure_studio_core/constants.py` owns workflow steps, canonical outputs, and artifact roles. Do not duplicate those tables in other scripts.
- **Command:** `scripts/figure_studio_core/state_commands.py` contains concrete state commands. Each command must be resumable through project-relative state and must avoid paper-specific logic.
- **Memento:** `state/project-state.json` plus `step_runs`, `step_epoch`, `attempt_id`, and cleanup events are the interruption/recovery memory.
- **Strategy:** image routing is environment strategy: Codex Image Gen, ChatGPT web Create Image / Images 2.0, or another approved image API only when neither is available.
- **Adapter:** `scripts/figure_studio_s8_svg_catalog_ppt.js` adapts a semantic SVG catalog spec into SVG files and PPTX delivery without performing image recognition itself.
- **Pipeline:** S0-S9 remains a linear workflow with explicit handoffs. Returning to any earlier/current step for execution invokes covered-step cleanup first.

## Architecture Rules

- **Loose coupling:** keep workflow constants, state construction, artifact indexing, image-output registration, cleanup, SVG/PPTX build, delivery validation, and release checks in separate modules.
- **High cohesion:** each script has one job. Shared Python state helpers live under `scripts/figure_studio_core/`; S8 package building stays in the Node builder; release/audit checks stay in dedicated scripts.
- **Layered on-demand calls:** load only the reference needed for the current step. Do not force S8 delivery references into S1/S2; do not load atlas/style references into S8 unless diagnosing a visual extraction issue.
- **Transformation isolation:** S0 reports, S2 sketches, S5 candidates, S6 selection reports, S7 foreground-only images, S8 SVG/PPTX artifacts, and S9 text outputs must use distinct output roots and artifact roles.
- **Failure resume:** every generated artifact should be project-relative and registerable. Cleanup events move through planned/running/completed records and never delete `state/project-state.json`.
- **Abstraction:** scripts must accept specs, relative paths, artifact roles, and CLI flags rather than hard-coded paper names, local folders, or machine-specific paths.
- **Memory:** after interruption, use `project-state.json` as source of truth. Do not rely on conversation memory alone for current step, selected reference, foreground-only source, or pending outputs.
- **Retrievability:** every durable artifact should have a stable role, relative path, summary, tags, and source relation so it can be found without reading the whole chat.
- **Vulnerability checks:** run validate, doctor, architecture audit, production SVG validation, S8 delivery validation, and release path scan before packaging.

## Required Checks Before Packaging

```bash
python scripts/figure_studio_architecture_audit.py --target . --fail-on-issue
python scripts/figure_studio_release_check_paths.py scan --target . --fail-on-match
```

Also run the normal JSON, Python, Node, state-flow, and S8 smoke tests described in the release checklist.

## Forbidden Release Remnants

- Python caches: `__pycache__/`, `*.pyc`.
- Temporary smoke-test roots such as `.skill_test_runs/`.
- Generated browser renderer artifacts such as `editable_renderer.html` or `renderer_core.js`.
- Host-specific absolute paths, tokens, credentials, sandbox paths, or local tool-install paths.
- Obsolete workflow names that conflict with the S0-S9 sequence.
