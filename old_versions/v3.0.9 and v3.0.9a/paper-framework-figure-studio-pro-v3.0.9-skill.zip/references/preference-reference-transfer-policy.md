# Preference Reference Transfer Policy

User-uploaded style or architecture references only affect S1-FIGURE-STRATEGY by default. They help discuss figure type, reader effect, visual language, and possible expression directions.

They do not automatically transfer into S2-SKETCH-EXPLORE, S3-DIRECTION-SELECT, S4-CANDIDATE-BRIEF, S5-CANDIDATE-IMAGE, S6-FINAL-SELECT, S7-FOREGROUND-IMAGE, S8-SVG-PPT, or S9-FIGURE-TEXT.

To use a reference later, the user must explicitly promote it to a design requirement, and the state should record:

- reference path or artifact id;
- promoted step;
- exact visual property to borrow;
- paper-fact risks or constraints.

Local refinement must prioritize the paper and deep-reading report over style preference images.


