# Script Core Architecture

Main reusable scripts:

- `scripts/figure_studio_state.py`: state CLI for init, validate, doctor, cleanup, and registration.
- `scripts/figure_studio_s8_svg_catalog_ppt.js`: builds the S8-SVG-PPT SVG catalog PPTX.
- `scripts/figure_studio_s8_svg_fallback_patch.py`: optional PPTX fallback patcher when a viewer needs PNG previews for embedded SVG.
- `scripts/figure_studio_s8_clean_delivery.py`: validates/finalizes S8-SVG-PPT self-contained delivery and removes transient intermediates when requested.
- `scripts/figure_studio_validate_production_svg.py`: validates production SVG safety.
- `scripts/figure_studio_release_check_paths.py`: scans releases for local absolute paths and cleans caches.
- `scripts/figure_studio_architecture_audit.py`: audits architecture contracts, reference links, release hygiene, and forbidden remnants.

Core Python package:

- `constants.py`: workflow steps, version, canonical outputs, artifact roles, runtime values.
- `state_schema.py`: initial state and workflow construction.
- `artifacts.py`: artifact lookup, role inference, active-index refresh, upsert, and pending-output refresh.
- `image_outputs.py`: image-generation registration and S7-FOREGROUND-IMAGE foreground-only validation.
- `state_commands.py`: CLI command implementation, cleanup, doctor, and S8-SVG-PPT readiness checks.

Design principles:

- keep workflow policy, state helpers, image gates, delivery builders, cleanup helpers, and release checks loosely coupled;
- use relative paths only in package docs, state, manifests, and generated specs;
- keep S8-SVG-PPT builder parameterized by `--reference-final` and `--no-texture-final`;
- avoid paper-specific hard-coded coordinates or local machine paths.
- avoid generated browser renderer HTML/JS in release outputs; use direct SVG/PPTX artifacts plus optional raster preview only when requested.

