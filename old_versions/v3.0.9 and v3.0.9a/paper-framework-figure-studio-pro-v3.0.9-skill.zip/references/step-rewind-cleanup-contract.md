# Step Rewind Cleanup Contract

Use one simple rule for rollback, rerun, and status jump operations:

If the target step will be executed, first delete every product created by the covered step span from `target_step` through the previous `current_step`, inclusive. Then remove the covered active state records and execute the target step.

Never delete:

- `state/project-state.json`
- `state/`
- `inputs/`
- user source files
- skill package source files

Covered state records include active artifacts, image-generation events, pending outputs, and active artifact role mappings. Keep the cleanup event itself as the audit record.

Examples:

- Current `S6-FINAL-SELECT`, rerun `S4-CANDIDATE-BRIEF`: clean old `S4-CANDIDATE-BRIEF`, `S5-CANDIDATE-IMAGE`, and `S6-FINAL-SELECT` products and active records, then execute `S4-CANDIDATE-BRIEF`.
- Current `S8-SVG-PPT`, rerun `S7-FOREGROUND-IMAGE`: clean old `S7-FOREGROUND-IMAGE` and `S8-SVG-PPT` products and active records, then execute `S7-FOREGROUND-IMAGE`.
- Current `S5-CANDIDATE-IMAGE`, rerun `S5-CANDIDATE-IMAGE`: clean old `S5-CANDIDATE-IMAGE` products and active records, then execute it again.

If the user only asks to inspect or compare historical results, no cleanup is required.


