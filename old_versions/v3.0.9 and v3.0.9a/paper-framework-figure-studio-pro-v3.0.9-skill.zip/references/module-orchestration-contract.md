# Module Orchestration Contract

Use these module references by step:

- S1-FIGURE-STRATEGY and S2-SKETCH-EXPLORE: `references/modules/s1-s2-strategy-and-sketch.md`.
- S3-DIRECTION-SELECT through S5-CANDIDATE-IMAGE: `references/modules/s3-to-s5-candidates.md`.
- S6-FINAL-SELECT: `references/modules/s6-final-selection.md`.
- S7-FOREGROUND-IMAGE through S9-FIGURE-TEXT: `references/modules/s7-s8-s9-finalization.md`.

Active workflow:

```text
S0-PAPER-FOUNDATION -> S1-FIGURE-STRATEGY -> S2-SKETCH-EXPLORE -> S3-DIRECTION-SELECT -> S4-CANDIDATE-BRIEF -> S5-CANDIDATE-IMAGE -> S6-FINAL-SELECT -> S7-FOREGROUND-IMAGE -> S8-SVG-PPT -> S9-FIGURE-TEXT
```

Global exploration steps may be divergent and reader-hook oriented. Local refinement steps must be paper-grounded. Delivery steps turn the selected reference into a foreground-only extraction source, then an editable SVG/PPT package.

Architecture and release governance are cross-cutting. Before changing module boundaries or packaging, read `references/architecture-governance-contract.md` and run `scripts/figure_studio_architecture_audit.py`.



