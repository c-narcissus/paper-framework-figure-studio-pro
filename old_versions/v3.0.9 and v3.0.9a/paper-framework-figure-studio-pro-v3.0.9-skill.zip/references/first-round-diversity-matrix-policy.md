# First-Round Diversity Matrix Policy

Use this reference when S3-DIRECTION-SELECT and S4-CANDIDATE-BRIEF prepare the first formal target-paper candidate board.

## Purpose

The first formal round must preserve real visual diversity. It should not be a set of minor style tweaks around one already-chosen composition. By default, S5-CANDIDATE-IMAGE uses a `2 directions x 3 style treatments = 6 candidates` matrix.

Local refinement now ends at S6-FINAL-SELECT final selection. S5-CANDIDATE-IMAGE should still preserve genuine first-round diversity instead of prematurely narrowing to tiny variations of one composition.

Before the formal round, S2-SKETCH-EXPLORE must provide at least 6 separate low-fidelity sketches. These sketches should be visually different at a glance and should sample different internal taxonomy angles such as subtype, layout grammar, reader role/path, density/detail level, visual communication style, and first-glance hook.

## Default Matrix

After S2-SKETCH-EXPLORE, select the active matrix's requested number of broad low-fidelity structural directions for formal exploration. The default is two directions. Prefer directions that answer the paper's reader problem in different ways, not merely different color palettes.

Each selected direction receives the active matrix's requested number of visual communication treatments. The default is three:

1. **Schematic Precision Treatment**
   - Style family: `formal architecture schematic` or `blueprint / technical drawing`, whichever better matches the direction.
   - Communication angle: topology, interfaces, routes, and technical exactness.

2. **Editorial Clarity Treatment**
   - Style family: `clean editorial flat` or `minimal line-art schematic`, whichever better matches the direction.
   - Communication angle: fast scanning, low cognitive load, and label economy.

3. **Mechanism / Evidence Treatment**
   - Style family: `mechanism snapshot`, `mini-evidence infographic`, or `premium scientific illustration`, whichever best fits the paper's contribution.
   - Communication angle: mechanism intuition, evidence link, or conceptual memorability.

## Candidate Naming

Name S5-CANDIDATE-IMAGE candidates as a matrix:

- `D1-A`: selected low-fidelity direction 1 + schematic precision treatment.
- `D1-B`: selected low-fidelity direction 1 + editorial clarity treatment.
- `D1-C`: selected low-fidelity direction 1 + mechanism/evidence treatment.
- `D2-A`: selected low-fidelity direction 2 + schematic precision treatment.
- `D2-B`: selected low-fidelity direction 2 + editorial clarity treatment.
- `D2-C`: selected low-fidelity direction 2 + mechanism/evidence treatment.

If the target paper strongly favors specific style families, keep the 2x3 structure but remap the treatments to three genuinely different visual-communication styles from the saved style taxonomy. The three treatments for the same direction must differ in visual rhetoric, density, and reader path, while preserving the same paper logic.

## Selection Rules

- Default first-round count is 6.
- S2-SKETCH-EXPLORE default and minimum count is 6 separate sketches; maximum is 8.
- Keep total first-round images <= 8.
- Select structurally different low-fidelity directions according to the active matrix; default is two.
- The 2x3 matrix is adjustable. It is the default, not a hard-coded allocation.
- S0-PAPER-FOUNDATION first reply must disclose the default matrix at the matrix-specification level: after low-fidelity sketches, the workflow normally selects 2 structural directions and assigns 3 visual communication style treatments to each direction.
- S0-PAPER-FOUNDATION first reply must also disclose that S2 low-fidelity sketches default to at least 6 separate images for visual diversity.
- The S0-PAPER-FOUNDATION disclosure must also tell the user they may change the matrix specification, for example to 3 low-fidelity directions x 2 visual communication style treatments. Do not frame this as asking the user to edit specific direction IDs or style labels one by one.
- S3-DIRECTION-SELECT/S4-CANDIDATE-BRIEF text replies should state the active matrix only: default 2x3, or the user-modified matrix such as 3x2.
- If the user changes the matrix specification, follow the user's allocation, update the S4-CANDIDATE-BRIEF brief/state, and use the modified matrix for S5-CANDIDATE-IMAGE.
- User-uploaded style references still do not propagate automatically beyond S1-FIGURE-STRATEGY. The active matrix candidates are unbiased formal explorations unless the user explicitly made a later-step style requirement.
- If fewer than two viable low-fidelity sketches exist, either ask to generate/restore low-fidelity diversity or clearly record a diversity limitation.
- If the user explicitly locks one direction before S5-CANDIDATE-IMAGE, warn that first-round diversity is narrowed; then produce treatments according to the active matrix unless the user asks to restore the default 2x3 matrix.

## S4-CANDIDATE-BRIEF Requirements

S4-CANDIDATE-BRIEF must write a first-round candidate matrix before S5-CANDIDATE-IMAGE:

- selected low-fidelity direction IDs and reasons;
- style treatments per direction according to the active matrix; default is three;
- which style-family terms from `visual-communication-styles.png` are used;
- fixed paper logic shared by all active matrix candidates;
- theme elements for each candidate and a total-coverage check across the matrix;
- figure layer / caption-legend layer / omitted-implicit layer for each candidate;
- local-detail emphasis strategy for each candidate, chosen from vector-friendly mechanisms such as magnified module detail, cutaway/section, mini-evidence, mechanism snapshot, or module-internal structure;
- vectorization-friendliness risks and constraints for each candidate, including whether it can be rebuilt from simple shapes, large separable icons, editable labels, and clean connectors;
- varied axes per treatment: layout grammar, panel rhythm, density, callout strategy, color semantics, reader path, and visual rhetoric;
- whether the candidate mirrors the draft structure or proposes a non-contradictory reorganization, with manuscript revision suggestions when useful;
- comparison rubric: choose by fit to the paper description and first-glance appeal first, then paper logic clarity, reader path, at-a-glance comprehension, label economy, layout readability, and visual polish.

S4-CANDIDATE-BRIEF must also display the matrix as an inline Markdown design-intent table in the user-facing reply. The table must compare candidate ID, author need, paper content anchor, algorithm/model reference when present, fit to paper description, figure-vs-caption split, semantic density budget, visual communication/style category, layout strategy, first-glance appeal design, at-a-glance understanding, SVG/PPT buildability, author-intent clarity, divergence/enhancement note, and main risk. Do not hide this reasoning only in `candidate-board-brief.md` or state.

If a first-round candidate intentionally improves the paper figure by reorganizing or simplifying user-provided information, write the change as a divergence/enhancement note instead of treating it as a silent assumption.

S5-CANDIDATE-IMAGE then generates the active matrix candidates and outputs only images plus a minimal next-step prompt.



