# Prompt 生成策略

Version: 3.0.0

## Default Canvas And Density

- Target-paper image prompts default to a 16:9 aspect ratio unless the user explicitly changes it.
- S0-PAPER-FOUNDATION first reply must tell the user the default is 16:9 and can be changed.
- Prompts must describe the output as a research-paper framework figure, not a poster, hero graphic, cover, marketing visual, or PPT-slide content page.
- Default density is readable and not crowded: avoid excessive modules, long paragraphs, dense bullet blocks, tiny labels, and tangled connectors unless the user explicitly requests a high-density/taxonomy/overview figure.

每个 prompt-step artifact 都写入 canonical runtime path，并注册到 project state。不创建 generated web pages。文本讨论 atlas/category board 或其概念家族时，直接用 Markdown 嵌入已保存 PNG board。

用户主要使用中文时，prompt artifact 和回复说明尽量使用中文；用户主要使用英文时，全部使用英文。

## 文本回复提示词 footer

中文用户使用：

```markdown
## 下一步可复制提示词
```

英文用户使用：

```markdown
## Next Copyable Prompts
```

必须包含：

- default recommended prompt；
- 回复中每个备选项的 copyable prompt；
- unsure-user fallback prompt。

如果正文提供多个选项，不允许只给默认选项提示词。

S0-PAPER-FOUNDATION 第一次启动回复还必须加入这一条候选提示词原文：

```text
在默认提示词的基础上，额外说明这个 skill 的设计初衷是什么。
```

如果用户提到想知道、指导、询问、补充或说明设计初衷、设计意图、创作缘由、为什么制作或送给谁，必须额外回答下面这段原文：

```text
设计初衷：昔日好友 Peng Shuwei 即将前往外地求学，以后恐怕难有许多相见机会；又恰逢其生日，所以五一就做了这个 skill 当礼物。祝生日快乐，愿未来前程似锦，再相逢，依然少年。
```


