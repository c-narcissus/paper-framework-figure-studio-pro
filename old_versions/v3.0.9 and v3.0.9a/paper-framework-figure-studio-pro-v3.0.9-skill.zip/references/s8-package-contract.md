# S8-SVG-PPT Package Contract

S8-SVG-PPT must generate a self-contained PPTX and cannot be replaced by a single new image or concept explanation.

## Inputs

- S6-FINAL-SELECT selected final reference, default `outputs/S5-candidate-images/candidate-01.png`.
- S7-FOREGROUND-IMAGE foreground-only element collection sheet(s), starting with `outputs/S7-foreground-image/rimg-no-texture-final-01.png`; read `foreground-only-manifest.json` for any additional sheets.
- SVG catalog spec, `outputs/S8-svg-ppt/_work/icon_catalog_spec.json`.

## Required Process

1. Run S8-SVG-PPT rewind cleanup if old S8-SVG-PPT outputs or records exist.
2. Build a foreground element inventory from `rimg-no-texture-final-01.png` plus any additional collection sheets listed in `foreground-only-manifest.json`.
3. Exclude connector lines, borders, arrows, arrowheads, text labels, titles, descriptions, background texture, region fills, and decorations by default.
4. Fill `icon_catalog_spec.json` with stable IDs, titles, groups, accents, and safe SVG definitions.
5. Run:

```bash
node scripts/figure_studio_s8_svg_catalog_ppt.js \
  --project-root <project_run_root> \
  --spec outputs/S8-svg-ppt/_work/icon_catalog_spec.json \
  --out outputs/S8-svg-ppt \
  --reference-final outputs/S5-candidate-images/candidate-01.png \
  --no-texture-final outputs/S7-foreground-image/rimg-no-texture-final-01.png \
  --pptx
```

6. Validate SVG safety, PPTX self-containment, and the required slide order. Do not emit generated browser renderer HTML/JS as part of the delivery.
7. Print the execution report in the reply body and provide a download/artifact link to `outputs/S8-svg-ppt/s8-svg-ppt-delivery.pptx`. In Codex/local environments, render the actual PPTX path as a Markdown file link when possible; in ChatGPT web, export/attach the PPTX artifact and show its download link. S8-SVG-PPT is not complete until this link is visible.

## PPTX

Required retained output:

```text
outputs/S8-svg-ppt/s8-svg-ppt-delivery.pptx
```

Slide order is mandatory:

1. grayscale S6-FINAL-SELECT selected final reference as the map page;
2. original S6-FINAL-SELECT selected final reference;
3. one or more pages containing movable, editable SVG icons / foreground elements grouped by semantic category.

Labels and filenames must be live PPT text. SVG media must be embedded in the PPTX package.

Completion reply must include:

- PPTX download/artifact link;
- retained output path: `outputs/S8-svg-ppt/s8-svg-ppt-delivery.pptx`;
- slide-order confirmation for the grayscale map page, original final reference page, and movable SVG icon pages;
- validation status for self-contained PPTX and safe SVG media.

Validation commands:

```bash
python scripts/figure_studio_validate_production_svg.py outputs/S8-svg-ppt/final.svg
python scripts/figure_studio_s8_clean_delivery.py validate --output-dir outputs/S8-svg-ppt
```

