# S8-SVG-PPT Strict Extraction Algorithm

1. Read `rimg-no-texture-final-01.png`.
2. Create a semantic inventory of reusable foreground elements.
3. Mark excluded structural/text/background elements with omitted reasons.
4. Write `outputs/S8-svg-ppt/_work/icon_catalog_spec.json`.
5. Generate safe standalone SVG files and a catalog PPTX with `scripts/figure_studio_s8_svg_catalog_ppt.js`.
6. Validate SVG safety and PPTX self-containment.
7. Print the report and clean transient files unless the user explicitly asks to retain SVG assets.

