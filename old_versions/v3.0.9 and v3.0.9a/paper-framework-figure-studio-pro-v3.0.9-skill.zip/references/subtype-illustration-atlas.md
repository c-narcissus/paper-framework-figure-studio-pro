# Subtype Illustration Atlas

The atlas helps S1-FIGURE-STRATEGY explain possible figure subtypes and reader effects. It is reference material, not a substitute for target-paper image generation.

Common paper-framework subtypes:

- method overview;
- architecture diagram;
- pipeline/process figure;
- agent/workflow figure;
- system/data-flow figure;
- mechanism figure;
- evidence or ablation overview;
- case walkthrough.

Use the atlas to compare visual logic, not to copy paper facts. Uploaded or atlas reference images do not automatically transfer into S5-CANDIDATE-IMAGE or S7-FOREGROUND-IMAGE unless the user explicitly promotes a style requirement.

After global exploration, local refinement proceeds through S4-CANDIDATE-BRIEF, S5-CANDIDATE-IMAGE, and S6-FINAL-SELECT. S6-FINAL-SELECT selects the final reference for S7-FOREGROUND-IMAGE foreground extraction.

