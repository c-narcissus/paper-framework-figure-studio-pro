# Example S2-SKETCH-EXPLORE IMAGE_ONLY_PLUS_PROMPT Turn

Generate default and minimum 6 rough low-fidelity direction sketches, maximum 8. Each sketch should use a distinct taxonomy/design angle such as subtype, layout grammar, reader path, density/detail, visual communication style, or first-glance hook. Uploaded style references were scoped to S1-FIGURE-STRATEGY type advice only and must not automatically bias this image batch. Keep sketches large-scale and readable: clear icons, few short labels, necessary data-flow symbols only, no dense text/formulas. After the images, include only a minimal next-step copyable prompt section and end the text reply with this exact standalone final line, with no punctuation after it: 如果不知道如何提问，请说：请使用 paper-framework-figure-studio-pro 根据当前状态判断下一步

