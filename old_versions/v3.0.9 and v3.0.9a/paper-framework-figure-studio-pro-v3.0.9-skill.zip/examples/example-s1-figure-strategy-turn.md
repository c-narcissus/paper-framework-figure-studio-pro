# Example S1-FIGURE-STRATEGY Reading Turn

```text
全流程：S0-PAPER-FOUNDATION -> S1-FIGURE-STRATEGY -> S2-SKETCH-EXPLORE -> S3-DIRECTION-SELECT -> S4-CANDIDATE-BRIEF -> S5-CANDIDATE-IMAGE -> S6-FINAL-SELECT -> S7-FOREGROUND-IMAGE -> S8-SVG-PPT -> S9-FIGURE-TEXT
当前 step：S1-FIGURE-STRATEGY
默认下一步：S2-SKETCH-EXPLORE
```

S1-FIGURE-STRATEGY diagnoses figure subtype, reader effect, global visual hooks, and which internal references informed the options. It does not generate target-paper images.

Default next prompt:

```text
请按照 paper-framework-figure-studio-pro skill 的要求，根据当前状态和已登记产物，进入 S2-SKETCH-EXPLORE，使用规定的生图路径逐张单独生成全局探索草图，重点在不同维度上发散并提高第一眼吸引力，同时不捏造论文事实。
```


