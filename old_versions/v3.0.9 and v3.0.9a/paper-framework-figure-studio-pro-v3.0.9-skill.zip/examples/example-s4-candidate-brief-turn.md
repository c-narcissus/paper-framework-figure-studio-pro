# Example S4-CANDIDATE-BRIEF Candidate Prep Turn

```text
全流程：S0-PAPER-FOUNDATION -> S1-FIGURE-STRATEGY -> S2-SKETCH-EXPLORE -> S3-DIRECTION-SELECT -> S4-CANDIDATE-BRIEF -> S5-CANDIDATE-IMAGE -> S6-FINAL-SELECT -> S7-FOREGROUND-IMAGE -> S8-SVG-PPT -> S9-FIGURE-TEXT
当前 step：S4-CANDIDATE-BRIEF
默认下一步：S5-CANDIDATE-IMAGE
```

S4-CANDIDATE-BRIEF prepares the local-refinement candidate matrix. It prints candidate design intents, paper anchors, per-candidate theme elements, total coverage, local-detail strategy, and vectorization-friendliness notes before any S5-CANDIDATE-IMAGE generation.

Default next prompt:

```text
请按照 paper-framework-figure-studio-pro skill 的要求，根据当前状态和已登记产物，进入 S5-CANDIDATE-IMAGE，按照 S4-CANDIDATE-BRIEF 候选矩阵逐张单独生成正式架构图候选；每张候选都必须不违背论文精读记录、方法语义、术语映射和箭头语义，可以采用更清楚的非违背式重组，不能生成拼接候选板或 contact sheet。
```



