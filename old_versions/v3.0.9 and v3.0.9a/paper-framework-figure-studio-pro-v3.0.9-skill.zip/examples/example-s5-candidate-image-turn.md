# Example S5-CANDIDATE-IMAGE Turn

Generate the default 6 unbiased formal first-round target-paper candidates as a 2x3 matrix: D1-A, D1-B, D1-C, D2-A, D2-B, D2-C. Uploaded style references do not automatically create preference-informed candidates. After the images, include only a minimal next-step copyable prompt section and end the text reply with this exact standalone final line, with no punctuation after it: 如果不知道如何提问，请说：请使用 paper-framework-figure-studio-pro 根据当前状态判断下一步

