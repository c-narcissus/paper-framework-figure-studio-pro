# Example S6-FINAL-SELECT Final Selection Turn

```text
全流程：S0-PAPER-FOUNDATION -> S1-FIGURE-STRATEGY -> S2-SKETCH-EXPLORE -> S3-DIRECTION-SELECT -> S4-CANDIDATE-BRIEF -> S5-CANDIDATE-IMAGE -> S6-FINAL-SELECT -> S7-FOREGROUND-IMAGE -> S8-SVG-PPT -> S9-FIGURE-TEXT
当前 step：S6-FINAL-SELECT
默认下一步：S7-FOREGROUND-IMAGE
```

S6-FINAL-SELECT reviews the S5-CANDIDATE-IMAGE candidates, rechecks the paper/source material, selects one final architecture reference, prints the selection report, and records the theme elements that S7/S8 must preserve.

Default next prompt:

```text
请按照 paper-framework-figure-studio-pro skill 的要求，根据当前状态和已登记产物，进入 S7-FOREGROUND-IMAGE，以 S6-FINAL-SELECT 选中的 S5-CANDIDATE-IMAGE 最终架构图和已记录主题元素清单为来源，生成一张或多张 foreground-only 无底纹元素集合图，至少包含 `outputs/S7-foreground-image/rimg-no-texture-final-01.png`，必要时追加 `rimg-no-texture-final-02.png` 等。它不只是去掉底纹，还必须去掉边框、外框、分区框、格线、连接线、箭头、箭头头、文字标签、标题和说明，只保留 S8-SVG-PPT 需要分割并转换为 SVG 的可复用前景图元；布局要利于 SVG 提取，尽量减少遮挡、粘连、交错、嵌套和重叠。同时保存轻量 manifest，记录来源候选图、每张集合图覆盖的主题元素、生成方式、限制说明和 S8-SVG-PPT 输入路径。
```


