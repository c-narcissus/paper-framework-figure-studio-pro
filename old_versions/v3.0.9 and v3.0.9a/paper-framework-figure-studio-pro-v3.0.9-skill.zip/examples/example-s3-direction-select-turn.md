# Example S3-DIRECTION-SELECT Sketch Review Turn

```text
全流程：S0-PAPER-FOUNDATION -> S1-FIGURE-STRATEGY -> S2-SKETCH-EXPLORE -> S3-DIRECTION-SELECT -> S4-CANDIDATE-BRIEF -> S5-CANDIDATE-IMAGE -> S6-FINAL-SELECT -> S7-FOREGROUND-IMAGE -> S8-SVG-PPT -> S9-FIGURE-TEXT
当前 step：S3-DIRECTION-SELECT
默认下一步：S4-CANDIDATE-BRIEF
```

S3-DIRECTION-SELECT reviews the global-exploration sketches and selects structure directions for formal candidates. The review should favor visual hooks and reader appeal, while recording any paper-fact risks.

Default next prompt:

```text
请按照 paper-framework-figure-studio-pro skill 的要求，根据当前状态和已登记产物，进入 S4-CANDIDATE-BRIEF，基于 S3-DIRECTION-SELECT 选定的全局探索方向和 S0-PAPER-FOUNDATION 精读记录，准备局部细化候选矩阵；该阶段必须更精准地保持论文方法、算法、模型、术语和箭头关系的语义忠实，同时允许不违背论文事实的结构重组。
```


