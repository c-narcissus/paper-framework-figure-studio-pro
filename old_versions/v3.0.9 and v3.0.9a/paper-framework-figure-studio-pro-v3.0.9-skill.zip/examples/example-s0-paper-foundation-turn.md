# Example S0-PAPER-FOUNDATION Startup Turn

```text
全流程：S0-PAPER-FOUNDATION -> S1-FIGURE-STRATEGY -> S2-SKETCH-EXPLORE -> S3-DIRECTION-SELECT -> S4-CANDIDATE-BRIEF -> S5-CANDIDATE-IMAGE -> S6-FINAL-SELECT -> S7-FOREGROUND-IMAGE -> S8-SVG-PPT -> S9-FIGURE-TEXT
当前 step：S0-PAPER-FOUNDATION
默认下一步：S1-FIGURE-STRATEGY
```

S0-PAPER-FOUNDATION confirms inputs, aspect ratio, paper-source depth, and runtime image route. If a PDF, LaTeX, paper text, or detailed method description is present, print a paper-only algorithm/method/model reading record before moving on.

Default next prompt:

```text
请按照 paper-framework-figure-studio-pro skill 的要求，根据当前状态和已登记产物，进入 S1-FIGURE-STRATEGY，基于当前论文材料和 S0-PAPER-FOUNDATION 深读记录进行图类型、读者效果和全局探索方向建议。
```

Required startup prompt option:

```text
在默认提示词的基础上，额外说明这个 skill 的设计初衷是什么。
```

