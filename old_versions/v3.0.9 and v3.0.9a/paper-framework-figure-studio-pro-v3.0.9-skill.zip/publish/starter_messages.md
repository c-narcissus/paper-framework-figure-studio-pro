# Starter Messages

- `请按照 paper-framework-figure-studio-pro skill 的要求，根据当前状态和已登记产物，判断当前 step 并继续下一步。`
- `如果不知道如何提问，请说：请使用 paper-framework-figure-studio-pro 根据当前状态判断下一步`
- `在默认提示词的基础上，额外说明这个 skill 的设计初衷是什么。`
- `请按照 paper-framework-figure-studio-pro skill 的要求，根据当前状态和已登记产物，进入 S1-FIGURE-STRATEGY，根据论文材料和 S0-PAPER-FOUNDATION 深读记录给出图类型、读者效果和全局探索方向建议。`
- `请按照 paper-framework-figure-studio-pro skill 的要求，根据当前状态和已登记产物，进入 S2-SKETCH-EXPLORE，使用规定生图路径逐张单独生成至少 6 张全局探索草图，要求从不同分类角度发散、少文字公式、图标清晰且第一眼有冲击，并遵守 vector-first minimal semantic 规则。`
- `请按照 paper-framework-figure-studio-pro skill 的要求，根据当前状态和已登记产物，进入 S5-CANDIDATE-IMAGE，按 S4-CANDIDATE-BRIEF 候选矩阵、每个候选的主题元素清单、figure-vs-caption 分工和语义密度预算逐张单独生成正式候选架构图，并考虑后续转 SVG/PPT 的可实现性。`
- `请按照 paper-framework-figure-studio-pro skill 的要求，根据当前状态和已登记产物，进入 S7-FOREGROUND-IMAGE，以 S6-FINAL-SELECT 选中的最终架构图和已记录主题元素清单为来源，生成一张或多张 foreground-only 无底纹元素集合图，并去掉边框、外框、分区框、格线、连接线、箭头、箭头头、文字、标题和说明，只保留可复用前景图元。`
- `请按照 paper-framework-figure-studio-pro skill 的要求，根据当前状态和已登记产物，进入 S8-SVG-PPT，严格执行 foreground SVG catalog 流程，从 foreground-only 元素集合图分割/重绘元素为 SVG，并生成自包含 PPTX；第一页为 S6-FINAL-SELECT 选中最终结果的灰度图作为地图，第二页为选中最终结果原图，后续页摆放可移动、可编辑 SVG 图标；完成后提供 PPTX 下载/产物链接。`


