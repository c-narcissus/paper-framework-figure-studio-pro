# Release Checklist

- [ ] Version is `3.0.9-architecture-governance`.
- [ ] Workflow is `S0-PAPER-FOUNDATION -> S1-FIGURE-STRATEGY -> S2-SKETCH-EXPLORE -> S3-DIRECTION-SELECT -> S4-CANDIDATE-BRIEF -> S5-CANDIDATE-IMAGE -> S6-FINAL-SELECT -> S7-FOREGROUND-IMAGE -> S8-SVG-PPT -> S9-FIGURE-TEXT`.
- [ ] S0-PAPER-FOUNDATION paper foundation report is rich, detailed, accurate, source-anchored, printed inline, and used as the S1-S9 foundation when paper/source material is available.
- [ ] S6-FINAL-SELECT selects the final S5-CANDIDATE-IMAGE reference and prints the selection report.
- [ ] S7-FOREGROUND-IMAGE outputs only `rimg-no-texture-final-01.png` plus `foreground-only-manifest.json`.
- [ ] S8-SVG-PPT uses `--reference-final` and `--no-texture-final`, and builds a PPTX with slide 1 as grayscale selected-final map, slide 2 as original selected final, and slide 3+ as movable/editable embedded SVG icon pages.
- [ ] S8-SVG-PPT completion reply provides a visible download/artifact link to `outputs/S8-svg-ppt/s8-svg-ppt-delivery.pptx`.
- [ ] `python scripts/figure_studio_architecture_audit.py --target . --fail-on-issue` passes.
- [ ] `python -m compileall -q scripts` passes.
- [ ] `node --check scripts/figure_studio_s8_svg_catalog_ppt.js` passes.
- [ ] JSON templates validate.
- [ ] State init/validate/doctor smoke tests pass.
- [ ] S8-SVG-PPT builder smoke test produces PPTX, manifest, SVG catalog, and report.
- [ ] Release path scanner reports no local absolute paths.
- [ ] Package zip name is `paper-framework-figure-studio-pro-v3.0.9-skill.zip`.

