- v3.0.9 uses a simplified S0-PAPER-FOUNDATION-S9-FIGURE-TEXT workflow for paper framework figures with input-depth-sensitive S0-PAPER-FOUNDATION paper reading, global exploration, local refinement, S6-FINAL-SELECT final selection, S7-FOREGROUND-IMAGE foreground-only extraction, S8-SVG-PPT foreground SVG catalog PPTX delivery with required download link and fixed slide order, architecture governance audit, environment-routed separate image generation, and covered-step rewind cleanup that preserves the state file.


