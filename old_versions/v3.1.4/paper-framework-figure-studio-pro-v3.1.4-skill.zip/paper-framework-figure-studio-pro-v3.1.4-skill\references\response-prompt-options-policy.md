# Response Prompt Options Policy

Each text reply should show the current workflow position:

```text
全流程：S0-PAPER-FOUNDATION -> S1-FIGURE-STRATEGY -> S2-SKETCH-EXPLORE -> S3-DIRECTION-SELECT -> S4-CANDIDATE-BRIEF -> S5-CANDIDATE-IMAGE -> S6-FINAL-SELECT
当前 step：<current_step>
默认下一步：<default_next_step 或 已完成>
```

The next-step prompt is copyable guidance only. It must not auto-run the next step.

When the current step is `S3-DIRECTION-SELECT`, the next-step prompt for `S4-CANDIDATE-BRIEF` must include a shared part plus two explicit branches:

- Branch A: continue the second-round reference images with hand-drawn / sketch-like character.
- Branch B: prefer reference images that are easier for a human to redraw as SVG/PPT with clean vector-approximable geometry.

Branch B is the default if the user does not choose. The branch selection must carry into S4 candidate wording and S5 image prompts.

Target-paper images must follow the environment image route. Every sketch and candidate is generated separately.

After S6, provide completion status. There is no S7 step and no post-S6 handoff prompt. If refinement is needed, provide only a prompt to return to S4, S5, or S6.
