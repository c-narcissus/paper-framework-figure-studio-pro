# S0 Paper Foundation Template

S0 initializes state and builds the factual base.

Required sections when paper/source material is available:

1. Input material inventory.
2. Problem, assumptions, and contribution summary.
3. Method/algorithm/model pipeline.
4. Module inventory: input, output, role, dependency.
5. Training and inference flow.
6. Objective/loss/equation interpretation.
7. Terminology map: paper term -> figure label -> allowed shorthand.
8. Arrow semantics table.
9. Core innovation modules and internal mechanism evidence.
10. Non-droppable core substeps.
11. Figure-relevant omissions and uncertainty.
12. S1 strategy hints.

The report anchors S1-S6. If it is missing or too shallow, repair S0 before generating images.

Default canvas is 16:9 unless the user requests another ratio.

Default S2 count is 6 sketches. Default S5 count is 6 formal candidates. S5 candidates remain generated raster images whose clean schematic geometry should be easy to approximate later with SVG/PPT primitives.
