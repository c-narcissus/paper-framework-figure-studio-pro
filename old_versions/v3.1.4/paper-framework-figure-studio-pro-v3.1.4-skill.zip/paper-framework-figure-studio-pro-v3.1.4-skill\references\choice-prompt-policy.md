# Choice Prompt Policy

Every default prompt, fallback prompt, and option prompt for Chinese users must begin with:

```text
请按照 paper-framework-figure-studio-pro skill 的要求，根据当前状态和已登记产物，
```

Each text reply must end with:

```text
如果不知道如何提问，请说：请使用 paper-framework-figure-studio-pro 根据当前状态只建议下一步提示词，不要自动执行下一步。
```

Prompts are suggestions only. They never authorize automatic execution of the next step.

Default prompt targets:

- S0-PAPER-FOUNDATION: initialize state and paper/source foundation.
- S1-FIGURE-STRATEGY: diagnose figure strategy and S2 sketch cards.
- S2-SKETCH-EXPLORE: generate separate raster exploration sketches.
- S3-DIRECTION-SELECT: choose the strongest direction.
- S4-CANDIDATE-BRIEF: prepare formal candidate contracts.
- S5-CANDIDATE-IMAGE: generate separate formal raster candidate images.
- S6-FINAL-SELECT: select the final image and write figure text.

S3-DIRECTION-SELECT special next-prompt rule: when S3 ends, the S4 prompt must contain one shared part and two branches. The shared part must preserve S3 choices, paper facts, registered artifacts, aspect ratio, and constraints while entering only S4. Branch A means the later reference figures keep hand-drawn / sketch-like character. Branch B means the later reference figures prefer clean geometry and easy manual SVG/PPT redraw. Branch B is the default if the user does not choose, and the chosen branch must affect S4 candidate contracts and S5 image prompts.

After S6, offer only completion or a rewind/refinement prompt back to S4/S5/S6.
