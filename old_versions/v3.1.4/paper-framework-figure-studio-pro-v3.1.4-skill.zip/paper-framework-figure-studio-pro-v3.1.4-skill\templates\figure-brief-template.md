# S6-FINAL-SELECT Final Selection Report Template

Use this template when S6-FINAL-SELECT selects the final architecture reference from S5-CANDIDATE-IMAGE candidates.

## Metadata

- artifact_id: s6-final-selection-report
- canonical_relative_path: outputs/S6-final-selection/final-selection-report.md
- selected_reference_final: outputs/S5-candidate-images/candidate-01.png
- default_next_step: completed

## Selected Final Reference

- Selected image:
- Candidate ID:
- Why this candidate is the final reference:
- Figure-vs-caption split:
- Core innovation module detail mode:
- Core submodule internal mechanism preserved:
- Non-droppable core substeps preserved:
- Semantic density budget:
- PPT/SVG manual reconstruction notes:
- Known limitations:

## Paper Recheck

| Check | Paper/source evidence | Candidate result | Action |
|---|---|---|---|
| Core method/algorithm/model structure |  |  | keep/fix/drop |
| Core innovation submodule internal mechanism |  |  | keep/fix/drop |
| Non-droppable core substep coverage |  |  | keep/fix/drop |
| Required modules |  |  | keep/fix/drop |
| Terminology |  |  | keep/fix/drop |
| Arrow/data/control relations |  |  | keep/fix/drop |
| Key contribution claims |  |  | keep/fix/drop |
| Figure-vs-caption split |  |  | keep/fix/drop |
| PPT/SVG manual reconstruction feasibility |  |  | keep/fix/drop |
| Density/readability for a paper figure |  |  | keep/fix/drop |

## Candidate Ranking

| Rank | Candidate | Paper fit | Core detail | First-glance appeal | 10-second comprehension | Semantic density | Reconstruction feasibility | Precision | Decision |
|---|---|---|---|---|---|---|---|---|---|
| 1 | candidate-01.png |  |  |  |  |  |  |  | select |

## Final Figure Text

- Figure title:
- Caption:
- Legend / symbol notes:
- Body-reference sentence:
- Manuscript revision note:

## Completion

S6-FINAL-SELECT complete. The workflow is complete.
