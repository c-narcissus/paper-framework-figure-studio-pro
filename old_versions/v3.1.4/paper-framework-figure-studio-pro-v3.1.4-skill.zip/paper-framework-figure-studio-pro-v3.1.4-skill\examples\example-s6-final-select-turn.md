# Example: S6-FINAL-SELECT

Run only S6. Select the final S5 candidate, show the selected path/image, provide the selection report, and write the figure title, caption, legend, body-reference text, and manuscript note. The workflow is complete after S6.
