# Prompt Template

All default prompts, option prompts, and fallback prompts must begin with the skill prefix for Chinese users:

```text
请按照 paper-framework-figure-studio-pro skill 的要求，根据当前状态和已登记产物，
```

Every text reply must end with this exact standalone line:

```text
如果不知道如何提问，请说：请使用 paper-framework-figure-studio-pro 根据当前状态只建议下一步提示词，不要自动执行下一步。
```

## S2-SKETCH-EXPLORE Image Prompt

Generate low-fidelity global-exploration sketches for the target paper framework figure. Use the environment image route: Image Gen in Codex, Create Image / ChatGPT Images 2.0 in ChatGPT web, or another approved image API only if neither is available. Generate each sketch as a separate image call and save/register it separately.

Hard modality gate: every S2 sketch must be a generated raster image file (`.png`, `.jpg`, `.jpeg`, or `.webp`). Do not output SVG code, vector diagrams, HTML, Mermaid, canvas, PPT/PPTX shapes, PDF, or prompt-only placeholders as sketches. "PPT/SVG-ready" means the generated raster sketch is easy to rebuild later; it does not permit drawing the sketch directly as SVG.

Default canvas aspect ratio is 16:9 unless changed by the user. Default and minimum count is 6 diverse sketches; maximum is 8. Keep the sketches broad and eye-catching across different reader hooks, visual metaphors, layout grammars, reader paths, density/detail levels, visual communication styles, and first-glance emphasis. They may be more divergent than later steps, but they must not invent paper facts.

Use the paper reading to distill the big framework, not to draw every paper detail. Use large clear icons, module silhouettes, rough grouping, simple data-flow symbols, and at most short module/step titles. Avoid dense labels, long text, many formulas, tiny icons, and tangled connectors.

Hard gate: if the preceding S1 output does not contain complete S2 candidate cards with `candidate_id`, `figure_title`, `pre_image_explanation_draft`, `symbol_visual_legend`, `in_image_text_budget`, `caption_support_note`, and `reader_understanding_test` for every planned sketch, stop before writing prompts or generating images and repair S1 first.

After the images, print only a compact candidate-ID/filename list, the S3 next-step prompt, and the unsure-user fallback. Do not execute S3 in the same reply.

## S5-CANDIDATE-IMAGE Prompt

Generate formal paper-framework candidates for local refinement. Use the environment image route and generate every candidate separately. Do not create a contact sheet or stitched candidate board.

Hard modality gate: every S5 candidate must be a generated raster image file (`.png`, `.jpg`, `.jpeg`, or `.webp`). Do not output SVG code, vector diagrams, HTML, Mermaid, canvas, PPT/PPTX shapes, PDF, or prompt-only placeholders as candidates. The S6 selected final reference must be one of these generated raster image candidates.

Default canvas aspect ratio is 16:9 unless changed by the user. Default count is 6 candidates as a `2 selected directions x 3 visual communication treatments` matrix unless the user changed the matrix.

All default S5 formal candidates should be generated raster images in a clean publication-ready schematic style. Use stable modular geometry, consistent stroke weights, clear module bodies, clean connector grammar, restrained color coding, separable icons, short labels, and predictable reading order. They should look like serious research-paper diagram references that a human can later approximate with SVG/PPT primitives. Do not generate SVG in S5.

Do not use hand-drawn, whiteboard, paper-sketch, sketch-note, comic, sticky-note, or storyboard rendering as the default S5 style. A plain-language story-like candidate may appear only when the user explicitly requests it or S4 records it as an intentional optional candidate; even then it should be a clean schematic raster candidate, not a decorative cartoon or SVG output.

Keep paper meaning fixed across all candidates, but do not mechanically mirror the manuscript draft's current organization. Vary visual grammar, focal hierarchy, panel rhythm, label density, local-detail display, style treatment, callout strategy, reader path, and non-contradictory organization.

Design with later manual SVG/PPT approximation in mind: prefer separable icons, module cards, swimlanes, panel groups, clean insets, short editable-looking labels, and controlled data-flow relations. Avoid painterly textures, photo-realism, complex translucency, tiny decorative details, elaborate backgrounds, exaggerated cartoon rendering, wobbly strokes, and fused shapes.

Every S5 prompt must include the S4 `image_core_step_visibility_plan`. Name the visual carrier for each image-required core step, for example a three-token mini-chain inside a module, a connected inset, a small loop, or a mechanism panel. If S4 lacks `image_required_core_steps` or `image_core_step_visibility_plan`, stop and repair S4 before generating images.

After the images, print only a compact candidate-ID/filename list, the S6 next-step prompt, and the unsure-user fallback. Do not execute S6-FINAL-SELECT in the same reply.

## S6-FINAL-SELECT Terminal Prompt

Use only after S5-CANDIDATE-IMAGE has generated and registered the formal raster candidates.

S6-FINAL-SELECT is the terminal workflow step. After S6 the workflow is complete. There is no S7 step. It must not print or execute any post-S6 or S7 handoff prompt.

Required S6 output:

1. Review all S5 candidates as bundles: S4 contract plus generated image.
2. Recheck the paper foundation report and highest-quality paper/source material for terminology, modules, arrow relations, method constraints, core contributions, and non-contradictory reorganization.
3. Rank candidates with explicit reasons, including paper fidelity, core-submodule detail visibility, image-required core-step coverage, readability, figure-vs-caption split, stable focal hierarchy, target-size readability, and ease of later SVG/PPT approximation.
4. Select one final S5 raster candidate as the final figure reference and provide its project-relative path.
5. Display the selected final image when the runtime supports local image display; the final selected image must be visible in the S6 response or explicitly unavailable with reason.
6. Provide final figure text: title, caption, legend/symbol notes, and body-reference sentence(s).
7. Provide manuscript revision suggestions when the selected figure uses a clearer organization than the draft paper text.
8. Mark `S6-FINAL-SELECT complete`; default next step is `已完成`; do not provide a next-step prompt except instructions to return to S4/S5/S6 for explicit refinement.
