# Workflow And State Contract

The workflow is fixed:

```text
S0-PAPER-FOUNDATION -> S1-FIGURE-STRATEGY -> S2-SKETCH-EXPLORE -> S3-DIRECTION-SELECT -> S4-CANDIDATE-BRIEF -> S5-CANDIDATE-IMAGE -> S6-FINAL-SELECT
```

Phase semantics:

- Foundation: `S0-PAPER-FOUNDATION`.
- Global exploration: `S1-FIGURE-STRATEGY -> S2-SKETCH-EXPLORE -> S3-DIRECTION-SELECT`.
- Local refinement and finalization: `S4-CANDIDATE-BRIEF -> S5-CANDIDATE-IMAGE -> S6-FINAL-SELECT`.

Default next-step table:

| Step | Default next |
|---|---|
| S0-PAPER-FOUNDATION | S1-FIGURE-STRATEGY |
| S1-FIGURE-STRATEGY | S2-SKETCH-EXPLORE |
| S2-SKETCH-EXPLORE | S3-DIRECTION-SELECT |
| S3-DIRECTION-SELECT | S4-CANDIDATE-BRIEF |
| S4-CANDIDATE-BRIEF | S5-CANDIDATE-IMAGE |
| S5-CANDIDATE-IMAGE | S6-FINAL-SELECT |
| S6-FINAL-SELECT | done |

`S6-FINAL-SELECT` is the final workflow step. After S6, the workflow is done. There is no S7 step, and agents must not propose, invent, or execute any post-S6/S7 delivery step.

S2 sketches, S5 candidates, and the S6 selected final reference are target-paper image artifacts. They must be generated raster images (`.png`, `.jpg`, `.jpeg`, or `.webp`) produced by Image Gen, ChatGPT Create Image, or another approved image-generation API.

SVG/HTML/Mermaid/canvas/PPT/PDF/code-drawn substitutes are invalid for those target-image roles. "Easy to approximate with SVG/PPT primitives" is a design constraint on the generated image, not a change in output modality.

S6-FINAL-SELECT is terminal. It must select one final S5 raster candidate, provide the selected final image path and display it when the runtime supports local image display, then write the final figure title, caption, legend, body-reference text, and manuscript note.
