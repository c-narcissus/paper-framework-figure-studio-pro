# Review Rubric

Evaluate S2/S5/S6 outputs against:

- paper fidelity and source-grounded terminology;
- required module coverage;
- correct data/control/causal arrow semantics;
- visible core innovation mechanism when evidence exists;
- non-droppable core substep coverage;
- readable density at target size;
- figure-vs-caption split;
- first-glance appeal and 10-second comprehension;
- clean schematic geometry that is easy to approximate later with SVG/PPT primitives;
- avoidance of poster/PPT-slide content dumping.

S6 must select one S5 raster candidate and provide title, caption, legend, body-reference text, and manuscript note.
