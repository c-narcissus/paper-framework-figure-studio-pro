# Visual Style And Board Protocol

S2 may be exploratory and visually varied. S5 should be formal, paper-grounded, and clean.

Second-round/formal candidate style:

- still generate raster images;
- use regular publication schematic composition;
- use stable modular geometry, clear connectors, restrained color, short labels, and separable icons;
- make the result easier for a human to approximate later using SVG/PPT primitives.

Avoid default hand-drawn, whiteboard, sketch-note, comic, sticky-note, painterly, photorealistic, texture-heavy, poster-like, or dense PPT-slide aesthetics for S5.

Vectorization-aware is an output-design constraint, not an output-modality change. S5 candidates and the S6 selected final reference must be generated raster images.

Default density budget: 3-6 main modules, one dominant data/control flow, 0-3 secondary flows, usually no formulas and at most 1-2 essential formulas, short module labels only, and landmark icons rather than many small dictionary icons. If a detail is scientifically important but visually expensive, move it to S6 caption/legend/body text instead of forcing it into the image.
