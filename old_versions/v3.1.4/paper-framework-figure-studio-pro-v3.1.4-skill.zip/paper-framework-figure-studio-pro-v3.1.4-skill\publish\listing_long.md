# paper-framework-figure-studio-pro v3.1.4

Publication-oriented framework-figure workflow for computer-science papers.

Core route:

```text
S0-PAPER-FOUNDATION -> S1-FIGURE-STRATEGY -> S2-SKETCH-EXPLORE -> S3-DIRECTION-SELECT -> S4-CANDIDATE-BRIEF -> S5-CANDIDATE-IMAGE -> S6-FINAL-SELECT
```

Highlights:

- Strict human-in-the-loop alternation: one user turn executes at most one explicitly requested workflow step, then stops.
- The initial bootstrap gate prevents accidental S0 execution.
- S2 generates 6-8 broad low-fidelity sketches.
- S3 completion offers two S4 prompt branches: preserve hand-drawn reference-image character, or default to cleaner reference images that are easier for a human to redraw as SVG/PPT.
- S4 prepares per-candidate figure title, explanation, legend, text budget, and visible core-step plans before S5.
- S5 formal candidates default to clean publication schematic raster images, not hand-drawn or storyboard style. They should remain images while using geometry that is easy to approximate later with SVG/PPT primitives.
- S6 is terminal: it selects the final S5 candidate and provides the figure title, caption, legend, body-reference text, and manuscript note.
- Rewind/rerun cleanup deletes covered-step products while preserving the state file and cleanup audit event.
