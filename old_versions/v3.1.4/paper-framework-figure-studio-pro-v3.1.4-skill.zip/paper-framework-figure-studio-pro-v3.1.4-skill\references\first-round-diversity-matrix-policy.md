# Formal Candidate Diversity Matrix Policy

S4-CANDIDATE-BRIEF prepares the S5 formal candidate matrix. The default is 6 candidates arranged as `2 selected directions x 3 visual communication treatments`; the user may change the matrix, but the total must not exceed 8.

S5 candidates are generated raster images. They should be formal, clean, paper-grounded schematic references whose geometry is easy to approximate later with SVG/PPT primitives.

Default treatments should vary:

- visual grammar and reading path;
- module grouping and focal hierarchy;
- local-detail display strategy;
- callout or inset strategy;
- semantic density and label budget;
- paper reorganization hypothesis and manuscript note.

Do not make the default difference mainly about hand-drawn versus polished rendering. Do not require a hand-drawn or story candidate by default.

If the user explicitly asks for a metaphorical or story-like candidate, S4 may include one optional plain-language candidate. It still must preserve paper entities, module relations, symbols, and non-droppable core steps, and it should remain clean enough to approximate later with vector primitives.

S4 must display the matrix as an inline Markdown design-intent table before image generation. The table must compare candidate ID, author need, paper content anchor, figure-vs-caption split, semantic density budget, visual communication style, layout strategy, first-glance appeal, at-a-glance understanding, approximation feasibility, divergence/enhancement note, and main risk.
