# Changelog

## 3.1.4

- Promoted the v3.1.3 package to version 3.1.4.
- Shortened the active workflow to S0-PAPER-FOUNDATION through terminal S6-FINAL-SELECT.
- Moved final figure text into S6-FINAL-SELECT: title, caption, legend, body-reference text, and manuscript note.
- Clarified that S6-FINAL-SELECT must output the final selected image path/display and that the workflow ends there with no S7 step.
- Changed S5 formal candidate defaults from hand-drawn/sketch-note/storyboard to clean publication schematic raster references that are easier to approximate later with SVG/PPT primitives.
- Added an in-place S3 exit prompt rule while keeping version `3.1.4`: after S3, the S4 next prompt must include a shared section plus two branches, hand-drawn continuity or default SVG/PPT-approximable refinement, and the selected branch must affect S4/S5 text and image plans.
- Removed post-S6 delivery scripts, templates, and prompt handoffs from the active package.
