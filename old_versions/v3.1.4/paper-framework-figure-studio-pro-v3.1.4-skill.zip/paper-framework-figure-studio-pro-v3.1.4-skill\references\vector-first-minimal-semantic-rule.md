# Vector-First Minimal Semantic Rule

Use this rule whenever S1-S6 decide what a research-paper framework figure should show.

Vector-first does not mean the workflow outputs SVG at S2 or S5. S2/S5 output generated raster images. Vector-first means the raster image is organized with simple, separable, clean geometry so a human can later approximate it with SVG/PPT primitives.

Default figure shape:

- one clear visual sentence;
- 3-6 main modules;
- one dominant flow and 0-3 secondary flows;
- few large landmark icons;
- short labels;
- usually no formulas unless one or two symbols are essential mechanism anchors.

Minimal does not permit deleting non-droppable core substeps. If the source-grounded method depends on a sequence such as train -> generate, filter -> use, score -> weight, or evaluate -> update, S5 formal candidates must preserve that sequence in the generated image body, connected inset, zoom/cutaway, or compact mechanism panel. Captions may explain visible steps, but they must not be the only carrier.

S6 absorbs important details removed from the pixels into title, caption, legend, body-reference text, and manuscript note.
