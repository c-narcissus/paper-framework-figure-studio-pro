# Figure Caption Co-Design Policy

Candidates are planned as bundles:

```text
pre-image candidate introduction + generated raster candidate image
```

S1 must introduce every planned S2 sketch candidate before image generation. S4 must introduce every planned S5 formal candidate before image generation.

Required S2 fields:

- candidate_id
- figure_title
- pre_image_explanation_draft
- symbol_visual_legend
- in_image_text_budget
- caption_support_note
- reader_understanding_test

Required S5 fields:

- candidate_id
- figure_title
- figure_sentence
- pre_image_explanation
- symbol_visual_legend
- in_image_text_budget
- visible_math_symbols_or_simple_formulas
- kept_out_of_image
- reader_understanding_test
- caption_risk_or_missing_context
- image_required_core_steps
- image_core_step_visibility_plan

The title, explanation, legend, method prose, and symbol definitions normally stay outside image pixels. The image should carry the cognitive map; S6 figure text carries definitions, caveats, equation meanings, and long explanations.

For S5 formal candidates, caption/legend text cannot be the only carrier of a non-droppable core algorithm step. If a step is required to understand the paper contribution, it must appear in the image body, a connected inset, zoom/cutaway, compact mechanism panel, or another visible carrier. The caption may explain the visible step, but it may not replace it.

S5 defaults to clean publication schematic raster references. These are images, not SVGs; they should simply be easy to approximate later with SVG/PPT primitives.

S6-FINAL-SELECT finalizes the selected bundle into final figure title, caption, legend, body-reference text, and manuscript note.
