# S6 Final Selection Module

S6-FINAL-SELECT is terminal. After this step the workflow is complete. There is no S7 step and no post-S6 handoff.

Inputs:

- S5 candidate image paths;
- S4 candidate contracts;
- S0 paper foundation report and highest-quality source material;
- any S3 direction-selection criteria.

S6 must:

1. Rank the S5 candidate bundles.
2. Recheck paper terminology, modules, arrows, constraints, contribution claims, and core mechanism visibility.
3. Select one S5 raster candidate as the final image.
4. Provide the selected final image path and display the selected final image when the runtime supports local image display.
5. Provide final figure title, caption, legend/symbol notes, body-reference sentence, and manuscript revision note.
6. Mark `S6-FINAL-SELECT complete` and default next step `done` / `完成`.

If the final result is not acceptable, recommend returning to S4, S5, or S6 for refinement. Do not offer a post-S6 workflow step, and never offer S7.
