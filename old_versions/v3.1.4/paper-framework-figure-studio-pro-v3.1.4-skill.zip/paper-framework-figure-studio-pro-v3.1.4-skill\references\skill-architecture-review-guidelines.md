# Skill Architecture Review Guidelines

Review architecture changes against these checks:

- Workflow constants, state schema, artifact roles, image generation gates, cleanup helpers, and release checks remain separate.
- S0-S6 is the only active step sequence.
- S2/S5 target images remain generated raster images.
- S5 formal candidates are schematic raster references that are easy to approximate later with SVG/PPT primitives; they are not SVG outputs.
- S6 is terminal and includes final image selection plus figure text.
- State files store relative paths only.
- Release packages contain no caches, temporary test outputs, or host-specific absolute paths.
