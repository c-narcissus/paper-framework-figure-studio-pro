# Persistent State Contract

The project state is the source of truth for the S0-PAPER-FOUNDATION to S6-FINAL-SELECT workflow.

Required top-level state groups include workflow plan, step runs, artifact role registry, active artifact roles, artifacts, pending outputs, runtime environment, user preference status, image generation events, cleanup policy, and S6 terminal output policy.

The active step sequence is:

```text
S0-PAPER-FOUNDATION -> S1-FIGURE-STRATEGY -> S2-SKETCH-EXPLORE -> S3-DIRECTION-SELECT -> S4-CANDIDATE-BRIEF -> S5-CANDIDATE-IMAGE -> S6-FINAL-SELECT
```

Canonical artifact roles:

- `s0.paper_foundation_report`
- `s1.figure_strategy`
- `s2.primary_sketch`
- `s3.direction_selection`
- `s4.candidate_brief`
- `s5.primary_candidate`
- `s6.final_selection`
- `s6.selected_reference_final`
- `s6.figure_text`

S6 is complete only when the selected final S5 raster candidate is recorded and the final-selection report includes title, caption, legend, body-reference text, and manuscript note.

State validation must reject path traversal, local absolute paths in state fields, non-raster target-paper image substitutes for S2/S5/S6 selected reference roles, and secret-like keys.
