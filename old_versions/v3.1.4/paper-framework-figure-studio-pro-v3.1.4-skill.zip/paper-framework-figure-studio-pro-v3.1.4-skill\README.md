# Paper Framework Figure Studio Pro v3.1.4

`paper-framework-figure-studio-pro` is a human-in-the-loop skill for making research-paper framework, architecture, pipeline, mechanism, and method-overview figures.

v3.1.4 promotes the v3.1.3 workflow to a shorter terminal flow:

```text
S0-PAPER-FOUNDATION -> S1-FIGURE-STRATEGY -> S2-SKETCH-EXPLORE -> S3-DIRECTION-SELECT -> S4-CANDIDATE-BRIEF -> S5-CANDIDATE-IMAGE -> S6-FINAL-SELECT
```

## Main Changes

- S6-FINAL-SELECT is now the terminal step. After S6 the workflow is complete.
- There is no S7 step. Do not propose, invent, or execute S7.
- S6 must provide the final selected image path/display plus figure title, caption, legend, body-reference text, and manuscript revision note.
- The former post-S6 delivery branch has been removed from the active workflow.
- S5 formal candidates now default to clean publication schematic raster references, not hand-drawn whiteboard or sketch-note style. They are still generated images; the composition should merely be easier to approximate later with SVG/PPT primitives.
- S3 completion must offer two S4 prompt branches outside the shared prompt body: keep hand-drawn reference-image character, or default to cleaner SVG/PPT-approximable reference images.
- If additional refinement is needed after S6, return to S4/S5/S6 and regenerate candidates instead of moving to a later delivery step.

## Step List

| Step | Type | Purpose |
|---|---|---|
| S0-PAPER-FOUNDATION | TEXT_ONLY | Build project state and the paper/source foundation. |
| S1-FIGURE-STRATEGY | TEXT_ONLY | Diagnose the reader question, figure role, and candidate directions. |
| S2-SKETCH-EXPLORE | IMAGE_ONLY_PLUS_PROMPT | Generate 6-8 broad low-fidelity sketches. |
| S3-DIRECTION-SELECT | TEXT_ONLY | Select the strongest direction for local refinement. |
| S4-CANDIDATE-BRIEF | TEXT_ONLY | Prepare formal candidate briefs, prompts, caption split, and visible core-step plans. |
| S5-CANDIDATE-IMAGE | IMAGE_ONLY_PLUS_PROMPT | Generate formal paper-framework raster candidates in clean schematic style, easy to approximate later with SVG/PPT primitives. |
| S6-FINAL-SELECT | TEXT_ONLY | Select the final image and provide figure text. |

## Operating Rules

- Execute only one explicitly requested step per user turn.
- Do not auto-run S0 from a first high-level request; first provide a copyable S0 prompt.
- S2 and S5 target images must be raster outputs generated through the configured image route.
- At S3 completion, the next S4 prompt must offer the hand-drawn-continuity branch and the SVG/PPT-approximable branch; the SVG/PPT-approximable branch is the default.
- S5 candidates should be clean, formal raster images whose modules, connectors, labels, and icons are easy to approximate later with SVG/PPT primitives unless the S3 hand-drawn-continuity branch was explicitly selected.
- S6 is complete only when it includes the final selected image path/display and the figure text package. After that, the default next step is `完成`.

## Usage Prompt

```text
请按照 paper-framework-figure-studio-pro skill 的要求，根据当前状态和已登记产物，进入 S0-PAPER-FOUNDATION。建立项目状态，确认运行环境、输入材料、画幅和默认候选数量；如果输入包含 PDF/LaTeX/完整论文文本/详细方法说明，请只基于允许的论文材料生成并打印 paper-foundation-report.md。不要生成目标论文图片。完成 S0 后停止，并只提供进入 S1-FIGURE-STRATEGY 的可复制提示词。
```
