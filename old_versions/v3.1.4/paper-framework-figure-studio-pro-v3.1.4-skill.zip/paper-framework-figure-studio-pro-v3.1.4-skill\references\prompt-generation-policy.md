# Prompt Generation Policy

S2 and S5 image prompts must be grounded in the preceding text-step candidate contracts.

S2 prompts:

- generate separate raster sketches;
- explore broad reader hooks and layout grammars;
- use sparse text and simple symbols;
- avoid inventing paper facts.

S5 prompts:

- generate separate formal raster candidates;
- default to clean publication schematic image references;
- keep modules, connectors, labels, and icons separable enough for later SVG/PPT approximation;
- avoid default hand-drawn, whiteboard, sketch-note, comic, decorative cartoon, painterly, photorealistic, or poster-like rendering;
- include the `image_core_step_visibility_plan`.

Hard gate: do not enter S2 without complete S1 sketch cards. Do not enter S5 without complete S4 formal candidate contracts.

Prompt-only manifests are not a substitute for generated raster images.
