# Release Checklist

- [ ] Version is `3.1.4`.
- [ ] Workflow is `S0-PAPER-FOUNDATION -> S1-FIGURE-STRATEGY -> S2-SKETCH-EXPLORE -> S3-DIRECTION-SELECT -> S4-CANDIDATE-BRIEF -> S5-CANDIDATE-IMAGE -> S6-FINAL-SELECT`.
- [ ] Strict human-in-the-loop alternation is enforced.
- [ ] Initial bootstrap gate is enforced.
- [ ] S0 paper-foundation behavior is input-depth-sensitive.
- [ ] S2 generates 6-8 raster exploration sketches.
- [ ] S4 provides complete candidate text contracts before S5.
- [ ] S5 defaults to formal clean publication schematic raster candidates that are easier to approximate later with SVG/PPT primitives.
- [ ] S6 selects one final S5 image and provides title, caption, legend, body-reference text, and manuscript note.
- [ ] `python scripts/figure_studio_architecture_audit.py --target . --fail-on-issue` passes.
- [ ] `python -m compileall -q scripts` passes.
- [ ] JSON templates validate.
- [ ] State init/validate/doctor smoke tests pass.
- [ ] Release path scanner reports no local absolute paths.
- [ ] Package zip name is `paper-framework-figure-studio-pro-v3.1.4-skill.zip`.
