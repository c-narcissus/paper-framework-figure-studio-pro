# S1-S2 Strategy And Sketch Module

S1 diagnoses figure strategy and prepares S2 sketch cards.

S1 must include:

- reader question;
- figure role;
- candidate visual directions;
- paper-content anchors;
- core innovation modules and non-droppable core substeps;
- per-sketch candidate cards with title, explanation, legend, text budget, caption support note, and reader understanding test.

S2 generates 6-8 separate low-fidelity raster sketches. The sketches may be divergent and reader-hook oriented, but they must not invent paper facts.

Hard raster gate for S2: every sketch must be generated through Image Gen, ChatGPT Create Image, or another approved image-generation API and accepted as `.png`, `.jpg`, `.jpeg`, or `.webp`. SVG/HTML/Mermaid/canvas/PPT/PDF/code-drawn sketches are invalid.

S2 should use large icons, rough module groups, simple data-flow marks, sparse labels, and clear first-glance hooks.

Do not execute S3 in the same reply.
