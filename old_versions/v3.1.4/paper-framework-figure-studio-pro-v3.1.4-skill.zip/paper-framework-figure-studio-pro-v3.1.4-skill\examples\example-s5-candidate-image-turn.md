# Example: S5-CANDIDATE-IMAGE

Run only S5. Generate formal raster candidates in clean publication schematic style, with geometry easy to approximate later using SVG/PPT primitives. Stop with the S6-FINAL-SELECT prompt.
