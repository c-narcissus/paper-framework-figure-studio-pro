# S3 To S5 Candidate Module v3.2.15f

S3 must first review and aggregate S2 sketches, then select direction.

S3 responsibilities:

- inspect registered S2 images;
- record issue-ledger and visual-signal summaries;
- accept optional user-named preferred S2 candidate IDs as preference signals, while still selecting by evidence and contract compliance;
- record explicit `user_preferred_first_round_candidate_ids` when the S3 prompt names preferred first-round candidates;
- transfer useful/risky S2 findings to S4, including excessive whitespace, fragmented microblock scatter, off-center mainline, top-heavy context panel, and context-area-overrun issues from `references/layout-density-mainline-balance-policy-v3215f.md`;
- choose the refinement direction;
- when closing with the S4 prompt, include the full non-copyable second-round surface-style reminder outside the copyable prompt.

S3 preference signals are weighted signals, not unconditional final selections. If S3 does not select a user-preferred candidate or does not use it as a leading ingredient, S3 must record why.

S4 is the formal candidate brief stage and prepares all S5 prompt packages before closing.

S4 must prepare:

- formal candidate matrix with exactly two prompt-package rows mapped to `F01` and `F02`;
- S2 issue transfer and negative constraints;
- formal layout/routing/arrow contracts with `edge_support_ledger`;
- connector multiplicity/bundling audit;
- visible text whitelist;
- line-carried variable registry and edge-label-first variable placement;
- modularity-not-fragmentation gate;
- simple reviewer-recognizable internal visual motif plan;
- human palette contract with `palette_strategy`, `palette_semantic_mapping`, `palette_anti_ai_artifact_rules`, `human_aesthetic_rationale`, and `color_accessibility_note`;
- redundancy/background-context budget gates;
- layout density, canvas area, context inset, and mainline center-of-gravity gates from `references/layout-density-mainline-balance-policy-v3215f.md`;
- prompt contradiction audit plus a maximum 5-cycle audit/repair log;
- data consumer/transformer ledger plus false relay data-flow audit;
- preference-led second-round coverage when S3 recorded preferred first-round candidates, fitted within the two-candidate S5 budget;
- optional ACM/IEEE/AAAI second-round line-art surface-style injection/override when the S4 or S5 user prompt explicitly requests it, following `references/acm-ieee-aaai-line-art-schematic-style-policy-v3215c.md`;
- no S4-to-S5 surface-style reminder; S4 closes with the S5 image-only prompt only;
- `outputs/S5-candidate-image/prompt-index.json`;
- candidate/artifact ID coherence: every S5 prompt-index row must preserve the same `candidate_id` across `prompt_path`, `target_image_path`, registry keys, artifacts, status files, and checkpoint inventories. Default formal IDs are `F01` and `F02`.

## Preference-Led Second-Round Coverage

If S3 recorded explicit user-preferred first-round candidate IDs, S4 must include preference-led local-essence candidates when feasible inside the two-row S5 matrix.

The required count is dynamic:

```text
required_preference_rows = len(preferred_source_ids) x len(style_slots)
```

If the coverage requirement exceeds two rows, S4 must stop at a text checkpoint and repair/replan, narrow the active style slots, or ask the user for a trade-off instead of silently dropping coverage or creating a third scheme. The workflow must not hard-code preferred IDs, style counts, or paper-specific image counts; the two-candidate cap is the public workflow maximum.

Each preference-led S5 prompt must bind:

- `source_first_round_candidate_id`;
- `style_id`;
- `preference_coverage_role = preferred_first_round_local_essence_lead`.

It must state that the source candidate is a visual preference signal only. It must preserve useful local visual essence while repairing S3 issue-ledger problems and preserving source-grounded paper semantics.

S5 is image generation only and terminal. It reads the S4-prepared prompt-index, generates exactly two images for `F01` and `F02`, applies an explicit compatible surface-style override such as `acm_ieee_aaai_line_art_schematic` only when recorded in S4 artifacts or stated in the current S5 image-only prompt, maps generated images by exact prompt-index row order, mirrors each image to the same row `target_image_path`, generates formal candidates through the approved image route, and then assistant workflow ends.

S4 image prompts must explicitly include the strict hard-constraint block from `references/strict-source-grounded-modular-prompt-contract-policy-v3215a.md`: source-supported arrows only, one bundled connector unless distinct labeled transfers are supported, variables on lines/ports/tags, modular not fragmented, simple internal motifs, no duplicate workflow or redundant inset, small background context, compact-balanced manuscript density, no empty quadrants, no top-heavy context panels, and centered mainline visual focus.

S4/S5 palette work must follow `references/style-combination-selection-and-human-palette-policy-v3215d.md`: use restrained publication-grade palettes with paper-supported color semantics, grayscale legibility, accessible contrast, and no generic AI-blue/purple gradients, neon saturation, glossy orb/glass effects, bokeh, marketing-poster lighting, or decorative rainbow ramps.
