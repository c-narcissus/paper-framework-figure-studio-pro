# Workflow And State Contract

## Step Order

```text
S0-PAPER-FOUNDATION -> S1-FIGURE-STRATEGY -> S2-SKETCH-EXPLORE -> S3-DIRECTION-SELECT -> S4-CANDIDATE-BRIEF -> S5-CANDIDATE-IMAGE -> S6-FINAL-SELECT -> S7-FOREGROUND-IMAGE -> S8-SVG-PPT -> S9-FIGURE-TEXT
```

Older second-pass optimization steps are removed. More optimization is handled by rewinding to S4-CANDIDATE-BRIEF, S5-CANDIDATE-IMAGE, or S6-FINAL-SELECT.

## Process Groups

- Global exploration: `S1-FIGURE-STRATEGY -> S2-SKETCH-EXPLORE -> S3-DIRECTION-SELECT`. Explore divergent visual hooks, first-glance appeal, and different ways to make the paper framework immediately interesting. S2-SKETCH-EXPLORE defaults to at least 6 separate low-fidelity sketches, each from a genuinely different taxonomy/design angle.
- Local refinement: `S4-CANDIDATE-BRIEF -> S5-CANDIDATE-IMAGE -> S6-FINAL-SELECT`. Use the paper and S0 `paper-foundation-report.md` closely; optimize for faithful method/model/algorithm meaning, terminology mapping, module relations, and arrow semantics. Do not mechanically mirror the draft's current section/module/algorithm-step divisions when a clearer non-contradictory figure organization would better communicate the work.
- Delivery: `S7-FOREGROUND-IMAGE -> S8-SVG-PPT -> S9-FIGURE-TEXT`. Extract foreground-only elements from the S6-FINAL-SELECT selected final reference, build SVG catalog PPTX, then write figure text.

## Default Transitions

| Current | Next |
|---|---|
| S0-PAPER-FOUNDATION | S1-FIGURE-STRATEGY |
| S1-FIGURE-STRATEGY | S2-SKETCH-EXPLORE |
| S2-SKETCH-EXPLORE | S3-DIRECTION-SELECT |
| S3-DIRECTION-SELECT | S4-CANDIDATE-BRIEF |
| S4-CANDIDATE-BRIEF | S5-CANDIDATE-IMAGE |
| S5-CANDIDATE-IMAGE | S6-FINAL-SELECT |
| S6-FINAL-SELECT | S7-FOREGROUND-IMAGE |
| S7-FOREGROUND-IMAGE | S8-SVG-PPT |
| S8-SVG-PPT | S9-FIGURE-TEXT |
| S9-FIGURE-TEXT | done |

## S6-FINAL-SELECT Final Selection

S6-FINAL-SELECT must select one S5-CANDIDATE-IMAGE candidate as the final architecture reference. Its report must include:

- selected image path;
- selection rationale;
- paper deep-reading recheck;
- terminology/module/arrow/model relation check;
- divergence/enhancement notes, reorganization rationale, manuscript revision suggestions, and confirmation status;
- S7-FOREGROUND-IMAGE handoff prompt.

## S7-FOREGROUND-IMAGE Foreground-Only Extraction

S7-FOREGROUND-IMAGE writes:

```text
outputs/S7-foreground-image/rimg-no-texture-final-01.png
outputs/S7-foreground-image/foreground-only-manifest.json
```

It no longer generates background texture images, glyph sheets, textured final RImg, or full S7 contract packages.

The foreground-only element collection sheet(s) must be generated from the S6-FINAL-SELECT selected final reference and the recorded theme-element inventory. They must remove texture, borders, frames, region boxes, grid lines, connector lines, arrows, arrowheads, all text labels, titles, and descriptions. They keep only reusable foreground elements and should minimize overlap, occlusion, fusion, nesting, and ambiguity. If one sheet cannot cover the needed elements cleanly, create additional `rimg-no-texture-final-02.png` style collection sheets and list them in the manifest.

## S8-SVG-PPT PPT Delivery

S8-SVG-PPT uses:

- `--reference-final`: S6-FINAL-SELECT selected final reference;
- `--no-texture-final`: S7-FOREGROUND-IMAGE primary foreground-only element collection sheet; additional foreground collection sheets listed in the manifest inform the element inventory and catalog spec.

PPTX slide order:

1. grayscale S6-FINAL-SELECT selected final reference as the map page;
2. original S6-FINAL-SELECT selected final reference;
3. movable, editable SVG icon / foreground-element pages generated from the foreground-only element collection sheet(s).

S8-SVG-PPT must provide a visible download/artifact link to `outputs/S8-svg-ppt/s8-svg-ppt-delivery.pptx` in the completion reply. Without the link, S8-SVG-PPT is not complete.

## Rewind Cleanup

Free-form user requests must be mapped to a real `target_step` and operation mode before acting. Do not depend on explicit user words such as rerun, generate, overwrite, repair, or patch.

- Inspect mode reads or validates existing files without writing/replacing outputs. It does not clean outputs and should state that no outputs/state changed.
- Rebuild/rerun/progress mode creates, advances, replaces, regenerates, or re-exports a stage artifact. Before execution, delete products for the covered span from `target_step` through the previous `current_step`, remove covered active state records, record a cleanup event, and then execute.
- Repair/patch mode fixes an existing same-step artifact. It may read the same-step artifact as input only after backing it up and recording a repair event. After the repair validates and target-step state is updated, delete all downstream outputs after `target_step`, remove downstream active state records, and record the reason `downstream invalidated by repaired target_step artifact`.

During execution or repair, only read `inputs/`, skill package references, assets, scripts, `state/project-state.json`, valid artifacts from steps before `target_step`, and same-step repair inputs/backups. Never read or reuse artifacts from steps after `target_step`, stale/removed artifacts, or old files from mismatched epochs/attempts except for pure historical inspection that writes no outputs.

Never delete `state/project-state.json`, `state/`, `inputs/`, user source files, or skill package files. Remove covered artifact/image-generation records from active state and preserve cleanup events as the audit trail.



