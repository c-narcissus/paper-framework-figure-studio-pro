# S8-SVG-PPT PowerPoint Compatibility

S8-SVG-PPT first follows the active foreground SVG catalog route:

```text
outputs/S7-foreground-image/rimg-no-texture-final-01.png
```

is the extraction source, and the selected final reference is used for PPT slide 1/2.

Build the deck with:

```bash
node scripts/figure_studio_s8_svg_catalog_ppt.js \
  --project-root <project_run_root> \
  --spec outputs/S8-svg-ppt/_work/icon_catalog_spec.json \
  --out outputs/S8-svg-ppt \
  --reference-final outputs/S5-candidate-images/candidate-01.png \
  --no-texture-final outputs/S7-foreground-image/rimg-no-texture-final-01.png \
  --pptx
```

After the PPTX is built, always run the SVG display compatibility/export script. The route is still SVG catalog first; compatibility patches are packaging work and cannot replace the required self-contained PPTX delivery. For the full reusable checklist, state fields, and native PowerPoint layer workflow, also read `references/s8-editable-ppt-lessons.md`.

```bash
python scripts/figure_studio_s8_svg_display_compat.py \
  --in outputs/S8-svg-ppt/s8-svg-ppt-delivery.pptx \
  --out outputs/S8-svg-ppt/s8-svg-ppt-delivery.pptx \
  --export-dir outputs/S8-svg-exported-icons \
  --backup-original outputs/S8-svg-exported-icons/s8-svg-ppt-delivery-svg-only-original.pptx \
  --report outputs/S8-svg-exported-icons/pptx-svg-display-compat-report.json \
  --json
```

Why this is mandatory: a PPTX that stores SVG as direct image relationships can be self-contained and still fail to render in PowerPoint/WPS or preview surfaces. The compatibility script exports `ppt/media/*.svg`, renders PNG fallbacks with Edge/Chrome/Chromium when available, and rewrites slide pictures as PNG fallback images with an Office `asvg:svgBlip` pointer to the original SVG source. If browser rendering is unavailable, the script falls back to `cairosvg` only when native cairo is installed.

Retain:

```text
outputs/S8-svg-ppt/s8-svg-ppt-delivery.pptx
outputs/S8-svg-exported-icons/*.svg
outputs/S8-svg-exported-icons/png-fallbacks/*.png
outputs/S8-svg-exported-icons/s8-svg-ppt-delivery-svg-only-original.pptx
```

Report these counts in the final reply and state: slide count, embedded SVG count, PNG fallback count, `svgBlip` count, external relationship count, and missing internal target count.


