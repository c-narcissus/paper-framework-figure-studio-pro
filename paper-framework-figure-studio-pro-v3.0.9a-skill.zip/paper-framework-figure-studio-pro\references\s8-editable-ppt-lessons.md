# S8 Editable PPT Lessons

Use this reference when S8-SVG-PPT output must work in real PowerPoint/WPS and when the user wants final manual PowerPoint editing.

## Lessons From SemiDFL

- A PPTX can be self-contained and still show blank SVG pictures if slide relationships point directly to SVG media. Treat direct SVG image relationships as insufficient for delivery.
- The reliable packaging pattern is PNG fallback for display plus Office `asvg:svgBlip` pointing to the original SVG. This keeps the SVG source embedded while making the slide visible in PowerPoint/WPS.
- Embedded SVG media is movable and scalable, but it is still a picture-like object in PowerPoint. For layer-by-layer final editing, generate a separate native PowerPoint shape deck.
- A native layer deck should use PowerPoint primitive shapes, live text boxes, connectors, and readable shape names. It should not embed SVG media as the editable layer surface.
- Preserve both outputs when needed: the SVG catalog deck for source SVG reuse, and the native shape layer deck for final manual PPT editing.

## Reusable Scripts

Primary S8 SVG catalog PPTX builder:

```bash
node scripts/figure_studio_s8_svg_catalog_ppt.js \
  --project-root <project_run_root> \
  --spec outputs/S8-svg-ppt/_work/icon_catalog_spec.json \
  --out outputs/S8-svg-ppt \
  --reference-final outputs/S5-candidate-images/candidate-01.png \
  --no-texture-final outputs/S7-foreground-image/rimg-no-texture-final-01.png \
  --pptx
```

SVG export and PowerPoint/WPS display compatibility patch:

```bash
python scripts/figure_studio_s8_svg_display_compat.py \
  --in outputs/S8-svg-ppt/s8-svg-ppt-delivery.pptx \
  --out outputs/S8-svg-ppt/s8-svg-ppt-delivery.pptx \
  --export-dir outputs/S8-svg-exported-icons \
  --backup-original outputs/S8-svg-exported-icons/s8-svg-ppt-delivery-svg-only-original.pptx \
  --report outputs/S8-svg-exported-icons/pptx-svg-display-compat-report.json \
  --json
```

Native PowerPoint vector layer deck for final manual editing:

```bash
python scripts/figure_studio_s8_native_ppt_layers.py \
  --project-root <project_run_root> \
  --reference-final outputs/S5-candidate-images/candidate-01.png \
  --out-dir outputs/S8-native-vector-layers
```

Validate the S8 delivery deck:

```bash
python scripts/figure_studio_s8_clean_delivery.py validate --output-dir outputs/S8-svg-ppt
```

## Dependencies

- Node.js plus `pptxgenjs`, `sharp`, and `image-size` for the SVG catalog PPTX builder.
- Python 3.9+ for all S8 Python helpers.
- Python standard library is enough for OOXML relationship patching in `figure_studio_s8_svg_display_compat.py`.
- Microsoft Edge, Google Chrome, or Chromium is the preferred SVG-to-PNG fallback renderer. Browser rendering avoids Windows native Cairo installation issues.
- `cairosvg` is only a fallback when native Cairo is installed and importable.
- `python-pptx` plus Pillow is required for native PowerPoint vector layer decks.

Install example:

```bash
npm install pptxgenjs sharp image-size
python -m pip install python-pptx pillow lxml
```

## Required Outputs

Always retain these SVG/PPT delivery files:

```text
outputs/S8-svg-ppt/s8-svg-ppt-delivery.pptx
outputs/S8-svg-exported-icons/*.svg
outputs/S8-svg-exported-icons/png-fallbacks/*.png
outputs/S8-svg-exported-icons/pptx-svg-display-compat-report.json
outputs/S8-svg-exported-icons/s8-svg-ppt-delivery-svg-only-original.pptx
```

When native PPT editing is requested, also retain:

```text
outputs/S8-native-vector-layers/s8-native-vector-layers.pptx
outputs/S8-native-vector-layers/layer-manifest.json
```

## Validation Checklist

For the SVG catalog deck:

- slide count matches expected reference and catalog pages;
- embedded SVG media count is nonzero;
- PNG fallback media count is nonzero and includes every SVG foreground element;
- `svgBlip` relationship count matches the patched SVG element count;
- no external relationships;
- no missing internal targets;
- each SVG has a title or equivalent inspectable identity.

For the native PowerPoint layer deck:

- PowerPoint opens the file without repair;
- `ppt/media/*.svg` count is zero;
- shapes are PowerPoint-native primitives, text boxes, or connectors;
- every meaningful primitive has a readable shape name;
- manifest records slide roles, icon groups, layer count, and source reference path;
- basic atom pages exist for final manual editing.

## State Registration

Register the normal S8 PPTX under the canonical S8 delivery role when available. Register native layer outputs as additional S8 artifacts, not as replacements for `s8.delivery_pptx`.

Example artifact IDs:

```text
s8-svg-ppt-delivery
s8-native-vector-layers
s8-native-vector-layer-manifest
```

Suggested state summary fields:

```json
{
  "s8_svg_ppt_delivery": {
    "status": "completed_compatibility_patched",
    "delivery_pptx": "outputs/S8-svg-ppt/s8-svg-ppt-delivery.pptx",
    "exported_svg_dir": "outputs/S8-svg-exported-icons",
    "png_fallback_dir": "outputs/S8-svg-exported-icons/png-fallbacks",
    "png_fallback_count": 0,
    "svg_blip_count": 0
  },
  "s8_native_vector_layers": {
    "status": "completed",
    "native_pptx": "outputs/S8-native-vector-layers/s8-native-vector-layers.pptx",
    "layer_manifest": "outputs/S8-native-vector-layers/layer-manifest.json",
    "shape_model": "PowerPoint-native primitive shapes with named layers",
    "pptx_slide_count": 0,
    "pptx_shape_count": 0,
    "media_svg_count": 0
  }
}
```

## Failure Patterns

- If the PPTX contains SVG media but no PNG fallbacks or `svgBlip`, expect blank rendering in some viewers.
- If the user asks to edit individual layers in PowerPoint, do not claim embedded SVG pictures are sufficient. Generate the native shape layer deck.
- If Edge/Chrome/Chromium is unavailable and CairoSVG cannot import native Cairo, stop and report the missing renderer instead of marking display compatibility complete.
- If a smoke test creates `__pycache__`, remove it before release audits or package scans.
- Do not keep host-specific absolute paths in state, manifests, or skill docs.
