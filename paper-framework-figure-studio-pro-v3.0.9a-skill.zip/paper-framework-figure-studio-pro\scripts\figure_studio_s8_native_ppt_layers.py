#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import math
from datetime import datetime, timezone
from pathlib import Path

from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.dml import MSO_LINE_DASH_STYLE
from pptx.enum.shapes import MSO_CONNECTOR, MSO_SHAPE
from pptx.enum.text import PP_ALIGN
from pptx.util import Inches, Pt


ROOT = Path.cwd()
OUT_DIR = ROOT / "outputs" / "S8-native-vector-layers"
PPTX = OUT_DIR / "s8-native-vector-layers.pptx"
MANIFEST = OUT_DIR / "layer-manifest.json"
REFERENCE = ROOT / "outputs" / "S5-candidate-images" / "candidate-01.png"

WIDE_W = 13.333
WIDE_H = 7.5

PALETTE = {
    "ink": "101A3D",
    "muted": "556170",
    "green": "1F7A32",
    "blue": "1F55C8",
    "orange": "E54B16",
    "teal": "078B8D",
    "purple": "6D28D9",
    "red": "D11A1A",
    "pale": "F8FAFC",
    "white": "FFFFFF",
    "light_green": "E8F7EE",
    "light_blue": "EEF5FF",
    "light_orange": "FFF7ED",
    "light_purple": "F5F3FF",
}

GROUPS = [
    ("clients_privacy", "Clients and Private Data", "blue"),
    ("data_space", "Data-Space Consensus", "green"),
    ("model_space", "Model-Space Consensus", "purple"),
    ("constraints", "Decentralized Constraints", "red"),
]

ICONS = [
    ("client_l", "L-client laptop", "clients_privacy", "green"),
    ("client_u", "U-client laptop", "clients_privacy", "blue"),
    ("client_m", "M-client laptop", "clients_privacy", "orange"),
    ("local_private_data", "Local private data", "clients_privacy", "ink"),
    ("neighbor_graph", "Peer-to-peer neighbor graph", "clients_privacy", "ink"),
    ("neighborhood_pl", "Neighborhood PL", "data_space", "green"),
    ("consensus_diffusion", "Consensus diffusion", "data_space", "green"),
    ("generated_samples", "Generated sample stack", "data_space", "ink"),
    ("generated_tokens", "Generated data tokens", "data_space", "orange"),
    ("c_mixup", "C-MixUp mixed tokens", "data_space", "purple"),
    ("classifier_network", "Classifier network", "model_space", "ink"),
    ("generated_data_validation", "Generated-data validation", "model_space", "ink"),
    ("adaptive_aggregation", "Adaptive aggregation weights", "model_space", "blue"),
    ("neighbor_model_consensus", "Neighbor model consensus", "model_space", "blue"),
    ("no_central_server", "No central server", "constraints", "red"),
    ("no_raw_data_sharing", "No raw-data sharing", "constraints", "red"),
]


def rgb(name_or_hex: str) -> RGBColor:
    value = PALETTE.get(name_or_hex, name_or_hex).replace("#", "")
    return RGBColor.from_string(value.upper())


def inch(v: float):
    return Inches(v)


class Canvas:
    def __init__(self, slide, x: float, y: float, size: float, prefix: str, manifest: list[dict]):
        self.slide = slide
        self.x = x
        self.y = y
        self.size = size
        self.prefix = prefix
        self.manifest = manifest

    def u(self, v: float) -> float:
        return self.size * v / 96.0

    def xywh(self, x: float, y: float, w: float, h: float):
        return inch(self.x + self.u(x)), inch(self.y + self.u(y)), inch(self.u(w)), inch(self.u(h))

    def pt(self, x: float, y: float):
        return inch(self.x + self.u(x)), inch(self.y + self.u(y))

    def record(self, shape, layer: str, kind: str) -> None:
        shape.name = f"{self.prefix}.{layer}"
        self.manifest.append({"icon": self.prefix, "layer": layer, "kind": kind, "shape_name": shape.name})

    def shape(self, layer: str, kind, x, y, w, h, fill=None, line="ink", lw=1.5, dash=None, radius=False):
        shp = self.slide.shapes.add_shape(kind, *self.xywh(x, y, w, h))
        if fill is None:
            shp.fill.background()
        else:
            shp.fill.solid()
            shp.fill.fore_color.rgb = rgb(fill)
            if hasattr(shp.fill, "transparency"):
                pass
        shp.line.color.rgb = rgb(line)
        shp.line.width = Pt(lw)
        if dash:
            shp.line.dash_style = dash
        self.record(shp, layer, "shape")
        return shp

    def rect(self, layer, x, y, w, h, fill=None, line="ink", lw=1.5, rounded=False, dash=None):
        return self.shape(layer, MSO_SHAPE.ROUNDED_RECTANGLE if rounded else MSO_SHAPE.RECTANGLE, x, y, w, h, fill, line, lw, dash)

    def oval(self, layer, cx, cy, w, h, fill=None, line="ink", lw=1.5):
        return self.shape(layer, MSO_SHAPE.OVAL, cx - w / 2, cy - h / 2, w, h, fill, line, lw)

    def line(self, layer, x1, y1, x2, y2, line="ink", lw=1.5, dash=None):
        shp = self.slide.shapes.add_connector(MSO_CONNECTOR.STRAIGHT, *self.pt(x1, y1), *self.pt(x2, y2))
        shp.line.color.rgb = rgb(line)
        shp.line.width = Pt(lw)
        if dash:
            shp.line.dash_style = dash
        self.record(shp, layer, "line")
        return shp

    def freeform(self, layer, points, fill=None, line="ink", lw=1.5):
        start = points[0]
        builder = self.slide.shapes.build_freeform(*self.pt(*start))
        for point in points[1:]:
            builder.add_line_segments([self.pt(*point)], close=False)
        shp = builder.convert_to_shape()
        if fill is None:
            shp.fill.background()
        else:
            shp.fill.solid()
            shp.fill.fore_color.rgb = rgb(fill)
        shp.line.color.rgb = rgb(line)
        shp.line.width = Pt(lw)
        self.record(shp, layer, "freeform")
        return shp


def add_title(slide, title: str, subtitle: str = ""):
    bar = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, inch(0), inch(0), inch(WIDE_W), inch(0.16))
    bar.fill.solid()
    bar.fill.fore_color.rgb = rgb("ink")
    bar.line.color.rgb = rgb("ink")
    tx = slide.shapes.add_textbox(inch(0.48), inch(0.32), inch(11.6), inch(0.5))
    set_text(tx, title, 24, "ink", bold=True)
    if subtitle:
        sub = slide.shapes.add_textbox(inch(0.49), inch(0.82), inch(11.9), inch(0.28))
        set_text(sub, subtitle, 9.5, "muted")


def set_text(shape, text: str, size: float, color="ink", bold=False, align=None):
    tf = shape.text_frame
    tf.clear()
    p = tf.paragraphs[0]
    if align:
        p.alignment = align
    run = p.add_run()
    run.text = text
    run.font.name = "Arial"
    run.font.size = Pt(size)
    run.font.bold = bold
    run.font.color.rgb = rgb(color)
    tf.margin_left = inch(0.03)
    tf.margin_right = inch(0.03)
    tf.margin_top = inch(0.01)
    tf.margin_bottom = inch(0.01)


def add_note(slide, text: str, x: float, y: float, w: float, h: float, size=8.5):
    box = slide.shapes.add_textbox(inch(x), inch(y), inch(w), inch(h))
    set_text(box, text, size, "muted")
    return box


def draw_laptop(c: Canvas, color: str):
    c.rect("screen_outer", 24, 18, 48, 34, fill="white", line=color, lw=2.4, rounded=True)
    c.rect("screen_inner", 29, 23, 38, 24, fill="pale", line=color, lw=1.3, rounded=True)
    c.freeform("keyboard_deck", [(18, 68), (28, 54), (68, 54), (78, 68), (18, 68)], fill="white", line=color, lw=2.4)
    c.line("trackpad", 39, 63, 57, 63, line=color, lw=2.2)
    c.rect("front_lip", 18, 68, 60, 6, fill="white", line=color, lw=2.4, rounded=True)


def draw_database(c: Canvas, color: str):
    c.shape("body", MSO_SHAPE.CAN, 23, 14, 50, 68, fill="white", line=color, lw=2.2)
    c.line("middle_band", 24, 45, 72, 45, line=color, lw=1.5)
    c.line("lower_band", 24, 61, 72, 61, line=color, lw=1.5)
    c.oval("dot_top", 65, 42, 4, 4, fill=color, line=color, lw=0.5)
    c.oval("dot_bottom", 65, 60, 4, 4, fill=color, line=color, lw=0.5)


def draw_graph(c: Canvas, color: str, diffusion=False):
    nodes = [(22, 36), (48, 18), (74, 36), (32, 70), (64, 70), (48, 54)]
    lines = [
        (22, 36, 48, 18), (48, 18, 74, 36), (22, 36, 32, 70), (74, 36, 64, 70),
        (32, 70, 64, 70), (22, 36, 64, 70), (74, 36, 32, 70), (48, 18, 48, 54), (22, 36, 74, 36),
    ]
    for i, (x1, y1, x2, y2) in enumerate(lines):
        c.line(f"edge_{i+1:02d}", x1, y1, x2, y2, line=color, lw=1.2 if diffusion else 1.6)
    for i, (x, y) in enumerate(nodes):
        if diffusion:
            c.shape(f"diffusion_node_{i+1:02d}", MSO_SHAPE.CAN, x - 7, y - 8, 14, 20, fill="white", line=color, lw=1.6)
        else:
            c.oval(f"node_{i+1:02d}", x, y, 15, 15, fill="white", line=color, lw=2)


def draw_people_network(c: Canvas, color: str):
    c.oval("center_head", 48, 37, 13, 13, fill=color, line=color, lw=1.5)
    c.freeform("center_body", [(36, 67), (40, 54), (56, 54), (60, 67), (36, 67)], fill=color, line=color, lw=1.5)
    outer = [(24, 24), (72, 24), (22, 66), (74, 66), (48, 12)]
    for i, (x, y) in enumerate(outer):
        c.line(f"neighbor_link_{i+1}", 48, 45, x, y + 5, line=color, lw=1.2)
        c.oval(f"neighbor_{i+1}_head", x, y, 10, 10, fill="white", line=color, lw=1.8)
        c.freeform(f"neighbor_{i+1}_body", [(x - 8, y + 18), (x - 5, y + 9), (x + 5, y + 9), (x + 8, y + 18), (x - 8, y + 18)], fill="white", line=color, lw=1.8)


def draw_sample_stack(c: Canvas, color: str):
    c.rect("back_card", 23, 16, 42, 34, fill="white", line=color, lw=1.6, rounded=True)
    c.rect("middle_card", 29, 23, 42, 34, fill="white", line=color, lw=1.6, rounded=True)
    c.rect("front_card", 35, 31, 42, 42, fill="white", line=color, lw=2.2, rounded=True)
    c.oval("image_sun", 47, 43, 7, 7, fill="white", line=color, lw=1.5)
    c.freeform("image_mountain", [(42, 66), (54, 53), (61, 60), (67, 49), (75, 66), (42, 66)], fill="pale", line=color, lw=1.6)


def draw_tokens(c: Canvas):
    c.oval("green_circle", 24, 28, 16, 16, fill="light_green", line="green", lw=1.8)
    c.rect("blue_square", 54, 20, 16, 16, fill="light_blue", line="blue", lw=1.8)
    c.shape("purple_diamond", MSO_SHAPE.DIAMOND, 24, 48, 24, 24, fill="light_purple", line="purple", lw=1.8)
    c.shape("orange_triangle", MSO_SHAPE.ISOSCELES_TRIANGLE, 56, 48, 24, 24, fill="light_orange", line="orange", lw=1.8)
    c.shape("black_star", MSO_SHAPE.STAR_5_POINT, 34, 36, 28, 28, fill="white", line="ink", lw=1.6)


def draw_cmixup(c: Canvas):
    c.oval("green_set", 38, 47, 56, 56, fill="light_green", line="green", lw=1.8)
    c.oval("purple_set", 58, 47, 56, 56, fill="light_purple", line="purple", lw=1.8)
    c.oval("mixed_circle", 33, 42, 12, 12, fill="light_green", line="green", lw=1.6)
    c.rect("mixed_square", 44, 58, 12, 12, fill="white", line="green", lw=1.6)
    c.shape("mixed_diamond", MSO_SHAPE.DIAMOND, 51, 33, 20, 20, fill="white", line="purple", lw=1.6)
    c.shape("mixed_triangle", MSO_SHAPE.ISOSCELES_TRIANGLE, 56, 58, 20, 18, fill="white", line="purple", lw=1.6)


def draw_classifier(c: Canvas, color: str):
    layers = [[(20, 28), (20, 48), (20, 68)], [(48, 24), (48, 48), (48, 72)], [(76, 36), (76, 60)]]
    edge_idx = 1
    for left, right in zip(layers, layers[1:]):
        for x1, y1 in left:
            for x2, y2 in right:
                c.line(f"edge_{edge_idx:02d}", x1, y1, x2, y2, line=color, lw=1.1)
                edge_idx += 1
    node_idx = 1
    for layer in layers:
        for x, y in layer:
            c.oval(f"node_{node_idx:02d}", x, y, 13, 13, fill="white", line=color, lw=1.8)
            node_idx += 1


def draw_validation(c: Canvas, color: str):
    c.rect("clipboard", 22, 14, 52, 68, fill="white", line=color, lw=2.2, rounded=True)
    c.shape("check_box_1", MSO_SHAPE.RECTANGLE, 32, 26, 10, 10, fill="white", line=color, lw=1.2)
    c.line("check_1_a", 33, 31, 38, 36, line="green", lw=2.4)
    c.line("check_1_b", 38, 36, 49, 23, line="green", lw=2.4)
    c.line("row_1", 54, 32, 68, 32, line=color, lw=1.5)
    c.shape("check_box_2", MSO_SHAPE.RECTANGLE, 32, 46, 10, 10, fill="white", line=color, lw=1.2)
    c.line("check_2_a", 33, 51, 38, 56, line="green", lw=2.4)
    c.line("check_2_b", 38, 56, 49, 43, line="green", lw=2.4)
    c.line("row_2", 54, 52, 68, 52, line=color, lw=1.5)
    c.line("cross_a", 33, 69, 47, 55, line="red", lw=2.4)
    c.line("cross_b", 33, 55, 47, 69, line="red", lw=2.4)
    c.line("row_3", 54, 64, 68, 64, line=color, lw=1.5)


def draw_bars(c: Canvas, color: str):
    c.line("baseline", 17, 78, 82, 78, line=color, lw=2.2)
    c.rect("bar_low", 24, 45, 10, 33, fill="light_blue", line=color, lw=1.6)
    c.rect("bar_mid", 42, 34, 10, 44, fill="light_blue", line=color, lw=1.6)
    c.rect("bar_high", 60, 22, 10, 56, fill="blue", line=color, lw=1.6)
    c.line("target_low", 24, 31, 34, 31, line=color, lw=1.2, dash=MSO_LINE_DASH_STYLE.DASH)
    c.line("target_mid", 42, 24, 52, 24, line=color, lw=1.2, dash=MSO_LINE_DASH_STYLE.DASH)
    c.line("target_high", 60, 14, 70, 14, line=color, lw=1.2, dash=MSO_LINE_DASH_STYLE.DASH)


def draw_model_consensus(c: Canvas, color: str):
    c.shape("left_model", MSO_SHAPE.CAN, 8, 37, 20, 28, fill="white", line=color, lw=1.8)
    c.line("link_left", 30, 53, 40, 53, line=color, lw=1.6)
    c.oval("consensus_node", 48, 53, 16, 16, fill="white", line=color, lw=1.8)
    c.line("link_right", 56, 53, 66, 53, line=color, lw=1.6)
    c.shape("right_model", MSO_SHAPE.CAN, 68, 37, 20, 28, fill="white", line=color, lw=1.8)
    c.shape("top_arc", MSO_SHAPE.ARC, 35, 22, 28, 22, fill=None, line=color, lw=1.8)
    c.shape("bottom_arc", MSO_SHAPE.ARC, 35, 58, 28, 22, fill=None, line=color, lw=1.8)


def draw_no_symbol(c: Canvas, inner_kind: str):
    if inner_kind == "server":
        for i, y in enumerate([24, 42, 60], start=1):
            c.rect(f"server_unit_{i}", 25, y, 46, 14, fill="pale", line="ink", lw=1.4, rounded=True)
            c.oval(f"server_led_{i}", 34, y + 7, 4, 4, fill="ink", line="ink", lw=0.5)
            c.line(f"server_line_{i}", 52, y + 7, 64, y + 7, line="ink", lw=1.2)
    else:
        draw_database(c, "ink")
    c.shape("prohibition_ring", MSO_SHAPE.NO_SYMBOL, 10, 10, 76, 76, fill=None, line="red", lw=2.2)
    c.line("prohibition_slash", 24, 24, 72, 72, line="red", lw=2.6)


def draw_icon(icon_id: str, c: Canvas, color_name: str):
    if icon_id.startswith("client_"):
        draw_laptop(c, color_name)
    elif icon_id == "local_private_data":
        draw_database(c, color_name)
    elif icon_id == "neighbor_graph":
        draw_graph(c, color_name, diffusion=False)
    elif icon_id == "neighborhood_pl":
        draw_people_network(c, color_name)
    elif icon_id == "consensus_diffusion":
        draw_graph(c, color_name, diffusion=True)
    elif icon_id == "generated_samples":
        draw_sample_stack(c, color_name)
    elif icon_id == "generated_tokens":
        draw_tokens(c)
    elif icon_id == "c_mixup":
        draw_cmixup(c)
    elif icon_id == "classifier_network":
        draw_classifier(c, color_name)
    elif icon_id == "generated_data_validation":
        draw_validation(c, color_name)
    elif icon_id == "adaptive_aggregation":
        draw_bars(c, color_name)
    elif icon_id == "neighbor_model_consensus":
        draw_model_consensus(c, color_name)
    elif icon_id == "no_central_server":
        draw_no_symbol(c, "server")
    elif icon_id == "no_raw_data_sharing":
        draw_no_symbol(c, "data")


def draw_icon_card(slide, icon, x, y, w, h, manifest, native=True):
    icon_id, title, group, color = icon
    card = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, inch(x), inch(y), inch(w), inch(h))
    card.fill.solid()
    card.fill.fore_color.rgb = rgb("white")
    card.line.color.rgb = rgb(color)
    card.line.width = Pt(1)
    card.name = f"{icon_id}.card_container"
    canvas = Canvas(slide, x + w / 2 - min(w * 0.45, h * 0.45) / 2, y + 0.34, min(w * 0.45, h * 0.45), icon_id, manifest)
    draw_icon(icon_id, canvas, color)
    label = slide.shapes.add_textbox(inch(x + 0.08), inch(y + h - 0.42), inch(w - 0.16), inch(0.24))
    set_text(label, title, 7.8, "ink", bold=True, align=PP_ALIGN.CENTER)
    label.name = f"{icon_id}.editable_label"
    fname = slide.shapes.add_textbox(inch(x + 0.08), inch(y + h - 0.19), inch(w - 0.16), inch(0.13))
    set_text(fname, icon_id, 5.3, "muted", align=PP_ALIGN.CENTER)
    fname.name = f"{icon_id}.editable_id"


def add_reference_slide(prs):
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    add_title(slide, "S6 Final Reference Map", "Raster reference only; later slides provide native PPT vector layers for editing.")
    if REFERENCE.exists():
        slide.shapes.add_picture(str(REFERENCE), inch(0.72), inch(1.28), width=inch(11.9))
    add_note(slide, "Use this as a visual map while assembling/editing native layers from later slides.", 0.76, 7.02, 11.5, 0.26)


def add_overview_slide(prs):
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    add_title(slide, "SemiDFL Native PPT Vector Layers", "All icon pages are PowerPoint-native shapes, not SVG image media.")
    bullets = [
        "Slides 3-6: semantic icon boards with editable PPT shapes.",
        "Slides 7-22: one icon per slide, decomposed into named primitive layers.",
        "Final slide: basic atom layer board for building custom variants.",
        "Open PowerPoint Selection Pane to edit layers named like client_l.screen_outer or classifier_network.edge_01.",
        "Colors, strokes, positions, and text labels can be changed directly in PowerPoint.",
    ]
    y = 1.55
    for line in bullets:
        box = slide.shapes.add_textbox(inch(0.75), inch(y), inch(11.6), inch(0.32))
        set_text(box, line, 14, "ink")
        y += 0.48


def add_group_boards(prs, manifest):
    for group_id, group_title, accent in GROUPS:
        slide = prs.slides.add_slide(prs.slide_layouts[6])
        add_title(slide, group_title, "Editable native PPT icon board. Each primitive shape is separately selectable.")
        group_icons = [icon for icon in ICONS if icon[2] == group_id]
        cols = 4
        card_w = 2.85
        card_h = 2.25
        for i, icon in enumerate(group_icons):
            col = i % cols
            row = i // cols
            draw_icon_card(slide, icon, 0.58 + col * 3.12, 1.42 + row * 2.55, card_w, card_h, manifest)


def add_single_icon_pages(prs, manifest):
    for icon in ICONS:
        icon_id, title, group, color = icon
        slide = prs.slides.add_slide(prs.slide_layouts[6])
        add_title(slide, title, f"Single-icon editable layer page: {icon_id}")
        canvas = Canvas(slide, 1.05, 1.45, 3.2, icon_id, manifest)
        draw_icon(icon_id, canvas, color)
        box = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, inch(5.05), inch(1.35), inch(7.45), inch(5.55))
        box.fill.solid()
        box.fill.fore_color.rgb = rgb("white")
        box.line.color.rgb = rgb("muted")
        box.line.width = Pt(1)
        layers = [r["layer"] for r in manifest if r["icon"] == icon_id]
        lines = [f"{idx+1:02d}. {layer}" for idx, layer in enumerate(layers[-40:])]
        tx = slide.shapes.add_textbox(inch(5.35), inch(1.62), inch(6.8), inch(4.9))
        set_text(tx, "Primitive layers in this icon:\n" + "\n".join(lines), 10, "ink")
        add_note(slide, "Tip: select and ungrouping is not required; these are already separate PPT shapes.", 1.02, 6.75, 11.2, 0.32)


def add_atom_board(prs, manifest):
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    add_title(slide, "Basic Atom Layer Board", "Reusable primitive building blocks for custom PPT editing.")
    atoms = [
        ("atom_laptop", "Laptop atom", "green"),
        ("atom_database", "Data cylinder atom", "ink"),
        ("atom_graph", "Graph atom", "ink"),
        ("atom_person_network", "People network atom", "green"),
        ("atom_sample_stack", "Sample stack atom", "ink"),
        ("atom_tokens", "Token shapes atom", "orange"),
        ("atom_classifier", "Neural net atom", "ink"),
        ("atom_validation", "Checklist atom", "ink"),
        ("atom_bars", "Weight bars atom", "blue"),
        ("atom_no_server", "No-symbol atom", "red"),
    ]
    drawers = {
        "atom_laptop": lambda c, color: draw_laptop(c, color),
        "atom_database": lambda c, color: draw_database(c, color),
        "atom_graph": lambda c, color: draw_graph(c, color, diffusion=False),
        "atom_person_network": lambda c, color: draw_people_network(c, color),
        "atom_sample_stack": lambda c, color: draw_sample_stack(c, color),
        "atom_tokens": lambda c, color: draw_tokens(c),
        "atom_classifier": lambda c, color: draw_classifier(c, color),
        "atom_validation": lambda c, color: draw_validation(c, color),
        "atom_bars": lambda c, color: draw_bars(c, color),
        "atom_no_server": lambda c, color: draw_no_symbol(c, "server"),
    }
    cols = 5
    for i, (atom_id, title, color) in enumerate(atoms):
        col = i % cols
        row = i // cols
        x = 0.65 + col * 2.55
        y = 1.42 + row * 2.72
        card = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, inch(x), inch(y), inch(2.2), inch(2.32))
        card.fill.solid()
        card.fill.fore_color.rgb = rgb("white")
        card.line.color.rgb = rgb(color)
        card.line.width = Pt(1)
        card.name = f"{atom_id}.card_container"
        c = Canvas(slide, x + 0.55, y + 0.35, 1.05, atom_id, manifest)
        drawers[atom_id](c, color)
        label = slide.shapes.add_textbox(inch(x + 0.08), inch(y + 1.98), inch(2.04), inch(0.2))
        set_text(label, title, 7.5, "ink", bold=True, align=PP_ALIGN.CENTER)
        label.name = f"{atom_id}.editable_label"


def configure_from_args(argv=None):
    parser = argparse.ArgumentParser(
        description=(
            "Build a PowerPoint-native editable vector layer deck for S8. "
            "This template provides common CS/SemiDFL foreground icons as PPT primitive shapes."
        )
    )
    parser.add_argument("--project-root", type=Path, default=Path.cwd())
    parser.add_argument("--out-dir", default="outputs/S8-native-vector-layers")
    parser.add_argument("--reference-final", default="outputs/S5-candidate-images/candidate-01.png")
    parser.add_argument("--pptx-name", default="s8-native-vector-layers.pptx")
    parser.add_argument("--manifest-name", default="layer-manifest.json")
    args = parser.parse_args(argv)

    global ROOT, OUT_DIR, PPTX, MANIFEST, REFERENCE
    ROOT = args.project_root.resolve()
    OUT_DIR = ROOT / args.out_dir
    PPTX = OUT_DIR / args.pptx_name
    MANIFEST = OUT_DIR / args.manifest_name
    REFERENCE = ROOT / args.reference_final
    return args


def build():
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    prs = Presentation()
    prs.slide_width = inch(WIDE_W)
    prs.slide_height = inch(WIDE_H)
    manifest: list[dict] = []
    add_overview_slide(prs)
    add_reference_slide(prs)
    add_group_boards(prs, manifest)
    add_single_icon_pages(prs, manifest)
    add_atom_board(prs, manifest)
    prs.save(PPTX)
    output_manifest = {
        "schema": "semiDFL-s8-native-vector-layers-v1",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "pptx": "outputs/S8-native-vector-layers/s8-native-vector-layers.pptx",
        "reference_final": "outputs/S5-candidate-images/candidate-01.png",
        "shape_model": "PowerPoint-native primitive shapes; no SVG image media required for the native layer deck.",
        "slides": {
            "1": "overview",
            "2": "S6 raster reference map",
            "3-6": "semantic icon boards",
            "7-22": "single-icon layer pages",
            "23": "basic atom layer board",
        },
        "icons": [
            {"id": icon_id, "title": title, "group": group, "accent": color}
            for icon_id, title, group, color in ICONS
        ],
        "layers": manifest,
        "layer_count": len(manifest),
    }
    MANIFEST.write_text(json.dumps(output_manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(PPTX)
    print(MANIFEST)
    print(f"slides={len(prs.slides)} layers={len(manifest)}")


if __name__ == "__main__":
    configure_from_args()
    build()
