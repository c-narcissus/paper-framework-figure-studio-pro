# S8-SVG-PPT Package Contract

S8-SVG-PPT must generate a self-contained PPTX and cannot be replaced by a single new image or concept explanation. Read `references/s8-editable-ppt-lessons.md` for the reusable PowerPoint/WPS display compatibility and native-layer editing checklist.

## Inputs

- S6-FINAL-SELECT selected final reference, default `outputs/S5-candidate-images/candidate-01.png`.
- S7-FOREGROUND-IMAGE foreground-only element collection sheet(s), starting with `outputs/S7-foreground-image/rimg-no-texture-final-01.png`; read `foreground-only-manifest.json` for any additional sheets.
- SVG catalog spec, `outputs/S8-svg-ppt/_work/icon_catalog_spec.json`.

## Required Process

1. Run S8-SVG-PPT rewind cleanup if old S8-SVG-PPT outputs or records exist.
2. Build a foreground element inventory from `rimg-no-texture-final-01.png` plus any additional collection sheets listed in `foreground-only-manifest.json`.
3. Exclude connector lines, borders, arrows, arrowheads, text labels, titles, descriptions, background texture, region fills, and decorations by default.
4. Fill `icon_catalog_spec.json` with stable IDs, titles, groups, accents, and safe SVG definitions.
5. Run:

```bash
node scripts/figure_studio_s8_svg_catalog_ppt.js \
  --project-root <project_run_root> \
  --spec outputs/S8-svg-ppt/_work/icon_catalog_spec.json \
  --out outputs/S8-svg-ppt \
  --reference-final outputs/S5-candidate-images/candidate-01.png \
  --no-texture-final outputs/S7-foreground-image/rimg-no-texture-final-01.png \
  --pptx
```

6. Patch PPTX display compatibility and export the SVG media:

```bash
python scripts/figure_studio_s8_svg_display_compat.py \
  --in outputs/S8-svg-ppt/s8-svg-ppt-delivery.pptx \
  --out outputs/S8-svg-ppt/s8-svg-ppt-delivery.pptx \
  --export-dir outputs/S8-svg-exported-icons \
  --backup-original outputs/S8-svg-exported-icons/s8-svg-ppt-delivery-svg-only-original.pptx \
  --report outputs/S8-svg-exported-icons/pptx-svg-display-compat-report.json
```

This step is required for robust PowerPoint/WPS display. A PPTX that only stores SVG as direct image relationships may pass package validation while showing blank or broken pictures in some viewers. The compatibility patch keeps the original SVG media, adds PNG fallback media, and rewrites slide pictures to use the Office `asvg:svgBlip` source relationship.

7. Validate SVG safety, PPTX self-containment, display compatibility, and the required slide order. Do not emit generated browser renderer HTML/JS as part of the delivery.
8. Print the execution report in the reply body and provide a download/artifact link to `outputs/S8-svg-ppt/s8-svg-ppt-delivery.pptx` plus a link to `outputs/S8-svg-exported-icons/`. In Codex/local environments, render actual local paths as Markdown file links when possible; in ChatGPT web, export/attach the PPTX artifact and show its download link. S8-SVG-PPT is not complete until these links are visible.

## PPTX

Required retained output:

```text
outputs/S8-svg-ppt/s8-svg-ppt-delivery.pptx
```

Slide order is mandatory:

1. grayscale S6-FINAL-SELECT selected final reference as the map page;
2. original S6-FINAL-SELECT selected final reference;
3. one or more pages containing movable, editable SVG icons / foreground elements grouped by semantic category.

Labels and filenames must be live PPT text. SVG media must be embedded in the PPTX package. For display compatibility, each embedded SVG picture should also have an internal PNG fallback and an `asvg:svgBlip` relationship back to the SVG media.

Retained support output:

```text
outputs/S8-svg-exported-icons/*.svg
outputs/S8-svg-exported-icons/png-fallbacks/*.png
outputs/S8-svg-exported-icons/pptx-svg-display-compat-report.json
```

The exported SVG directory is intentionally outside `outputs/S8-svg-ppt/` so `figure_studio_s8_clean_delivery.py finalize` can keep the PPTX-only delivery directory without hiding the reusable SVG files from the user.

## Native PPT Vector Layers

When the user asks for final manual PPT editing, individual layers, or direct editable vector objects, also generate:

```bash
python scripts/figure_studio_s8_native_ppt_layers.py \
  --project-root <project_run_root> \
  --reference-final outputs/S5-candidate-images/candidate-01.png \
  --out-dir outputs/S8-native-vector-layers
```

Retained output:

```text
outputs/S8-native-vector-layers/s8-native-vector-layers.pptx
outputs/S8-native-vector-layers/layer-manifest.json
```

This native layer PPT is separate from the SVG catalog PPTX. It uses PowerPoint-native primitive shapes with stable names such as `client_l.screen_outer` and `classifier_network.edge_01`, so users can edit strokes, fills, positions, and text directly in PowerPoint's Selection Pane. It is acceptable for the native layer version to be a clean schematic redrawing rather than a pixel-perfect SVG trace, as long as it preserves the S6/S7 foreground element semantics.

Completion reply must include:

- PPTX download/artifact link;
- retained output path: `outputs/S8-svg-ppt/s8-svg-ppt-delivery.pptx`;
- slide-order confirmation for the grayscale map page, original final reference page, and movable SVG icon pages;
- validation status for self-contained PPTX and safe SVG media.
- exported SVG directory and display-compatibility status, including SVG media count, PNG fallback count, and `svgBlip` count.
- native PPT vector layer link and layer count when generated.

Validation commands:

```bash
python scripts/figure_studio_validate_production_svg.py outputs/S8-svg-ppt/final.svg
python scripts/figure_studio_s8_clean_delivery.py validate --output-dir outputs/S8-svg-ppt
```

