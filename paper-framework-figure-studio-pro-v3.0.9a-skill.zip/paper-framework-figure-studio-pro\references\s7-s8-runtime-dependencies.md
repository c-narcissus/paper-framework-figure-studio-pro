# S7/S8 Runtime Dependencies

## Required

- Python 3.9 or newer.
- Standard library support is enough for S7-FOREGROUND-IMAGE contract generation.

## S8-SVG-PPT Optional Dependencies

Install these when foreground SVG catalog generation or PPT output is needed:

```bash
npm install pptxgenjs sharp image-size
python -m pip install lxml python-pptx pillow
```

- Node + pptxgenjs: `s8-svg-ppt-delivery.pptx`.
- sharp: grayscale textured-final reference generation and optional SVG preview rendering.
- image-size: aspect-ratio fitting for reference images.
- lxml or standard XML tooling: optional SVG validation helpers.
- python-pptx + Pillow: optional native PPT vector layer deck and reference image handling when the user wants final manual PPT editing.

## S8 Display Compatibility Dependencies

Run `scripts/figure_studio_s8_svg_display_compat.py` after the SVG catalog PPTX is created. It only needs Python standard-library modules for OOXML patching, but it needs one SVG-to-PNG renderer for fallback images:

- Preferred local renderer: Microsoft Edge, Google Chrome, or Chromium available on PATH or at the standard Windows install path. The script uses headless browser screenshots and leaves no browser HTML artifact in the delivery.
- Fallback renderer: `cairosvg`, only when native Cairo is installed and importable. Do not assume `pip install cairosvg` is enough on Windows; missing `cairo-2.dll` means browser rendering is required.

The display-compatibility output is:

```text
outputs/S8-svg-exported-icons/*.svg
outputs/S8-svg-exported-icons/png-fallbacks/*.png
outputs/S8-svg-exported-icons/s8-svg-ppt-delivery-svg-only-original.pptx
```

The canonical PPTX should contain SVG media, PNG fallback media, and `asvg:svgBlip` relationships. A PPTX with only direct SVG image relationships may pass internal package checks while still not rendering in PowerPoint/WPS.

If a PPTX-capable runtime is unavailable, S8-SVG-PPT cannot complete the required PPT delivery. Record the limitation in state and do not mark S8-SVG-PPT complete until the self-contained PPTX exists and embeds its SVG assets internally.

## Not Required

- No standalone web-preview pages.
- No browser automation is required for paper reading or figure design, but a browser renderer is preferred for S8 SVG display fallbacks.
- No Cairo/CairoSVG dependency is required when Edge/Chrome/Chromium is available.


