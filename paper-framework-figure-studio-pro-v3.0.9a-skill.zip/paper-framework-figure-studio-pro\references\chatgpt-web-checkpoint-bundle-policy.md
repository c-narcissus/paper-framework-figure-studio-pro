# ChatGPT Web Checkpoint Bundle Policy

This policy applies when the workflow runs in ChatGPT web and the assistant can create or attach files.

## Purpose

The checkpoint zip lets a user open a new ChatGPT conversation, upload one package, and resume from the recorded workflow state instead of starting from S0 again.

## Default Behavior

- Every text reply should provide a full resume checkpoint zip when file artifact creation is available.
- Prefer overwrite/latest semantics. Use one stable display filename:

```text
paper-framework-figure-studio-pro-full-checkpoint.zip
```

- If the platform supports overwriting an existing artifact path, overwrite the previous checkpoint.
- If the platform creates separate attachments or browser downloads with suffixes such as `(1)`, treat the newest package as authoritative by reading `checkpoint-manifest.json`.
- The checkpoint is not a workflow output. Store it outside `figure-studio-runs/<project_id>/` when a filesystem is available, for example:

```text
checkpoint-bundles/<project_id>/paper-framework-figure-studio-pro-full-checkpoint.zip
```

Do not place checkpoint zips inside `outputs/`, `state/`, or `inputs/`, and never include prior checkpoint zips inside a new checkpoint.

## Required Zip Structure

Use a single top-level folder:

```text
paper-framework-figure-studio-pro-resume-checkpoint/
  README_RESUME.md
  checkpoint-manifest.json
  checksums.sha256
  state/
    project-state.json
  inputs/
  outputs/
  skill-snapshot/
    SKILL.md
    VERSION
    metadata.json
    references/
    templates/
    scripts/
```

## Required Contents

- `state/project-state.json`: required. It is the workflow memory, current step, artifact index, epoch record, cleanup audit trail, and next-action source.
- `inputs/`: include the paper PDF, extracted raw text, LaTeX or Markdown sources, user notes, preference references, and any user-provided images needed to rerun or repair earlier steps.
- `outputs/`: include active workflow outputs needed to continue, inspect, repair, or move forward: reports, generated target-paper images, manifests, SVGs, PPTX files, validation reports, and S9 text.
- `skill-snapshot/`: include the exact skill rules used by the run, including references, templates, and scripts. This is required when the user may upload only the checkpoint zip to a new conversation.
- `README_RESUME.md`: give minimal restore instructions.
- `checkpoint-manifest.json`: machine-readable resume index.
- `checksums.sha256`: checksums for files in the zip except the checksum file itself.

## checkpoint-manifest.json Fields

Minimum fields:

```json
{
  "bundle_schema_version": 1,
  "bundle_kind": "full_resume_checkpoint",
  "checkpoint_filename": "paper-framework-figure-studio-pro-full-checkpoint.zip",
  "checkpoint_created_at": "ISO-8601 timestamp",
  "checkpoint_seq": 1,
  "project_id": "<project_id>",
  "skill_name": "paper-framework-figure-studio-pro",
  "skill_version": "<VERSION file value>",
  "current_step": "S0-PAPER-FOUNDATION",
  "last_completed_step": null,
  "state_path": "state/project-state.json",
  "active_artifact_roles": {},
  "active_artifact_paths": [],
  "pending_outputs": [],
  "included_roots": ["state", "inputs", "outputs", "skill-snapshot"],
  "excluded_patterns": [],
  "resume_instruction": "Read README_RESUME.md, then project-state.json, then continue from current_step using only active artifacts unless the user asks for historical inspection."
}
```

`checkpoint_seq` must increase when possible. If persistent sequence storage is unavailable, use `checkpoint_created_at` as the latest-checkpoint tie breaker.

## README_RESUME.md Content

The README must tell the next conversation to:

1. Read `checkpoint-manifest.json`.
2. Read `state/project-state.json`.
3. Determine the real next action from `current_step`, `workflow_plan`, `step_runs`, `active_artifact_roles`, and `next_recommended_action`.
4. Use `inputs/`, `outputs/`, and `skill-snapshot/` as the portable project context.
5. Do not rely on previous chat messages, stale file paths, or host-specific absolute paths.
6. Do not reuse stale or cleanup-invalidated outputs for execution. Historical inspection is allowed only when it does not write new outputs.

## Exclusions

Never include:

- API keys, tokens, credentials, passwords, or secrets.
- Host-specific absolute paths as authoritative resume paths.
- `__pycache__/`, `.pyc`, `node_modules/`, browser render temp files, generated HTML/JS preview files, operating-system trash, or previous checkpoint zips.
- Stale or cleanup-invalidated outputs as active resume inputs. If historical files are intentionally kept, place them under a clearly marked `history/` section and mark them non-executable in the manifest.

## User-Facing Reply Rule

In ChatGPT web text replies, include the checkpoint artifact link after the main answer, using language such as:

```text
Full resume checkpoint: paper-framework-figure-studio-pro-full-checkpoint.zip
```

If checkpoint creation is unavailable, state the limitation briefly and list the minimum files the user should preserve manually: `state/project-state.json`, `inputs/`, `outputs/`, and the current skill zip or `skill-snapshot/`.
