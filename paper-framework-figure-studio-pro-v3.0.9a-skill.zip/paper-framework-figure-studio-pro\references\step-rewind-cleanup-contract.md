# Step Rewind Cleanup Contract

Use this contract for free-form user requests, rollback, rerun, repair, and status jump operations. Always infer the real `target_step` and operation mode from the user's intent; do not depend on whether the user used explicit words such as rerun, execute, generate, overwrite, repair, or patch.

## Operation Modes

### Inspect Mode

Use inspect mode for status checks, file lookup, historical comparison, explanation, diagnostics, or validation that does not write or replace project outputs. Inspect mode does not delete outputs. The reply should state that no outputs/state were changed.

### Rebuild / Rerun / Progress Mode

Use rebuild, rerun, or progress mode when satisfying the request will create, advance, replace, regenerate, or re-export a workflow-stage artifact.

Before executing the target step, delete every product created by the covered step span from `target_step` through the previous `current_step`, inclusive. Then remove the covered active state records, record a cleanup event in `project-state.json`, and execute the target step.

### Repair / Patch Mode

Use repair or patch mode when the request fixes an existing artifact from the same `target_step`, such as a broken PPTX, missing fallback rendering, bad SVG packaging, or a malformed manifest.

Repair mode may read same-step existing output as repair input, but it must:

1. back up the same-step artifact before modifying it;
2. record a repair event in `project-state.json`;
3. complete validation after the repair;
4. update the target-step state;
5. delete every downstream output after `target_step`, because those outputs depended on the pre-repair artifact;
6. remove downstream active artifacts, image-generation events, pending outputs, and active artifact roles from state;
7. record the downstream cleanup reason, for example `downstream invalidated by repaired target_step artifact`.

## Input Boundary

During any execution or repair, the agent may read only:

- `inputs/`;
- skill package references, assets, and scripts;
- `state/project-state.json`;
- valid artifacts from steps before `target_step`;
- same-step repair inputs and backups when in repair mode.

Never read or reuse:

- artifacts from steps after `target_step`;
- artifacts marked stale, removed, or superseded by cleanup;
- old files from a mismatched epoch/attempt, except for pure historical inspection that writes no new outputs.

Never delete:

- `state/project-state.json`
- `state/`
- `inputs/`
- user source files
- skill package source files

Covered state records include active artifacts, image-generation events, pending outputs, and active artifact role mappings. Keep the cleanup event itself as the audit record.

Examples:

- Current `S6-FINAL-SELECT`, rerun `S4-CANDIDATE-BRIEF`: clean old `S4-CANDIDATE-BRIEF`, `S5-CANDIDATE-IMAGE`, and `S6-FINAL-SELECT` products and active records, then execute `S4-CANDIDATE-BRIEF`.
- Current `S8-SVG-PPT`, rerun `S7-FOREGROUND-IMAGE`: clean old `S7-FOREGROUND-IMAGE` and `S8-SVG-PPT` products and active records, then execute `S7-FOREGROUND-IMAGE`.
- Current `S5-CANDIDATE-IMAGE`, rerun `S5-CANDIDATE-IMAGE`: clean old `S5-CANDIDATE-IMAGE` products and active records, then execute it again.
- Current `S9-FIGURE-TEXT`, repair `S8-SVG-PPT`: back up the current S8 PPTX, repair and validate S8, then clean old `S9-FIGURE-TEXT` products and active records because the text may refer to the pre-repair S8 artifact.

If the user only asks to inspect or compare historical results, no cleanup is required.


