#!/usr/bin/env python3
"""Backward-compatible wrapper for S8 SVG display fallback patching.

Use figure_studio_s8_svg_display_compat.py for new workflows. This wrapper keeps
older commands working while avoiding a hard CairoSVG dependency.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from figure_studio_s8_svg_display_compat import main as compat_main  # noqa: E402


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--in", dest="infile", required=True)
    parser.add_argument("--out", dest="outfile", required=True)
    parser.add_argument("--export-dir")
    parser.add_argument("--backup-original")
    parser.add_argument("--renderer", choices=["auto", "browser", "cairosvg"], default="auto")
    parser.add_argument("--browser-path")
    parser.add_argument("--scale", type=float, default=4.0)
    parser.add_argument("--report")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args(argv)

    out_path = Path(args.outfile)
    export_dir = args.export_dir or str(out_path.parent.parent / "S8-svg-exported-icons")
    forwarded = [
        "--in",
        args.infile,
        "--out",
        args.outfile,
        "--export-dir",
        export_dir,
        "--renderer",
        args.renderer,
        "--scale",
        str(args.scale),
    ]
    if args.backup_original:
        forwarded.extend(["--backup-original", args.backup_original])
    if args.browser_path:
        forwarded.extend(["--browser-path", args.browser_path])
    if args.report:
        forwarded.extend(["--report", args.report])
    if args.json:
        forwarded.append("--json")
    return compat_main(forwarded)


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
