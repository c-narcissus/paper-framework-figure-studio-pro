"""Stable public constants and schema values."""

from __future__ import annotations

from pathlib import Path
import re

SKILL_NAME = "paper-framework-figure-studio-pro"
SKILL_VERSION = "3.0.9a-architecture-governance"
SCHEMA_VERSION = 1
DEFAULT_ROOT = "figure-studio-runs"
STATE_RELATIVE_PATH = Path("state") / "project-state.json"

PREFERENCE_REFERENCE_ROOT = "inputs/preference-reference-images"
PREFERENCE_ANALYSIS_PATH = "outputs/S0-paper-foundation/preference-reference-analysis.md"

SAFE_PROJECT_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,79}$")
SECRET_KEY_RE = re.compile(r"(api[_-]?key|token|secret|password|credential)", re.I)

REFERENCE_IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".webp"}
RUNTIME_ENVIRONMENTS = {"unknown", "chatgpt_web", "codex", "claude_code", "other"}
IMAGE_GENERATION_ROUTES = {
    "unknown",
    "chatgpt_create_image",
    "codex_imagegen",
    "approved_image_api",
    "user_supplied_api_required",
    "prompt_only",
}

S7_FOREGROUND_BATCH_ID = "s7-foreground-only"
S7_FOREGROUND_CANONICAL_FILENAMES = (
    "rimg-no-texture-final-01.png",
)
S7_FOREGROUND_REQUIRED_PREFIXES = (
    "rimg-no-texture-final-",
)
S7_FOREGROUND_REQUIRED_ROLE_IDS = (
    "s7.foreground_only_final",
)

WORKFLOW_STEPS = [
    ("S0-PAPER-FOUNDATION", "TEXT_ONLY", "论文精读底座：建立项目状态、环境、材料、默认 16:9 可修改画幅和偏好参考范围；简单短描述只做轻量澄清；PDF/LaTeX/完整论文/report/supplement/完整方法说明/详细描述必须产出丰富、详细、准确的论文精读报告，覆盖算法、方法、模型、公式、输入输出、术语、箭头关系和图形含义锚点；偏好参考仅供 S1-FIGURE-STRATEGY 类型建议", "outputs/S0-paper-foundation"),
    ("S1-FIGURE-STRATEGY", "TEXT_ONLY", "材料精读、图类型需求诊断和初稿结构诊断；用户风格参考只可辅助类型/读者效果建议", "outputs/S1-figure-strategy"),
    ("S2-SKETCH-EXPLORE", "IMAGE_ONLY_PLUS_PROMPT", "全局探索过程低保真方向草图，默认且至少 6 个、最多 8 个；更发散，关注不同视觉抓手、分类角度和第一眼吸引力；必须从论文精读中提炼 figure layer 主线，少文字公式、大图标、矢量优先、逐张单独生成；上传风格参考不自动传递到这里；末尾只附下一步提示", "outputs/S2-sketch-explore"),
    ("S3-DIRECTION-SELECT", "TEXT_ONLY", "全局探索过程收束：压缩论文逻辑，筛出可进入局部细化的发散结构方向；关注夺眼球、不同维度发散、读者第一眼兴趣，以及不违背论文事实的结构重组机会", "outputs/S3-direction-selection"),
    ("S4-CANDIDATE-BRIEF", "TEXT_ONLY", "局部细化过程准备：基于论文和精读报告生成正式候选矩阵设置、逐候选主题元素清单、figure-vs-caption 分工、语义密度预算、总覆盖核对、非违背式重组说明与 prompts；默认 2x3，可按用户修改的矩阵规格执行", "outputs/S4-candidate-brief"),
    ("S5-CANDIDATE-IMAGE", "IMAGE_ONLY_PLUS_PROMPT", "局部细化过程正式 paper-framework candidates，默认 16:9、默认 6 个 2x3 或用户修改矩阵，最多 8 个；必须按环境使用 Image Gen/Create Image/approved image API 逐张单独生成；必须不违背论文和精读报告，可采用更清楚的组织方式，关注精准、局部细节展示和后续 SVG/PPT 矢量化可实现性，避免文字公式符号和小图标堆料，不做海报/PPT 堆料页；末尾只附下一步提示", "outputs/S5-candidate-images"),
    ("S6-FINAL-SELECT", "TEXT_ONLY", "局部细化评审和最终选择：从 S5-CANDIDATE-IMAGE 候选中选出最终架构图，打印论文精读核对、figure-vs-caption 分工、SVG/PPT 可绘制性、非违背式重组/写作建议、选择理由和 S7-FOREGROUND-IMAGE handoff", "outputs/S6-final-selection"),
    ("S7-FOREGROUND-IMAGE", "IMAGE_ONLY_PLUS_PROMPT_WITH_MANIFEST", "从 S6-FINAL-SELECT 选中的最终架构图和主题元素清单生成一张或多张 foreground-only 无底纹元素集合图；去掉底纹、边框、外框、分区框、格线、连接线、箭头、箭头头、文字、标题和说明，只保留可复用前景图元；布局利于 SVG 提取；图像后只附下一步提示", "outputs/S7-foreground-image"),
    ("S8-SVG-PPT", "SVG_PPTX_ARTIFACTS", "从 S7-FOREGROUND-IMAGE foreground-only 无底纹元素集合图分割/重绘可复用元素为 SVG 并封装自包含 PPTX；第一页为 S6-FINAL-SELECT 选中最终架构图灰度图作为地图，第二页为原图，后续页为可移动可编辑 SVG 图标/前景图元列表；完成回复必须提供 PPTX 下载/产物链接；不能用一张新图片或概念说明替代", "outputs/S8-svg-ppt"),
    ("S9-FIGURE-TEXT", "TEXT_ONLY", "caption、legend 和论文正文引用文字", "outputs/S9-figure-text"),
]

STEP_OUTPUT_DIRS = {step: output_dir for step, _, _, output_dir in WORKFLOW_STEPS}
STEP_SEQUENCE = tuple(step for step, _, _, _ in WORKFLOW_STEPS)
DEFAULT_NEXT_STEP_BY_STEP = {
    step: STEP_SEQUENCE[index + 1] if index + 1 < len(STEP_SEQUENCE) else None
    for index, step in enumerate(STEP_SEQUENCE)
}
TEXT_REPLY_STEP_BANNER_TEMPLATE = (
    "当前流程位置\n"
    "全流程：S0-PAPER-FOUNDATION -> S1-FIGURE-STRATEGY -> S2-SKETCH-EXPLORE -> S3-DIRECTION-SELECT -> S4-CANDIDATE-BRIEF -> S5-CANDIDATE-IMAGE -> "
    "S6-FINAL-SELECT -> S7-FOREGROUND-IMAGE -> S8-SVG-PPT -> S9-FIGURE-TEXT\n"
    "当前 step：{current_step}\n"
    "默认下一步：{default_next_step}"
)
STEP_CLEANUP_EXTRA_DIRS = {}
STEP_CLEANUP_EXTRA_FILES = {}

# Single source of truth for stable workflow products. Scripts may infer a role
# from path, but new records should store artifact_role explicitly.
ARTIFACT_ROLES = {
    "s0.paper_foundation_report": {
        "step": "S0-PAPER-FOUNDATION",
        "kind": "markdown",
        "relative_path": "outputs/S0-paper-foundation/paper-foundation-report.md",
    },
    "s1.figure_strategy": {
        "step": "S1-FIGURE-STRATEGY",
        "kind": "markdown",
        "relative_path": "outputs/S1-figure-strategy/figure-strategy-brief.md",
    },
    "s2.primary_sketch": {
        "step": "S2-SKETCH-EXPLORE",
        "kind": "image",
        "relative_path": "outputs/S2-sketch-explore/sketch-01.png",
    },
    "s3.direction_selection": {
        "step": "S3-DIRECTION-SELECT",
        "kind": "markdown",
        "relative_path": "outputs/S3-direction-selection/direction-selection.md",
    },
    "s4.candidate_brief": {
        "step": "S4-CANDIDATE-BRIEF",
        "kind": "markdown",
        "relative_path": "outputs/S4-candidate-brief/candidate-board-brief.md",
    },
    "s5.primary_candidate": {
        "step": "S5-CANDIDATE-IMAGE",
        "kind": "image",
        "relative_path": "outputs/S5-candidate-images/candidate-01.png",
    },
    "s6.final_selection": {
        "step": "S6-FINAL-SELECT",
        "kind": "markdown",
        "relative_path": "outputs/S6-final-selection/final-selection-report.md",
    },
    "s6.selected_reference_final": {
        "step": "S6-FINAL-SELECT",
        "kind": "image",
        "relative_path": "outputs/S5-candidate-images/candidate-01.png",
    },
    "s7.foreground_only_final": {
        "step": "S7-FOREGROUND-IMAGE",
        "kind": "image",
        "relative_path": "outputs/S7-foreground-image/rimg-no-texture-final-01.png",
    },
    "s7.foreground_manifest": {
        "step": "S7-FOREGROUND-IMAGE",
        "kind": "json",
        "relative_path": "outputs/S7-foreground-image/foreground-only-manifest.json",
    },
    "s8.delivery_pptx": {
        "step": "S8-SVG-PPT",
        "kind": "pptx",
        "relative_path": "outputs/S8-svg-ppt/s8-svg-ppt-delivery.pptx",
    },
    "s9.caption_legend": {
        "step": "S9-FIGURE-TEXT",
        "kind": "markdown",
        "relative_path": "outputs/S9-figure-text/caption-legend.md",
    },
}

PRIMARY_ARTIFACT_ROLE_BY_STEP = {
    "S0-PAPER-FOUNDATION": "s0.paper_foundation_report",
    "S1-FIGURE-STRATEGY": "s1.figure_strategy",
    "S2-SKETCH-EXPLORE": "s2.primary_sketch",
    "S3-DIRECTION-SELECT": "s3.direction_selection",
    "S4-CANDIDATE-BRIEF": "s4.candidate_brief",
    "S5-CANDIDATE-IMAGE": "s5.primary_candidate",
    "S6-FINAL-SELECT": "s6.final_selection",
    "S7-FOREGROUND-IMAGE": "s7.foreground_only_final",
    "S8-SVG-PPT": "s8.delivery_pptx",
    "S9-FIGURE-TEXT": "s9.caption_legend",
}

CANONICAL_OUTPUTS = {
    step: ARTIFACT_ROLES[role]["relative_path"] for step, role in PRIMARY_ARTIFACT_ROLE_BY_STEP.items()
}

S7_PACKAGE_ROLE_IDS = [
    "s7.foreground_only_final",
    "s7.foreground_manifest",
]

S8_PACKAGE_ROLE_IDS = [
    "s8.delivery_pptx",
]


def _pending_row(role_id: str) -> dict[str, str]:
    role = ARTIFACT_ROLES[role_id]
    return {"step": role["step"], "relative_path": role["relative_path"], "artifact_role": role_id}


S7_CANONICAL_PACKAGE_OUTPUTS = [_pending_row(role_id) for role_id in S7_PACKAGE_ROLE_IDS]
S8_CANONICAL_OUTPUTS = [_pending_row(role_id) for role_id in S8_PACKAGE_ROLE_IDS]

PENDING_CANONICAL_OUTPUTS = []
for _step, _, _, _ in WORKFLOW_STEPS:
    if _step == "S7-FOREGROUND-IMAGE":
        PENDING_CANONICAL_OUTPUTS.extend(S7_CANONICAL_PACKAGE_OUTPUTS)
    elif _step == "S8-SVG-PPT":
        PENDING_CANONICAL_OUTPUTS.extend(S8_CANONICAL_OUTPUTS)
    else:
        _role_id = PRIMARY_ARTIFACT_ROLE_BY_STEP[_step]
        PENDING_CANONICAL_OUTPUTS.append(_pending_row(_role_id))

TEXT_ONLY_STEPS = {step for step, mode, _, _ in WORKFLOW_STEPS if mode.startswith("TEXT_ONLY")}
IMAGE_ONLY_STEPS = {step for step, mode, _, _ in WORKFLOW_STEPS if mode.startswith("IMAGE_ONLY")}

ATLAS_BOARD_ROOT = "assets/subtype-atlas/boards"
ATLAS_THUMBNAIL_ROOT = "assets/subtype-atlas/thumbnails"
ATLAS_MANIFEST_PATH = "assets/subtype-atlas/manifest.json"
ATLAS_BOARD_IDS = (
    "subtype-overview",
    "visual-grammar-layout",
    "reader-role-detail",
    "visual-communication-styles",
)
ATLAS_DISPLAY_POLICY = (
    "Whenever a reply mentions subtype/category atlas boards, layout grammar, visual communication styles, "
    "reader-role detail, or subtype overview, embed the corresponding saved PNG board with Markdown. "
    "Do not build generated web pages in any environment, including Codex."
)



