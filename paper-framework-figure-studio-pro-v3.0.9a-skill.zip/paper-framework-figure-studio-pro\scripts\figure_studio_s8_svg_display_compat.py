#!/usr/bin/env python3
"""Export S8 PPTX SVG media and patch display-compatible PNG fallbacks.

PowerPoint-like viewers vary in how they render SVG-only image relationships.
This script keeps SVG media embedded, but rewrites slide pictures to use a PNG
fallback for display and an Office asvg:svgBlip extension pointing back to the
original SVG source.
"""

from __future__ import annotations

import argparse
import json
import os
import posixpath
import re
import shutil
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET


P_NS = "http://schemas.openxmlformats.org/presentationml/2006/main"
A_NS = "http://schemas.openxmlformats.org/drawingml/2006/main"
R_NS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
REL_NS = "http://schemas.openxmlformats.org/package/2006/relationships"
CT_NS = "http://schemas.openxmlformats.org/package/2006/content-types"
ASVG_NS = "http://schemas.microsoft.com/office/drawing/2016/SVG/main"

ET.register_namespace("p", P_NS)
ET.register_namespace("a", A_NS)
ET.register_namespace("r", R_NS)
ET.register_namespace("asvg", ASVG_NS)
ET.register_namespace("", REL_NS)


def qn(ns: str, tag: str) -> str:
    return f"{{{ns}}}{tag}"


def rels_for_slide(slide_name: str) -> str:
    base = posixpath.basename(slide_name)
    return posixpath.dirname(slide_name) + "/_rels/" + base + ".rels"


def resolve_target(rels_name: str, target: str) -> str:
    if target.startswith("/"):
        return target.lstrip("/")
    rel_dir = posixpath.dirname(rels_name)
    base = posixpath.dirname(rel_dir) if rel_dir.endswith("/_rels") else rel_dir
    return posixpath.normpath(posixpath.join(base, target))


def parse_rels(data: bytes) -> tuple[ET.Element, dict[str, str]]:
    root = ET.fromstring(data)
    rels: dict[str, str] = {}
    for rel in root:
        rid = rel.attrib.get("Id")
        target = rel.attrib.get("Target")
        if rid and target:
            rels[rid] = target
    return root, rels


def next_rid(rels_root: ET.Element) -> str:
    max_id = 0
    for rel in rels_root:
        rid = rel.attrib.get("Id", "")
        if rid.startswith("rId") and rid[3:].isdigit():
            max_id = max(max_id, int(rid[3:]))
    return f"rId{max_id + 1}"


def ensure_content_type(xml_bytes: bytes, extension: str, content_type: str) -> bytes:
    root = ET.fromstring(xml_bytes)
    for child in root:
        if child.tag == qn(CT_NS, "Default") and child.attrib.get("Extension") == extension:
            return xml_bytes
    ET.SubElement(root, qn(CT_NS, "Default"), {"Extension": extension, "ContentType": content_type})
    return ET.tostring(root, encoding="utf-8", xml_declaration=True)


def svg_viewbox_size(svg_text: str, scale: float) -> tuple[int, int]:
    match = re.search(r'viewBox=["\']\s*[-\d.]+\s+[-\d.]+\s+([\d.]+)\s+([\d.]+)', svg_text)
    if not match:
        return int(512 * scale), int(512 * scale)
    width = max(128, int(float(match.group(1)) * scale))
    height = max(128, int(float(match.group(2)) * scale))
    longest = max(width, height)
    if longest > 2400:
        ratio = 2400 / longest
        width = int(width * ratio)
        height = int(height * ratio)
    return width, height


def browser_candidates(explicit: str | None) -> list[Path]:
    raw: list[str] = []
    if explicit:
        raw.append(explicit)
    raw.extend(
        [
            shutil.which("msedge") or "",
            shutil.which("chrome") or "",
            shutil.which("google-chrome") or "",
            shutil.which("chromium") or "",
            r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
            r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
            r"C:\Program Files\Google\Chrome\Application\chrome.exe",
            r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
        ]
    )
    out = []
    for item in raw:
        if not item:
            continue
        path = Path(item)
        if path.exists() and path not in out:
            out.append(path)
    return out


def render_with_browser(svg_path: Path, png_path: Path, browser: Path, scale: float) -> dict:
    svg_text = svg_path.read_text(encoding="utf-8", errors="replace")
    width, height = svg_viewbox_size(svg_text, scale)
    with tempfile.TemporaryDirectory() as td:
        html_path = Path(td) / "render.html"
        html_path.write_text(
            "\n".join(
                [
                    "<!doctype html>",
                    "<html><head><meta charset='utf-8'>",
                    "<style>html,body{margin:0;width:100%;height:100%;background:white;overflow:hidden}svg{display:block;width:100vw;height:100vh}</style>",
                    "</head><body>",
                    svg_text,
                    "</body></html>",
                ]
            ),
            encoding="utf-8",
        )
        cmd = [
            str(browser),
            "--headless=new",
            "--disable-gpu",
            "--no-sandbox",
            "--hide-scrollbars",
            f"--window-size={width},{height}",
            f"--screenshot={png_path}",
            html_path.as_uri(),
        ]
        result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=45)
        if result.returncode != 0 or not png_path.exists():
            raise RuntimeError(f"browser render failed for {svg_path.name}: {result.stderr or result.stdout}")
    return {"svg": svg_path.name, "png": png_path.name, "width": width, "height": height, "renderer": str(browser)}


def render_with_cairosvg(svg_path: Path, png_path: Path, scale: float) -> dict:
    try:
        import cairosvg  # type: ignore
    except Exception as exc:
        raise RuntimeError(f"cairosvg is unavailable: {exc}") from exc
    svg_text = svg_path.read_text(encoding="utf-8", errors="replace")
    width, height = svg_viewbox_size(svg_text, scale)
    cairosvg.svg2png(bytestring=svg_text.encode("utf-8"), write_to=str(png_path), output_width=width, output_height=height)
    return {"svg": svg_path.name, "png": png_path.name, "width": width, "height": height, "renderer": "cairosvg"}


def render_svg(svg_path: Path, png_path: Path, args: argparse.Namespace) -> dict:
    if args.renderer in {"auto", "browser"}:
        browsers = browser_candidates(args.browser_path)
        if browsers:
            return render_with_browser(svg_path, png_path, browsers[0], args.scale)
        if args.renderer == "browser":
            raise RuntimeError("No Edge/Chrome/Chromium browser found for SVG fallback rendering.")
    if args.renderer in {"auto", "cairosvg"}:
        return render_with_cairosvg(svg_path, png_path, args.scale)
    raise RuntimeError("No SVG renderer available. Install Edge/Chrome/Chromium or cairosvg with native cairo.")


def read_pptx(path: Path) -> dict[str, bytes]:
    with zipfile.ZipFile(path, "r") as zin:
        return {name: zin.read(name) for name in zin.namelist()}


def write_pptx(path: Path, files: dict[str, bytes]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED) as zout:
        for name, data in files.items():
            zout.writestr(name, data)


def export_svg_media(files: dict[str, bytes], export_dir: Path) -> list[str]:
    export_dir.mkdir(parents=True, exist_ok=True)
    svg_media = sorted(name for name in files if name.startswith("ppt/media/") and name.lower().endswith(".svg"))
    for name in svg_media:
        (export_dir / Path(name).name).write_bytes(files[name])
    return svg_media


def create_png_fallbacks(svg_media: list[str], export_dir: Path, png_dir: Path, args: argparse.Namespace) -> list[dict]:
    png_dir.mkdir(parents=True, exist_ok=True)
    rendered = []
    for media_name in svg_media:
        svg_path = export_dir / Path(media_name).name
        png_path = png_dir / f"{Path(media_name).stem}.png"
        rendered.append(render_svg(svg_path, png_path, args))
    return rendered


def patch_slide_pictures(files: dict[str, bytes], svg_media: list[str], png_dir: Path) -> list[dict]:
    files["[Content_Types].xml"] = ensure_content_type(files["[Content_Types].xml"], "png", "image/png")
    files["[Content_Types].xml"] = ensure_content_type(files["[Content_Types].xml"], "svg", "image/svg+xml")
    svg_set = set(svg_media)
    for media_name in svg_media:
        png_name = f"ppt/media/{Path(media_name).stem}.png"
        files[png_name] = (png_dir / f"{Path(media_name).stem}.png").read_bytes()

    replacements = []
    slide_names = sorted(
        [name for name in files if re.fullmatch(r"ppt/slides/slide\d+\.xml", name)],
        key=lambda name: int(re.search(r"\d+", Path(name).stem).group(0)),
    )
    for slide_name in slide_names:
        rels_name = rels_for_slide(slide_name)
        if rels_name not in files:
            continue
        rels_root, rels = parse_rels(files[rels_name])
        slide_root = ET.fromstring(files[slide_name])
        changed = False
        for pic in slide_root.findall(f".//{{{P_NS}}}pic"):
            blip = pic.find(f".//{{{A_NS}}}blip")
            if blip is None:
                continue
            fallback_rid = blip.attrib.get(qn(R_NS, "embed"))
            if not fallback_rid or fallback_rid not in rels:
                continue
            ext_lst = blip.find(qn(A_NS, "extLst"))
            existing_svg_blip = pic.find(f".//{{{ASVG_NS}}}svgBlip")
            if existing_svg_blip is not None:
                svg_rid = existing_svg_blip.attrib.get(qn(R_NS, "embed"))
                if not svg_rid or svg_rid not in rels:
                    continue
                svg_target = resolve_target(rels_name, rels[svg_rid])
            else:
                svg_rid = fallback_rid
                svg_target = resolve_target(rels_name, rels[fallback_rid])
            if svg_target not in svg_set:
                continue
            png_target = f"../media/{Path(svg_target).stem}.png"
            if existing_svg_blip is None:
                new_rid = next_rid(rels_root)
                ET.SubElement(
                    rels_root,
                    qn(REL_NS, "Relationship"),
                    {
                        "Id": new_rid,
                        "Type": "http://schemas.openxmlformats.org/officeDocument/2006/relationships/image",
                        "Target": png_target,
                    },
                )
                blip.set(qn(R_NS, "embed"), new_rid)
                if ext_lst is None:
                    ext_lst = ET.SubElement(blip, qn(A_NS, "extLst"))
                ext = ET.SubElement(ext_lst, qn(A_NS, "ext"), {"uri": "{96DAC541-7B7A-43D3-8B79-37D633B846F1}"})
                ET.SubElement(ext, qn(ASVG_NS, "svgBlip"), {qn(R_NS, "embed"): svg_rid})
                fallback_target = posixpath.normpath(posixpath.join("ppt/slides", png_target))
            else:
                fallback_target = resolve_target(rels_name, rels[fallback_rid])
                files[fallback_target] = files[f"ppt/media/{Path(svg_target).stem}.png"]
            replacements.append({"slide": slide_name, "svg": svg_target, "fallback_png": fallback_target})
            changed = True
        if changed:
            files[slide_name] = ET.tostring(slide_root, encoding="utf-8", xml_declaration=True)
            files[rels_name] = ET.tostring(rels_root, encoding="utf-8", xml_declaration=True)
    return replacements


def validate_pptx(path: Path) -> dict:
    with zipfile.ZipFile(path, "r") as zf:
        names = set(zf.namelist())
        slide_count = len([name for name in names if re.fullmatch(r"ppt/slides/slide\d+\.xml", name)])
        svg_media = sorted(name for name in names if name.startswith("ppt/media/") and name.lower().endswith(".svg"))
        png_fallbacks = sorted(name for name in names if name.startswith("ppt/media/") and name.lower().endswith(".png"))
        svg_blip_count = 0
        external = []
        missing = []
        untitled_svg = []
        for name in svg_media:
            if "<title" not in zf.read(name).decode("utf-8", errors="replace").lower():
                untitled_svg.append(name)
        for name in names:
            if re.fullmatch(r"ppt/slides/slide\d+\.xml", name):
                svg_blip_count += zf.read(name).decode("utf-8", errors="replace").count("svgBlip")
            if not name.endswith(".rels"):
                continue
            text = zf.read(name).decode("utf-8", errors="replace")
            if 'TargetMode="External"' in text:
                external.append(name)
            for target in re.findall(r'Target="([^"]+)"', text):
                if "://" in target or target.startswith("file:"):
                    external.append(f"{name}:{target}")
                    continue
                if target.startswith("/"):
                    resolved = target.lstrip("/")
                else:
                    rel_dir = posixpath.dirname(name)
                    base = posixpath.dirname(rel_dir) if rel_dir.endswith("/_rels") else rel_dir
                    resolved = posixpath.normpath(posixpath.join(base, target))
                if resolved.startswith("ppt/") and resolved not in names:
                    missing.append(f"{name}:{target}")
        return {
            "slide_count": slide_count,
            "svg_media_count": len(svg_media),
            "png_fallback_count": len(png_fallbacks),
            "svg_blip_count": svg_blip_count,
            "external_relationships": external,
            "missing_internal_targets": missing,
            "untitled_svg_entries": untitled_svg,
            "ok": not external and not missing and not untitled_svg and len(svg_media) > 0 and len(png_fallbacks) > 0 and svg_blip_count > 0,
        }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--in", dest="infile", required=True, type=Path)
    parser.add_argument("--out", dest="outfile", type=Path)
    parser.add_argument("--export-dir", required=True, type=Path)
    parser.add_argument("--renderer", choices=["auto", "browser", "cairosvg"], default="auto")
    parser.add_argument("--browser-path")
    parser.add_argument("--scale", type=float, default=4.0)
    parser.add_argument("--backup-original", type=Path)
    parser.add_argument("--report", type=Path)
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args(argv)

    infile = args.infile.resolve()
    outfile = (args.outfile or args.infile).resolve()
    export_dir = args.export_dir.resolve()
    png_dir = export_dir / "png-fallbacks"
    if not infile.is_file():
        raise SystemExit(f"missing input PPTX: {infile}")
    if args.backup_original:
        backup = args.backup_original.resolve()
        backup.parent.mkdir(parents=True, exist_ok=True)
        if not backup.exists():
            shutil.copy2(infile, backup)

    files = read_pptx(infile)
    svg_media = export_svg_media(files, export_dir)
    if not svg_media:
        raise SystemExit("input PPTX contains no ppt/media/*.svg entries to export or patch")
    rendered = create_png_fallbacks(svg_media, export_dir, png_dir, args)
    replacements = patch_slide_pictures(files, svg_media, png_dir)
    if not replacements:
        raise SystemExit("no slide picture SVG relationships were found to patch")
    write_pptx(outfile, files)
    validation = validate_pptx(outfile)
    result = {
        "status": "completed" if validation["ok"] else "failed",
        "input_pptx": str(infile),
        "output_pptx": str(outfile),
        "export_dir": str(export_dir),
        "png_fallback_dir": str(png_dir),
        "svg_export_count": len(svg_media),
        "png_render_count": len(rendered),
        "patched_picture_count": len(replacements),
        "rendered": rendered,
        "replacements": replacements,
        "validation": validation,
    }
    if args.report:
        report_path = args.report.resolve()
        report_path.parent.mkdir(parents=True, exist_ok=True)
        report_path.write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    if args.json:
        print(json.dumps(result, indent=2, ensure_ascii=False))
    else:
        print(f"S8 SVG display compatibility patch: {result['status']}")
        print(f"- exported SVG: {len(svg_media)}")
        print(f"- rendered PNG fallbacks: {len(rendered)}")
        print(f"- patched pictures: {len(replacements)}")
        print(f"- output: {outfile}")
    return 0 if validation["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
