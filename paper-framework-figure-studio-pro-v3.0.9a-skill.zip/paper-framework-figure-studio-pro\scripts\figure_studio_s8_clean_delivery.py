"""Validate and finalize S8-SVG-PPT self-contained PPT delivery outputs.

This helper enforces the lightweight S8-SVG-PPT retention contract:
after a successful delivery, the S8-SVG-PPT output directory keeps only the
delivery PPTX. All glyph crops, generated SVGs, reports, manifests, indexes,
and archives are transient and should be recorded in state as cleaned/unavailable
rather than retained as final deliverables.
"""

from __future__ import annotations

import argparse
import json
import posixpath
import shutil
import zipfile
from pathlib import Path


DEFAULT_PPTX = "s8-svg-ppt-delivery.pptx"


def count_pptx_slides(path: Path) -> int:
    with zipfile.ZipFile(path, "r") as zf:
        return len(
            [
                name
                for name in zf.namelist()
                if name.startswith("ppt/slides/slide") and name.endswith(".xml")
            ]
        )


def pptx_relationship_targets(path: Path) -> tuple[list[str], list[str], list[str], list[str], list[str], int]:
    with zipfile.ZipFile(path, "r") as zf:
        names = set(zf.namelist())
        svg_entries = sorted(
            name for name in names if name.startswith("ppt/media/") and name.lower().endswith(".svg")
        )
        png_fallback_entries = sorted(
            name for name in names if name.startswith("ppt/media/") and name.lower().endswith(".png")
        )
        svg_blip_count = sum(
            zf.read(name).decode("utf-8", errors="replace").count("svgBlip")
            for name in names
            if name.startswith("ppt/slides/slide") and name.endswith(".xml")
        )
        missing_internal_targets: list[str] = []
        external_targets: list[str] = []
        untitled_svg_entries: list[str] = []
        for name in names:
            if not name.endswith(".rels"):
                continue
            rel_dir = Path(name).parent
            rels_text = zf.read(name).decode("utf-8", errors="replace")
            if 'TargetMode="External"' in rels_text:
                external_targets.append(name)
            for target in rels_text.split("Target=\"")[1:]:
                target_text = target.split("\"", 1)[0]
                if "://" in target_text or target_text.startswith("file:"):
                    external_targets.append(f"{name}:{target_text}")
                    continue
                if target_text.startswith("/"):
                    target_path = target_text.lstrip("/")
                else:
                    if rel_dir.name == "_rels":
                        base = rel_dir.parent
                    else:
                        base = rel_dir
                    target_path = posixpath.normpath(str((base / target_text).as_posix()))
                if target_path.startswith("../") or target_path == ".":
                    continue
                if target_path.startswith("ppt/") and target_path not in names:
                    missing_internal_targets.append(f"{name}:{target_text}")
        for svg_entry in svg_entries:
            svg_text = zf.read(svg_entry).decode("utf-8", errors="replace").lower()
            if "<title" not in svg_text:
                untitled_svg_entries.append(svg_entry)
        return svg_entries, png_fallback_entries, sorted(set(external_targets)), sorted(set(missing_internal_targets)), untitled_svg_entries, svg_blip_count


def assert_child(parent: Path, child: Path) -> None:
    parent_resolved = parent.resolve()
    child_resolved = child.resolve()
    if child_resolved != parent_resolved and parent_resolved not in child_resolved.parents:
        raise SystemExit(f"Refusing to touch path outside output dir: {child}")


def validate_delivery(output_dir: Path, pptx_name: str) -> dict:
    pptx = output_dir / pptx_name
    errors: list[str] = []
    if not pptx.is_file():
        errors.append(f"missing delivery PPTX: {pptx_name}")
        slide_count = 0
        svg_entries = []
        png_fallback_entries = []
        svg_blip_count = 0
        external_targets = []
        missing_internal_targets = []
        untitled_svg_entries = []
    else:
        try:
            slide_count = count_pptx_slides(pptx)
            if slide_count < 4:
                errors.append(f"PPTX must contain at least 4 slides; found {slide_count}")
            svg_entries, png_fallback_entries, external_targets, missing_internal_targets, untitled_svg_entries, svg_blip_count = pptx_relationship_targets(pptx)
            if not svg_entries:
                errors.append("PPTX must embed SVG icons internally under ppt/media/*.svg; found none")
            if external_targets:
                errors.append("PPTX contains external relationships; all SVG/media must be embedded")
            if missing_internal_targets:
                errors.append("PPTX contains relationships to missing internal targets")
            if untitled_svg_entries:
                errors.append("Embedded SVG icons must include <title> metadata derived from the original glyph label")
        except zipfile.BadZipFile:
            slide_count = 0
            svg_entries = []
            png_fallback_entries = []
            svg_blip_count = 0
            external_targets = []
            missing_internal_targets = []
            untitled_svg_entries = []
            errors.append(f"PPTX is not a valid zip container: {pptx_name}")
    return {
        "ok": not errors,
        "errors": errors,
        "output_dir": str(output_dir),
        "delivery_pptx": pptx_name,
        "pptx_slide_count": slide_count,
        "embedded_svg_count": len(svg_entries),
        "embedded_svg_entries": svg_entries,
        "png_fallback_count": len(png_fallback_entries),
        "png_fallback_entries": png_fallback_entries,
        "svg_blip_count": svg_blip_count,
        "external_relationships": external_targets,
        "missing_internal_targets": missing_internal_targets,
        "untitled_svg_entries": untitled_svg_entries,
    }


def clean_intermediates(output_dir: Path, keep_names: set[str]) -> list[str]:
    deleted: list[str] = []
    output_dir.mkdir(parents=True, exist_ok=True)
    for child in output_dir.iterdir():
        if child.name in keep_names:
            continue
        assert_child(output_dir, child)
        if child.is_dir():
            shutil.rmtree(child)
        else:
            child.unlink()
        deleted.append(child.name)
    return sorted(deleted)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=["validate", "finalize"])
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--pptx-name", default=DEFAULT_PPTX)
    parser.add_argument("--json", action="store_true", help="Print machine-readable JSON.")
    args = parser.parse_args()

    output_dir = args.output_dir.resolve()
    result = validate_delivery(output_dir, args.pptx_name)
    if args.mode == "finalize" and result["ok"]:
        result["deleted_intermediates"] = clean_intermediates(
            output_dir, {args.pptx_name}
        )
        result = {**result, **validate_delivery(output_dir, args.pptx_name)}

    if args.json:
        print(json.dumps(result, indent=2, ensure_ascii=False))
    else:
        status = "ok" if result["ok"] else "failed"
        print(f"S8-SVG-PPT delivery validation: {status}")
        for error in result["errors"]:
            print(f"- {error}")
        print(f"- slides: {result['pptx_slide_count']}")
        print(f"- embedded svg files: {result['embedded_svg_count']}")
        print(f"- png fallback files: {result['png_fallback_count']}")
        print(f"- svgBlip relationships: {result['svg_blip_count']}")
        for name in result.get("deleted_intermediates", []):
            print(f"- deleted transient: {name}")
    return 0 if result["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())

