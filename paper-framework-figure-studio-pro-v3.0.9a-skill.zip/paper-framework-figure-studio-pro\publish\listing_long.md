# paper-framework-figure-studio-pro v3.0.9a

Publication-oriented framework-figure workflow for computer-science papers.

Core route:

```text
S0-PAPER-FOUNDATION -> S1-FIGURE-STRATEGY -> S2-SKETCH-EXPLORE -> S3-DIRECTION-SELECT -> S4-CANDIDATE-BRIEF -> S5-CANDIDATE-IMAGE -> S6-FINAL-SELECT -> S7-FOREGROUND-IMAGE -> S8-SVG-PPT -> S9-FIGURE-TEXT
```

Highlights:

- S0-PAPER-FOUNDATION reads simple descriptions lightly, but deep-reads paper PDF/LaTeX/full method descriptions.
- S1-FIGURE-STRATEGY to S3-DIRECTION-SELECT is global exploration: at least 6 separate low-fidelity sketches, divergent, eye-catching, sparse in text/formulas, and focused on reader hooks.
- S4-CANDIDATE-BRIEF to S6-FINAL-SELECT is local refinement: precise, paper-grounded, tied to method/algorithm/model structure, and explicit about theme-element coverage, figure-vs-caption split, semantic density budget, and SVG/PPT feasibility.
- Vector-first minimal semantics keep the figure as a clean cognitive map: usually 3-6 main modules, one dominant flow, few large landmark icons, short labels, and details moved to caption/legend/body text when needed.
- S6-FINAL-SELECT selects the final S5-CANDIDATE-IMAGE reference and prints the selection report.
- S7-FOREGROUND-IMAGE creates one or more foreground-only no-texture element collection sheets for SVG extraction.
- S8-SVG-PPT builds a foreground SVG catalog and self-contained PPTX, then provides the PPTX download/artifact link. Slide 1 is the grayscale selected final reference as the map page, slide 2 is the original selected final reference, and later slides contain movable, editable embedded SVG icons / foreground elements.
- In ChatGPT web, text replies should provide a full resume checkpoint zip when artifact creation is available. The package uses overwrite/latest semantics with a stable filename, and includes state, inputs, outputs, and a skill snapshot for new-conversation resume.
- Architecture governance keeps workflow constants, state schema, artifact roles, delivery builders, cleanup, and release checks loosely coupled and auditable.
- Target-paper sketches, candidates, and S7-FOREGROUND-IMAGE foreground output are generated one image at a time through the required environment image route.
- Rewind/rerun cleanup deletes covered-step products while preserving the state file and cleanup audit event.


