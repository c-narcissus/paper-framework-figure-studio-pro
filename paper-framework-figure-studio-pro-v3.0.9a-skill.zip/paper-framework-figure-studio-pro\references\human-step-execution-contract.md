# Human Step Execution Contract

Workflow must progress one step at a time unless the user explicitly asks to skip or return, and the state records the reason.

Every text or artifact-building reply begins with:

```text
全流程：S0-PAPER-FOUNDATION -> S1-FIGURE-STRATEGY -> S2-SKETCH-EXPLORE -> S3-DIRECTION-SELECT -> S4-CANDIDATE-BRIEF -> S5-CANDIDATE-IMAGE -> S6-FINAL-SELECT -> S7-FOREGROUND-IMAGE -> S8-SVG-PPT -> S9-FIGURE-TEXT
当前 step：<current_step>
默认下一步：<default_next_step 或 已完成>
```

## Hard Rules

- Do not mix text planning and target-paper image generation in the same step reply.
- Reports, briefings, review tables, validation notes, and limitations must be printed inline, not only saved to files.
- S0-PAPER-FOUNDATION depth depends on input: simple description means lightweight scoping; PDF, LaTeX, full paper text, report, supplement, or detailed method/model description triggers paper-only deep reading and printed algorithm/method/model notes.
- Target-paper sketches, candidates, and S7-FOREGROUND-IMAGE foreground outputs must use the environment image route: Image Gen in Codex, Create Image / ChatGPT Images 2.0 in ChatGPT web, or another approved API only if neither is available. Generate each image separately.
- A paper framework figure is not a poster and not a dense PPT content page. Default density must be readable.
- Every default prompt, fallback prompt, option prompt, S6-FINAL-SELECT handoff, and S7-FOREGROUND-IMAGE handoff must begin with `请按照 paper-framework-figure-studio-pro skill 的要求，根据当前状态和已登记产物，`.
- Every text reply must end with the exact standalone line `如果不知道如何提问，请说：请使用 paper-framework-figure-studio-pro 根据当前状态判断下一步`.
- User style references inform S1-FIGURE-STRATEGY type/reader-effect discussion only unless the user explicitly promotes them to design requirements.

## Decision Gates

- S0-PAPER-FOUNDATION -> S1-FIGURE-STRATEGY: startup questions handled; deep reading done and printed when source depth requires it.
- S1-FIGURE-STRATEGY -> S2-SKETCH-EXPLORE: material diagnosis, subtype/routing suggestions, global exploration options, and reference-use notes printed.
- S2-SKETCH-EXPLORE -> S3-DIRECTION-SELECT: separate sketch images exist.
- S3-DIRECTION-SELECT -> S4-CANDIDATE-BRIEF: sketch ranking printed, selected global directions recorded, and local refinement matrix prepared.
- S4-CANDIDATE-BRIEF -> S5-CANDIDATE-IMAGE: candidate matrix and paper anchors printed.
- S5-CANDIDATE-IMAGE -> S6-FINAL-SELECT: formal candidate images exist.
- S6-FINAL-SELECT -> S7-FOREGROUND-IMAGE: S6-FINAL-SELECT rechecks the paper/source, prints candidate ranking, selects the final S5-CANDIDATE-IMAGE reference, and prints the S7-FOREGROUND-IMAGE prompt.
- S7-FOREGROUND-IMAGE -> S8-SVG-PPT: `outputs/S7-foreground-image/rimg-no-texture-final-01.png` and `foreground-only-manifest.json` exist or a limitation is recorded.
- S8-SVG-PPT -> S9-FIGURE-TEXT: self-contained PPTX delivery exists or a limitation is recorded.

S8-SVG-PPT must generate a self-contained PPTX through the PPTX/SVG catalog route and cannot be replaced by a single new image or concept explanation.

## Cleanup

For free-form user requests, infer the real `target_step` and operation mode from intent before acting.

- Inspect mode covers status checks, explanation, diagnostics, historical comparison, and validation that writes no outputs. Do not clean outputs; state that no outputs/state changed.
- Rebuild/rerun/progress mode covers requests that will create, advance, replace, regenerate, or re-export a stage artifact. Clean every product from the target step through the previous current step before execution, remove covered active artifact/image/pending-output/role records from state, and record a cleanup event.
- Repair/patch mode covers fixes to a same-step existing artifact. Back up the same-step artifact, record a repair event, repair and validate it, update target-step state, then clean every downstream product after the target step and remove downstream active state records. Record the downstream cleanup reason as `downstream invalidated by repaired target_step artifact`.

During execution or repair, do not read outputs from steps after `target_step`. Only use inputs, skill resources, state, valid prior-step artifacts, and same-step repair inputs/backups. Never delete `state/project-state.json`, `state/`, `inputs/`, user source files, or skill package files. Pure historical questions may inspect history without cleanup.


