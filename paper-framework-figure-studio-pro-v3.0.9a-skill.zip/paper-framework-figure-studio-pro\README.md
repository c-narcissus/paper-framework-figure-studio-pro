# Paper Framework Figure Studio Pro v3.0.9a

<a id="chinese"></a>

## 中文 | [English](#english)

`paper-framework-figure-studio-pro` 是面向计算机科学论文框架图的制图 skill。它的目标是为绘制框架图提供多样性的参考草案，方便后续人工对照制图；适合 method overview、architecture diagram、pipeline/process figure、agent workflow、system/data-flow figure、mechanism figure 和审稿人友好的 schematic figure。感谢 bristol 的刘欣阳同学提供的协助。

## 总结

- 当前介绍的新版本包是 `paper-framework-figure-studio-pro-v3.0.9a-skill.zip`。
- 新版本不一定在所有场景下都比 `v2.5.0` 更好；不同论文、不同审美偏好和不同使用方式下，旧版仍可能更适合。
- `v2.5.0` 已被指出存在绝对路径硬编码隐患；如果仍然要使用，建议先在 Codex 中自行检查并修正相关路径后，再正式投入使用。
- 这个项目的核心目标不是给出唯一答案，而是提供多样性的结构和视觉参考草案，帮助用户做比较、筛选和后续人工制图。
- 在 ChatGPT 网页环境中，如果可以创建文件附件，文本回复应提供同名 full checkpoint zip，并采用覆盖/最新包语义，方便用户在新会话中从断点继续。
- 不管在 ChatGPT 网页环境还是 Codex 环境下，整个流程通常都比较慢；其中 Codex 在一些工程化场景下可能效果更好，但往往也更费 token。


## 设计思想与理念

- **先论文、后画图**：先建立论文事实底座，再决定图的结构、模块关系、箭头关系和表达重点。
- **先发散、后收敛**：先给出多种候选方向，再围绕论文真实结构做局部筛选和收束。
- **强调多样性参考**：项目重点是给用户提供可以比较的候选草案，而不是只输出一个单一路径的结果。
- **强调人工可继续接手**：生成结果应服务后续人工对照制图，而不是假设流程可以完全替代人工整理和排版。
- **视觉表达要服务论文内容**：允许风格上有识别度，但不能为了好看牺牲结构准确性和审稿可读性。

## 架构介绍


从架构图来看，v3.0.9a 不是简单的一串 prompt，而是一个带状态、带治理、可恢复的分层执行系统。整体可以理解为四层：最前面的论文事实底座层，中间的探索与选择层，后面的交付与转换层，以及贯穿全流程的状态治理与检查层。

- **论文事实底座层**：`S0-PAPER-FOUNDATION` 负责把论文中的算法、模块、公式、术语、箭头关系和证据锚点先抽取出来，作为后续所有步骤共享的事实基线。
- **探索与选择层**：`S1` 到 `S6` 负责图类型诊断、草图探索、方向筛选、候选细化和最终选择。这一层强调先发散后收敛，先给出可比较的参考草案，再逐步收束到更贴近论文的结果。
- **交付与转换层**：`S7` 到 `S9` 负责 foreground-only、SVG/PPT 交付以及图题文字整理。它不是单纯再出一张图，而是把前面选中的结果继续转成更适合人工接手的交付形态。
- **状态治理与检查层**：围绕整个流程，系统会维护步骤状态、产物边界和恢复点，使流程更容易回滚、重跑和检查。

从设计模式的角度看，这个架构主要借助以下思想来审核和组织：

- **松耦合、高内聚**：每个步骤尽量只负责一个清晰职责，减少跨步骤混杂，让文字分析、图像候选、最终选择和交付转换彼此分开。
- **层次化按需调用**：只有当前一步需要的输入和产物准备好了，下一步才继续执行，避免整个链条无条件一起跑。
- **隔离变换**：把论文理解、草图探索、候选生成、最终选择、foreground-only 提取和 SVG/PPT 交付看成一系列相互隔离的变换，降低互相污染的风险。
- **失败断点继续执行**：当流程中途失败或需要重跑时，可以从已有状态和产物继续，而不必每次都从头完整再来一遍。
- **跨会话恢复包**：ChatGPT 网页环境下优先维护一个 latest full checkpoint zip，包含 state、inputs、outputs 和 skill snapshot。若平台不能真正覆盖附件，则以 checkpoint manifest 中的时间和序号判断最新包。
- **抽象、记忆、便于检索**：`paper foundation report`、步骤状态和各类 manifest 共同承担了抽象和记忆的作用，方便后续步骤回查、检索和核对。
- **漏洞检查**：架构治理检查、路径扫描和交付前审计，都是为了尽量提前发现绝对路径、打包污染、状态错误或交付异常等问题。

v3.0.9a 的主线如下：

```text
S0-PAPER-FOUNDATION -> S1-FIGURE-STRATEGY -> S2-SKETCH-EXPLORE -> S3-DIRECTION-SELECT -> S4-CANDIDATE-BRIEF -> S5-CANDIDATE-IMAGE -> S6-FINAL-SELECT -> S7-FOREGROUND-IMAGE -> S8-SVG-PPT -> S9-FIGURE-TEXT
```

## 三段式流程

- **全局探索过程**：`S1-FIGURE-STRATEGY -> S2-SKETCH-EXPLORE -> S3-DIRECTION-SELECT`
- **局部细化过程**：`S4-CANDIDATE-BRIEF -> S5-CANDIDATE-IMAGE -> S6-FINAL-SELECT`
- **交付过程**：`S7-FOREGROUND-IMAGE -> S8-SVG-PPT -> S9-FIGURE-TEXT`

## 步骤列表

| Step | 类型 | 作用 |
|---|---|---|
| S0-PAPER-FOUNDATION | TEXT_ONLY | 论文精读底座，梳理论文中的算法、模块、术语、公式和箭头关系 |
| S1-FIGURE-STRATEGY | TEXT_ONLY | 诊断图类型、叙事角色和读者效果 |
| S2-SKETCH-EXPLORE | IMAGE_ONLY_PLUS_PROMPT | 全局探索草图 |
| S3-DIRECTION-SELECT | TEXT_ONLY | 从全局探索中筛出进入局部细化的方向 |
| S4-CANDIDATE-BRIEF | TEXT_ONLY | 局部细化准备，生成正式候选矩阵和 prompts |
| S5-CANDIDATE-IMAGE | IMAGE_ONLY_PLUS_PROMPT | 局部细化正式候选图 |
| S6-FINAL-SELECT | TEXT_ONLY | 从候选中选出最终架构图 |
| S7-FOREGROUND-IMAGE | IMAGE_ONLY_PLUS_PROMPT_WITH_MANIFEST | 生成 foreground-only 无底纹 final |
| S8-SVG-PPT | TEXT_ONLY_ARTIFACTS | 生成 SVG/PPT 交付结果 |
| S9-FIGURE-TEXT | TEXT_ONLY | 写图题、caption、legend 和正文引用文字 |

## 限制与已知问题

- 不管在哪种环境下，整体流程都不会特别快，尤其是 `S7-FOREGROUND-IMAGE` 和 `S8-SVG-PPT` 往往更慢。
- 效果并不稳定，仍需要人工干涉和评审；不同论文、不同环境和不同轮次下的输出质量波动较大，仍然需要人工判断、人工筛选和人工修正，当前示例里也保留了不少反面例子。
- Codex 环境下在一些完整工程场景里可能效果更好，但通常会更费 token。
- 我们没有实现“完整可编辑 PPT 复刻版”；当前交付更接近一种带参考地图的拼图式交付。
- 这种拼图式交付的好处是更稳、更容易局部替换，也更方便用户按自己的论文版式和投稿要求重新排版。
- 但它也有边界：并不是所有元素都能稳定自动变成高质量、语义完整、可直接编辑的矢量对象。
- 一些 SVG 图标仍然可能需要借助 ChatGPT 或其他 AI 模型先识别截图，再进一步转成更干净的 SVG。

## ChatGPT 网页版使用

1. 先把 `paper-framework-figure-studio-pro-v3.0.9a-skill.zip` 放进项目的 Sources。
2. 再把目标论文 PDF 放进 Sources；如果要复现实验结果，可使用 `<your_paper>.pdf`。
3. 打开 **Extended thinking**。
4. 在需要图像阶段时，切换到 **Create image**。

启动示例：

```text
请严格按照paper-framework-figure-studio-pro-v3.0.9a-skill.zip里skill的人机交互步骤，对<your_paper>.pdf绘制diagram。不要查看<your_paper>.pdf里面的diagram，注意这里说的不要查看并不是说不能自己也构思出类似的，而是说不要将其先入为主，而是根据实际情况决定生成或不生成类似的
```

## Codex 使用

1. 把 `paper-framework-figure-studio-pro-v3.0.9a-skill.zip` 放在当前工程目录中。
2. 把目标论文 PDF 也放在工程目录中，或者在 prompt 里写清楚相对路径。
3. 如果 token 额度有限，优先用 ChatGPT 网页环境。

启动示例：

```text
请严格按照 paper-framework-figure-studio-pro-v3.0.9a-skill.zip 里skill的人机交互步骤， 对 <your_paper>.pdf 绘制diagram。不要查看<your_paper>.pdf里面的diagram，注意这里说的不要查看并不是说不能自己也构思出类似的，而是说不要将其先入为主，而是根据实际情况决定生成或不生成类似的
```


<a id="english"></a>

## English | [中文](#chinese)

`paper-framework-figure-studio-pro` is a skill for making computer-science paper framework diagrams. Its goal is to provide diverse reference drafts for drawing framework figures so that users can continue the final figure-making process manually by comparing and following those drafts. It is suitable for method overviews, architecture diagrams, pipeline/process figures, agent workflows, system/data-flow figures, mechanism figures, and reviewer-friendly schematic figures. Special thanks to Xinyang Liu from Bristol for the support.

## Summary

- The current new package documented here is `paper-framework-figure-studio-pro-v3.0.9a-skill.zip`.
- The new version is not guaranteed to be better than `v2.5.0` in every scenario; depending on the paper, aesthetic preference, and workflow, the older version may still fit better.
- `v2.5.0` was reported to contain hard-coded absolute-path risks. If you still want to use it, the safer approach is to inspect and fix those path issues in Codex before using it seriously.
- The core goal of this project is not to force a single answer, but to provide diverse structural and visual reference drafts that support comparison, filtering, and later manual figure-making.
- In both ChatGPT web and Codex, the workflow is generally slow. Codex may perform better in some engineering-heavy scenarios, but it is usually much more token-expensive.


## Design Philosophy

- **Paper first, image second**: build the factual paper foundation first, then decide structure, module relations, arrow logic, and emphasis.
- **Diverge before converge**: offer multiple candidate directions first, then narrow down around the real paper structure.
- **Diversity is the point**: the project focuses on providing comparable drafts rather than one fixed answer.
- **Manual continuation is expected**: the outputs are meant to support later human-guided figure-making rather than fully replace manual layout and editing.
- **Visual style must serve paper clarity**: distinctive visuals are welcome, but not at the cost of structural accuracy or reviewer readability.

## Architecture Overview


From the architecture figure, v3.0.9a is not just a linear prompt chain. It is a stateful, governed, and recoverable execution system. At a high level, it can be understood as four layers: the paper-foundation layer, the exploration-and-selection layer, the delivery-and-transformation layer, and the cross-cutting state/governance/check layer.

- **Paper-foundation layer**: `S0-PAPER-FOUNDATION` extracts algorithms, modules, formulas, terminology, arrow relationships, and evidence anchors from the paper first, so later stages share the same factual baseline.
- **Exploration-and-selection layer**: `S1` to `S6` handle figure-type diagnosis, sketch exploration, direction filtering, candidate refinement, and final selection. This layer emphasizes divergence first and convergence later.
- **Delivery-and-transformation layer**: `S7` to `S9` handle foreground-only outputs, SVG/PPT delivery, and figure text. The goal is not just to generate one more image, but to convert the selected result into a form that is easier for humans to continue editing.
- **State/governance/check layer**: across the whole workflow, the system maintains step states, artifact boundaries, and recovery points so the process is easier to resume, rerun, rewind, and inspect.

From a design-pattern perspective, the architecture is reviewed and organized around the following ideas:

- **Loose coupling and high cohesion**: each step is designed to handle one clear responsibility, so text analysis, image generation, final selection, and delivery conversion stay separated.
- **Hierarchical on-demand invocation**: downstream steps are triggered only when the required inputs and artifacts are ready, instead of running the full chain unconditionally.
- **Isolated transformations**: paper understanding, sketch exploration, candidate generation, final selection, foreground extraction, and SVG/PPT delivery are treated as isolated transformations to reduce cross-stage contamination.
- **Resume from failure breakpoints**: when a run fails or needs to be retried, the workflow can continue from saved states and artifacts rather than always restarting from scratch.
- **Abstraction, memory, and retrieval**: the paper-foundation report, step states, and manifests act as abstraction and memory anchors, making later retrieval and verification easier.
- **Vulnerability checking**: architecture-governance checks, path scans, and pre-delivery audits are meant to catch absolute-path issues, packaging contamination, state errors, and delivery problems early.

The v3.0.9a mainline is:

```text
S0-PAPER-FOUNDATION -> S1-FIGURE-STRATEGY -> S2-SKETCH-EXPLORE -> S3-DIRECTION-SELECT -> S4-CANDIDATE-BRIEF -> S5-CANDIDATE-IMAGE -> S6-FINAL-SELECT -> S7-FOREGROUND-IMAGE -> S8-SVG-PPT -> S9-FIGURE-TEXT
```

## Three-Stage Workflow

- **Global exploration**: `S1-FIGURE-STRATEGY -> S2-SKETCH-EXPLORE -> S3-DIRECTION-SELECT`
- **Local refinement**: `S4-CANDIDATE-BRIEF -> S5-CANDIDATE-IMAGE -> S6-FINAL-SELECT`
- **Delivery**: `S7-FOREGROUND-IMAGE -> S8-SVG-PPT -> S9-FIGURE-TEXT`

## Step List

| Step | Type | Purpose |
|---|---|---|
| S0-PAPER-FOUNDATION | TEXT_ONLY | Build the factual paper foundation across algorithms, modules, terminology, formulas, and arrow relationships |
| S1-FIGURE-STRATEGY | TEXT_ONLY | Diagnose figure type, narrative role, and reader effect |
| S2-SKETCH-EXPLORE | IMAGE_ONLY_PLUS_PROMPT | Global exploration sketches |
| S3-DIRECTION-SELECT | TEXT_ONLY | Filter directions for local refinement |
| S4-CANDIDATE-BRIEF | TEXT_ONLY | Prepare the local-refinement candidate matrix and prompts |
| S5-CANDIDATE-IMAGE | IMAGE_ONLY_PLUS_PROMPT | Generate local-refinement candidate figures |
| S6-FINAL-SELECT | TEXT_ONLY | Select the final framework figure |
| S7-FOREGROUND-IMAGE | IMAGE_ONLY_PLUS_PROMPT_WITH_MANIFEST | Generate the foreground-only final |
| S8-SVG-PPT | TEXT_ONLY_ARTIFACTS | Generate the SVG/PPT delivery result |
| S9-FIGURE-TEXT | TEXT_ONLY | Write the title, caption, legend, and in-paper references |

## Limitations and Known Issues

- The workflow is not especially fast in either environment, and `S7-FOREGROUND-IMAGE` plus `S8-SVG-PPT` are usually even slower.
- The results are not fully stable and still require human intervention and review. Output quality can vary across papers, environments, and rounds, so human judgment, filtering, and correction are still necessary. The bundled example also preserves several negative cases.
- Codex may produce better results in some full-project scenarios, but it is usually much more token-hungry.
- We do not currently provide a fully editable PPT recreation. The current delivery is closer to a reference-map puzzle style.
- The advantage of this puzzle-style delivery is that it is more stable, easier to replace locally, and easier to re-layout for a user's own paper format and submission requirements.
- But it also has clear limits: not every element can yet be stably converted into a high-quality, semantically clean, directly editable vector object.
- Some SVG icons may still need help from ChatGPT or another AI model to recognize screenshot content before turning it into a cleaner SVG.

## Using in ChatGPT Web

1. First add `paper-framework-figure-studio-pro-v3.0.9a-skill.zip` to the project's Sources.
2. Then add the target paper PDF to Sources. To reproduce the example, you can use `<your_paper>.pdf`.
3. Turn on **Extended thinking**.
4. When the workflow reaches an image stage, switch to **Create image**.

Startup example:

```text
Please strictly follow the human-in-the-loop workflow steps in paper-framework-figure-studio-pro-v3.0.9a-skill.zip to draw a diagram for <your_paper>.pdf. Do not look at the diagram already inside <your_paper>.pdf. What I mean here is not that the model is forbidden from independently coming up with something similar, but that it should not be anchored by the existing figure and should decide based on the actual situation whether a similar structure should or should not be generated.
```

## Using in Codex

1. Put `paper-framework-figure-studio-pro-v3.0.9a-skill.zip` in the current project directory.
2. Put the target paper PDF in the same directory, or specify its relative path in the prompt.
3. If token budget is limited, prefer ChatGPT web.

Startup example:

```text
Please strictly follow the human-in-the-loop workflow steps in paper-framework-figure-studio-pro-v3.0.9a-skill.zip to draw a diagram for <your_paper>.pdf. Do not look at the diagram already inside <your_paper>.pdf. What I mean here is not that the model is forbidden from independently coming up with something similar, but that it should not be anchored by the existing figure and should decide based on the actual situation whether a similar structure should or should not be generated.
```
